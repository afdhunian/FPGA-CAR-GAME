// ps2_steering.v
//
// Reads a PS/2 keyboard (scan code set 2, the default one every PS/2
// keyboard powers up in) and turns it into steer_left / steer_right --
// active-high, held for as long as the key is down, wired straight into
// render_static's steer_left/steer_right ports (same "hold to move"
// semantics it already expects from buttons).
//
// Supports BOTH control schemes at once, so use whichever feels natural:
//   Arrow keys : Left  = steer_left,  Right = steer_right
//   WASD       : 'A'   = steer_left,  'D'   = steer_right
//
// Wiring into car_game.v (replaces whatever currently drives
// render_static's steer_left/steer_right -- buttons, switches, etc):
//
//   wire steer_left, steer_right;
//   ps2_steering u_kbd (
//       .clk         (CLOCK_50),
//       .reset       (~KEY[0]),
//       .PS2_CLK     (PS2_CLK),
//       .PS2_DAT     (PS2_DAT),
//       .steer_left  (steer_left),
//       .steer_right (steer_right)
//   );
//
//   render_static u_render (
//       ...
//       .steer_left  (steer_left),
//       .steer_right (steer_right),
//       ...
//   );
//
// Double-check PS2_CLK/PS2_DAT are enabled in the Pin Planner (they're
// often left unassigned by default even though the board has the port).
// If your board exposes a second PS/2 port too, this only reads the
// first one -- fine for a single-player game.

module ps2_steering (
    input  wire clk,      // board's fast system clock (e.g. 50MHz) -- NOT PS2_CLK
    input  wire reset,

    input  wire PS2_CLK,  // from the PS/2 port, driven by the keyboard
    input  wire PS2_DAT,  // from the PS/2 port, driven by the keyboard

    output reg  steer_left,
    output reg  steer_right
);

    // ------------------------------------------------------------------
    // Synchronize the keyboard's own clock/data lines into our clock
    // domain. PS2_CLK/PS2_DAT are asynchronous to `clk` (they come from
    // the keyboard's internal oscillator, ~10-16kHz), so a plain
    // 2-flop synchronizer avoids metastability before we look for edges.
    // ------------------------------------------------------------------
    reg [1:0] clk_sync, dat_sync;
    always @(posedge clk) begin
        clk_sync <= {clk_sync[0], PS2_CLK};
        dat_sync <= {dat_sync[0], PS2_DAT};
    end

    wire ps2_clk_s = clk_sync[1];
    wire ps2_dat_s = dat_sync[1];

    reg ps2_clk_prev;
    always @(posedge clk) ps2_clk_prev <= ps2_clk_s;

    // PS/2 devices shift data out on the FALLING edge of their clock --
    // that's the sample point we want.
    wire falling_edge = ps2_clk_prev && !ps2_clk_s;

    // ------------------------------------------------------------------
    // Receiver: one PS/2 frame = 11 bits, sampled on each falling edge --
    // start(0), 8 data bits (LSB first), parity, stop(1). We only care
    // about the 8 data bits; parity isn't checked here (fine for a game
    // controller -- an occasional dropped/garbled frame just means one
    // missed key edge, not a crash).
    // ------------------------------------------------------------------
    reg [3:0] bit_count;      // 0..10
    reg [7:0] shift_reg;      // accumulates the 8 data bits as they arrive
    reg       byte_ready;     // 1-cycle pulse: a full scan-code byte just landed
    reg [7:0] scan_byte;

    always @(posedge clk) begin
        byte_ready <= 1'b0;

        if (reset) begin
            bit_count <= 4'd0;
        end else if (falling_edge) begin
            if (bit_count == 4'd0) begin
                // bit 0 is the start bit (should be 0) -- just consume it,
                // don't shift it into the data byte.
                bit_count <= bit_count + 4'd1;
            end else if (bit_count >= 4'd1 && bit_count <= 4'd8) begin
                // data bits arrive LSB first
                shift_reg <= {ps2_dat_s, shift_reg[7:1]};
                bit_count <= bit_count + 4'd1;
            end else if (bit_count == 4'd9) begin
                // parity bit -- skipped
                bit_count <= bit_count + 4'd1;
            end else begin
                // bit_count == 10: stop bit -- frame done
                scan_byte  <= shift_reg;
                byte_ready <= 1'b1;
                bit_count  <= 4'd0;
            end
        end
    end

    // ------------------------------------------------------------------
    // Scan-code decode (set 2):
    //   0xE0       -- prefix for "extended" keys (arrows, etc.); the
    //                 real code follows in the next byte
    //   0xF0       -- "break" prefix, meaning key-release; the real
    //                 code follows in the next byte. Without it, a byte
    //                 is a "make" (key-press / key-repeat)
    //   0xE0 0x6B  -- Left arrow  (make)      0xE0 0xF0 0x6B -- Left arrow (break)
    //   0xE0 0x74  -- Right arrow (make)      0xE0 0xF0 0x74 -- Right arrow (break)
    //   0x1C       -- 'A' (make)              0xF0 0x1C      -- 'A' (break)
    //   0x23       -- 'D' (make)              0xF0 0x23      -- 'D' (break)
    // ------------------------------------------------------------------
    reg e0_pending, f0_pending;

    always @(posedge clk) begin
        if (reset) begin
            e0_pending  <= 1'b0;
            f0_pending  <= 1'b0;
            steer_left  <= 1'b0;
            steer_right <= 1'b0;
        end else if (byte_ready) begin
            if (scan_byte == 8'hE0) begin
                e0_pending <= 1'b1;      // next byte is an extended-key code
            end else if (scan_byte == 8'hF0) begin
                f0_pending <= 1'b1;      // next byte is a release
            end else begin
                case (scan_byte)
                    8'h6B: if (e0_pending) steer_left  <= ~f0_pending; // arrow Left
                    8'h74: if (e0_pending) steer_right <= ~f0_pending; // arrow Right
                    8'h1C: if (!e0_pending) steer_left  <= ~f0_pending; // 'A'
                    8'h23: if (!e0_pending) steer_right <= ~f0_pending; // 'D'
                    default: ; // any other key: ignore, held states unaffected
                endcase
                e0_pending <= 1'b0;
                f0_pending <= 1'b0;
            end
        end
    end

endmodule
