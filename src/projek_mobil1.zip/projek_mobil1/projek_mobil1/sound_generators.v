// sound_generators.v
//
// All the actual "instruments" -- no audio files, everything generated
// live by FPGA logic:
//   - tone_gen:      phase-accumulator square wave at any frequency
//   - engine_sound:  continuous tone whose pitch rises with speed/score
//   - crash_sfx:     short noise burst (LFSR), triggered once, fades out
//   - music_player:  tiny looping melody from a hardcoded note table

// ============================================================
// tone_gen: a numerically-controlled oscillator (NCO). Feed it a phase
// increment (bigger = higher pitch) and it outputs a square wave
// (+AMPLITUDE / -AMPLITUDE) at that frequency, referenced to clk.
//
// freq_out (Hz) = (phase_inc / 2^32) * clk_freq_hz
// ============================================================
module tone_gen #(
    parameter signed [15:0] AMPLITUDE = 16'sd6000
) (
    input  wire        clk,
    input  wire        reset,
    input  wire [31:0] phase_inc,
    input  wire        enable,
    output wire signed [15:0] sample
);
    reg [31:0] phase;
    always @(posedge clk) begin
        if (reset || !enable)
            phase <= 32'd0;
        else
            phase <= phase + phase_inc;
    end
    // Top bit of the phase accumulator is a perfect square wave at the
    // programmed frequency.
    assign sample = phase[31] ? -AMPLITUDE : AMPLITUDE;
endmodule


// ============================================================
// engine_sound: continuous engine drone. Two tones slightly detuned
// from each other (classic cheap synth trick for a "buzzier" engine
// texture instead of a flat single pitch), pitch rises with speed_level.
// ============================================================
module engine_sound (
    input  wire        clk,
    input  wire        reset,
    input  wire [3:0]  speed_level, // 0 (slow/idle) .. 15 (max speed)
    input  wire        running,     // 0 = engine off (silent), e.g. during game_over
    output wire signed [15:0] sample
);
    // Base phase increment for a low idle rumble (~80Hz-ish depending on
    // clk), climbing with speed_level. Tune BASE_INC/STEP_INC by ear.
    localparam [31:0] BASE_INC = 32'd68_719_477;   // ~80Hz @ 50MHz clk
    localparam [31:0] STEP_INC = 32'd8_589_935;    // ~10Hz per speed step

    wire [31:0] phase_inc_a = BASE_INC + speed_level * STEP_INC;
    wire [31:0] phase_inc_b = phase_inc_a + (phase_inc_a >> 5); // ~3% detuned

    wire signed [15:0] tone_a, tone_b;

    tone_gen #(.AMPLITUDE(16'sd3000)) u_tone_a (
        .clk(clk), .reset(reset), .phase_inc(phase_inc_a), .enable(running), .sample(tone_a)
    );
    tone_gen #(.AMPLITUDE(16'sd3000)) u_tone_b (
        .clk(clk), .reset(reset), .phase_inc(phase_inc_b), .enable(running), .sample(tone_b)
    );

    assign sample = running ? (tone_a + tone_b) : 16'sd0;
endmodule


// ============================================================
// crash_sfx: short noise burst with a decaying envelope, fired once
// per rising edge of `trigger`. Classic 8-bit "crash/explosion" sound:
// pseudo-random noise (LFSR) scaled down over time instead of a clean
// tone.
// ============================================================
module crash_sfx (
    input  wire clk,
    input  wire reset,
    input  wire trigger,           // pulse (or level) that starts the effect
    output wire signed [15:0] sample,
    output wire active             // high while the crash sound is still playing
);
    // ~0.4s burst at 50MHz -> 20,000,000 cycles. Envelope divides that
    // into 16 steps of decreasing volume.
    localparam [24:0] BURST_LEN   = 25'd20_000_000;
    localparam [24:0] STEP_LEN    = BURST_LEN >> 4;

    reg trigger_prev;
    always @(posedge clk) trigger_prev <= trigger;
    wire trigger_edge = trigger && !trigger_prev;

    reg [24:0] counter;
    reg        playing;

    always @(posedge clk) begin
        if (reset) begin
            counter <= 25'd0;
            playing <= 1'b0;
        end else if (trigger_edge) begin
            counter <= 25'd0;
            playing <= 1'b1;
        end else if (playing) begin
            if (counter >= BURST_LEN)
                playing <= 1'b0;
            else
                counter <= counter + 25'd1;
        end
    end

    // 16-bit LFSR noise source (taps for a maximal-length sequence)
    reg [15:0] lfsr;
    wire       lfsr_fb = lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10];
    always @(posedge clk) begin
        if (reset)
            lfsr <= 16'hACE1; // any nonzero seed
        else
            lfsr <= {lfsr[14:0], lfsr_fb};
    end

    // Envelope: louder at the start, fading to 0 -- (15 - step) out of 15
    wire [3:0] step_idx = counter[24:21]; // top 4 bits of counter ~= which of the 16 steps we're in
    wire [3:0] envelope = playing ? (4'd15 - step_idx) : 4'd0;

    // Scale the raw noise (treat lfsr as signed-ish by centering it,
    // then multiply by the envelope and shift back down)
    wire signed [16:0] noise_centered = $signed({1'b0, lfsr}) - 17'sd32768;
    wire signed [20:0] enveloped      = noise_centered * $signed({1'b0, envelope});

    assign sample = playing ? enveloped[20:5] : 16'sd0; // >>5 to bring back into a sane amplitude range
    assign active = playing;
endmodule


// ============================================================
// music_player: a tiny looping background melody. Note table is just
// phase increments (0 = rest) + durations, hardcoded below -- swap the
// table for whatever tune you want. Pauses instantly when `enable` is
// low (e.g. tie to !game_over) instead of finishing the current note.
// ============================================================
module music_player (
    input  wire clk,
    input  wire reset,
    input  wire enable,
    output wire signed [15:0] sample
);
    localparam NUM_NOTES = 8;

    // Phase increments for a simple 8-note major-scale-ish riff.
    // (Values chosen for a pleasant, clearly-different-pitch-per-note
    // feel at a 50MHz clk -- retune by ear if you want exact notes.)
    reg [31:0] note_inc [0:NUM_NOTES-1];
    reg [23:0] note_len [0:NUM_NOTES-1]; // in clk cycles (50MHz) -- ~0.2s each below
    initial begin
        note_inc[0] = 32'd221_555_752; note_len[0] = 24'd10_000_000; // C
        note_inc[1] = 32'd248_670_311; note_len[1] = 24'd10_000_000; // D
        note_inc[2] = 32'd279_101_802; note_len[2] = 24'd10_000_000; // E
        note_inc[3] = 32'd295_925_320; note_len[3] = 24'd10_000_000; // F
        note_inc[4] = 32'd332_064_006; note_len[4] = 24'd10_000_000; // G
        note_inc[5] = 32'd0;           note_len[5] = 24'd5_000_000;  // rest
        note_inc[6] = 32'd279_101_802; note_len[6] = 24'd10_000_000; // E
        note_inc[7] = 32'd221_555_752; note_len[7] = 24'd15_000_000; // C (held longer)
    end

    reg [3:0]  note_idx;
    reg [23:0] note_timer;

    always @(posedge clk) begin
        if (reset || !enable) begin
            note_idx   <= 4'd0;
            note_timer <= 24'd0;
        end else begin
            if (note_timer >= note_len[note_idx]) begin
                note_timer <= 24'd0;
                note_idx   <= (note_idx == NUM_NOTES - 1) ? 4'd0 : note_idx + 4'd1;
            end else begin
                note_timer <= note_timer + 24'd1;
            end
        end
    end

    wire is_rest = (note_inc[note_idx] == 32'd0);
    wire signed [15:0] raw_tone;

    tone_gen #(.AMPLITUDE(16'sd2000)) u_music_tone (
        .clk(clk), .reset(reset),
        .phase_inc(note_inc[note_idx]),
        .enable(enable && !is_rest),
        .sample(raw_tone)
    );

    // tone_gen outputs a constant +AMPLITUDE (not 0) whenever its
    // `enable` is low -- gate it here so rests/disabled actually give
    // silence instead of a DC thump.
    assign sample = (enable && !is_rest) ? raw_tone : 16'sd0;
endmodule
