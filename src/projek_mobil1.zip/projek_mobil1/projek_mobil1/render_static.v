// render_static.v -- otak utama game: gambar semua (jalan, mobil, musuh,
// pemandangan, HUD) + logika skor/nyawa/tabrakan.
//
// Cheat sheet biar ga nyasar (file ini panjang banget):
//   * kecepatan game            -> cari SCROLL_SPEED
//   * tikungan jalan            -> cari CURVE_MAX_CAP / SEGMENT_LENGTH
//   * panjang tiap zona/area    -> cari ZONE_LENGTH
//   * kecepatan geser mobil     -> cari CAR_STEP_BASE
//   * ukuran/kecepatan musuh    -> cari OBS_BASE_HALF / OBSTACLE_SPEEDUP
//   * nyawa & penalti           -> cari LIVES_START / LIFE_LOST_PENALTY
//   * poin-poin                 -> cari POINTS_PER_DODGE / POINTS_PER_OVERTAKE
//   * pickup bintang/nitro      -> cari BONUS_SPAWN_INTERVAL / NITRO_DURATION
//   * semua WARNA               -> blok always @(*) paling bawah file, tinggal
//                                  ganti angka red/green/blue nya (0-255)

module render_static ( 
    input  wire       clk,
    input  wire       video_on,
	 input  wire 		 reset,
    input  wire [9:0] x,
    input  wire [9:0] y,
    input  wire       steer_left,   // tahan = mobil geser kiri
    input  wire       steer_right,  // tahan = mobil geser kanan
    input  wire       start_btn,    // pencet sekali buat mulai dari layar START
    output reg  [7:0] red,
    output reg  [7:0] green,
    output reg  [7:0] blue,
	 output reg [15:0] score,
    output reg        game_over,
    output reg        collision    // pulsa 1 clock pas nabrak -- ini yang
                                    // dipakai audio_top buat trigger suara crash
);

    // ==== layar START + hitung mundur 3-2-1-GO ====
    // Sebelum start dipencet, seluruh dunia beku (semua blok update di
    // bawah dicek game_started). Habis pencet start, jalan dulu countdown
    // 3-2-1, baru game_started nyala.
    reg game_started;
    reg start_btn_prev;
    reg countdown_active;
    reg [1:0] countdown_num;            // ngitung 3,2,1
    reg [5:0] countdown_frame_counter;
    reg [5:0] go_banner_timer;          // lamanya tulisan "GO!" nempel di layar

    // Mau countdown lebih cepat/lambat? Ganti dua angka ini.
    // 60 frame = ~1 detik (layarnya 60fps).
    localparam [5:0] COUNTDOWN_FRAMES_PER_NUM = 6'd60; // ~1 detik per angka
    localparam [5:0] GO_BANNER_FRAMES         = 6'd30; // ~0.5 detik "GO!"

    initial game_started            = 1'b0;
    initial start_btn_prev          = 1'b0;
    initial countdown_active        = 1'b0;
    initial countdown_num           = 2'd3;
    initial countdown_frame_counter = 6'd0;
    initial go_banner_timer         = 6'd0;

    always @(posedge clk) begin
        if (reset) begin
            game_started            <= 1'b0;
            start_btn_prev          <= 1'b0;
            countdown_active        <= 1'b0;
            countdown_num           <= 2'd3;
            countdown_frame_counter <= 6'd0;
            go_banner_timer         <= 6'd0;
        end else if (x == 10'd0 && y == 10'd0) begin   // sekali per frame
            start_btn_prev <= start_btn;

            if (go_banner_timer != 6'd0)
                go_banner_timer <= go_banner_timer - 6'd1;

            if (!game_started && !countdown_active && start_btn && !start_btn_prev) begin
                // Start baru dipencet: mulai countdown dulu, jangan
                // langsung nyalain game_started.
                countdown_active        <= 1'b1;
                countdown_num           <= 2'd3;
                countdown_frame_counter <= 6'd0;
            end else if (countdown_active) begin
                if (countdown_frame_counter >= COUNTDOWN_FRAMES_PER_NUM - 6'd1) begin
                    countdown_frame_counter <= 6'd0;
                    if (countdown_num <= 2'd1) begin
                        // Angka "1" selesai -> game beneran mulai + flash "GO!"
                        countdown_active <= 1'b0;
                        game_started     <= 1'b1;
                        go_banner_timer  <= GO_BANNER_FRAMES;
                    end else begin
                        countdown_num <= countdown_num - 2'd1;
                    end
                end else begin
                    countdown_frame_counter <= countdown_frame_counter + 6'd1;
                end
            end
        end
    end


    wire [9:0] dy;
    wire [9:0] road_left;
    wire [9:0] road_right;
    wire [9:0] road_width;
    wire [9:0] line_margin;
    wire [9:0] line_thick;

    assign dy = (y >= 10'd120) ? (y - 10'd120) : 10'd0;

    // ==== KECEPATAN DASAR GAME ====
    // Ini angka paling sering di-tune: seberapa cepat dunia "maju" tiap
    // frame. Gedein = game lebih ngebut dari awal. Jalan, pohon, garis
    // putus-putus, dan musuh semuanya ikut angka ini.
    localparam SCROLL_SPEED = 10'd3;

    // Kecepatan total = dasar + bonus kesulitan (naik ikut skor) + nitro.
    // obstacle_speed_bonus & nitro_active dideklarasikan jauh di bawah,
    // tapi gapapa -- wire boleh dipakai duluan di Verilog.
    wire [9:0] world_scroll_speed = SCROLL_SPEED + obstacle_speed_bonus
                                    + (nitro_active ? 10'd3 : 10'd0);
                                    // ^ +3 itu tambahan kecepatan pas nitro aktif,
                                    //   mau nitronya lebih ngebut ya ganti 10'd3 ini

    // ==== BENTUK JALAN ====
    // ROAD_CENTER_X = posisi tengah jalan di layar (320 = tengah 640).
    // ROAD_HALF_FAR = setengah lebar jalan di garis horizon; makin besar
    // = jalan kelihatan makin lebar dari kejauhan.
    localparam ROAD_CENTER_X = 10'd320;
    localparam ROAD_HALF_FAR = 10'd20;

    // ==== TIKUNGAN ====
    // Jalannya belok otomatis, siklus 4 fase: lurus -> belok kanan ->
    // lurus -> belok kiri -> ulang. Tiap fase panjangnya SEGMENT_LENGTH.
    //
    // Yang enak diutak-atik:
    //   CURVE_MAX_CAP       = mentok setajam apa tikungan bisa jadi
    //   CURVE_MAX_START     = setajam apa tikungan pertama
    //   CURVE_MAX_INCREMENT = tiap satu putaran penuh, nambah setajam apa
    //   SEGMENT_LENGTH      = panjang tiap fase; kecilin = belokan lebih sering
    //   CURVE_UPDATE_DIVIDER= gedein = transisi masuk/keluar belokan lebih halus
    localparam signed CURVE_MAX_CAP       = 16;
    localparam signed CURVE_MAX_START     = 3;
    localparam signed CURVE_MAX_INCREMENT = 1;
    localparam         CURVE_STEP    = 1;
    localparam         CURVE_UPDATE_DIVIDER = 8'd4;
    localparam         SEGMENT_LENGTH = 20'd800;

    localparam PHASE_STRAIGHT_1 = 2'd0;
    localparam PHASE_RIGHT      = 2'd1;
    localparam PHASE_STRAIGHT_2 = 2'd2;
    localparam PHASE_LEFT       = 2'd3;

    reg [19:0]        seg_dist;
    reg [1:0]         phase;
    reg signed [6:0]  curve_amount;  // minus = lagi belok kiri, plus = kanan
    reg [7:0]         curve_update_counter;
    reg signed [6:0]  current_curve_max;  // ketajaman saat ini, naik tiap putaran

    initial current_curve_max = CURVE_MAX_START;

    wire signed [6:0] target_curve = (phase == PHASE_RIGHT) ? current_curve_max :
                                      (phase == PHASE_LEFT)  ? -current_curve_max :
                                                                7'sd0;

    always @(posedge clk) begin
        if (reset) begin
            seg_dist             <= 20'd0;
            phase                <= PHASE_STRAIGHT_1;
            curve_amount         <= 7'sd0;
            curve_update_counter <= 8'd0;
            current_curve_max    <= CURVE_MAX_START;
        end else if (x == 10'd0 && y == 10'd0 && !game_over && game_started) begin   // sekali per frame, beku pas game over / belum start
            if (seg_dist + world_scroll_speed >= SEGMENT_LENGTH) begin
                seg_dist <= (seg_dist + world_scroll_speed) - SEGMENT_LENGTH;

                // Habis fase belok-kiri = satu putaran penuh selesai ->
                // putaran berikutnya tikungannya lebih tajam dikit (sampai cap).
                if (phase == PHASE_LEFT && current_curve_max < CURVE_MAX_CAP)
                    current_curve_max <= current_curve_max + CURVE_MAX_INCREMENT;

                phase <= phase + 2'd1;      // muter 0,1,2,3,0,... otomatis
            end else begin
                seg_dist <= seg_dist + world_scroll_speed;
            end

            if (curve_update_counter >= CURVE_UPDATE_DIVIDER - 8'd1) begin
                curve_update_counter <= 8'd0;
                if (curve_amount < target_curve)
                    curve_amount <= curve_amount + CURVE_STEP;
                else if (curve_amount > target_curve)
                    curve_amount <= curve_amount - CURVE_STEP;
            end else begin
                curve_update_counter <= curve_update_counter + 8'd1;
            end
        end
    end

    // ==== ZONA / AREA ====
    // Tiap ZONE_LENGTH pixel perjalanan, pemandangan ganti area:
    // 0 = desa siang, 1 = kota siang, 2 = pegunungan salju, 3 = kota malam.
    // Mau tiap area lebih lama? Gedein ZONE_LENGTH.
    localparam [19:0] ZONE_LENGTH = 20'd2400; // px perjalanan per area

    reg  [19:0] zone_dist;
    reg  [1:0]  zone_id;
    reg  [1:0]  city_visit_count; // 0..2, buat siklus landmark menara jam
    reg         landmark_active;  // true = kunjungan kota kali ini ada menara jamnya
    reg  [2:0]  weather_cycle;    // counter ganti zona -- dipakai jadwal hujan
    initial zone_dist        = 20'd0;
    initial zone_id          = 2'd0;
    initial city_visit_count = 2'd0;
    initial landmark_active  = 1'b0;
    initial weather_cycle    = 3'd0;

    // Badge "AREA n" yang nongol sebentar tiap ganti area.
    // Mau nongolnya lebih lama? Gedein ZONE_BADGE_FRAMES.
    reg [6:0] zone_badge_timer;
    initial zone_badge_timer = 7'd0;
    localparam [6:0] ZONE_BADGE_FRAMES = 7'd90; // ~1.5 detik @60fps

    always @(posedge clk) begin
        if (reset) begin
            zone_dist        <= 20'd0;
            zone_id          <= 2'd0;
            city_visit_count <= 2'd0;
            landmark_active  <= 1'b0;
            weather_cycle    <= 3'd0;
            zone_badge_timer <= 7'd0;
        end else if (x == 10'd0 && y == 10'd0 && !game_over && game_started) begin
            if (zone_badge_timer != 7'd0)
                zone_badge_timer <= zone_badge_timer - 7'd1;

            if (zone_dist + world_scroll_speed >= ZONE_LENGTH) begin
                zone_dist <= (zone_dist + world_scroll_speed) - ZONE_LENGTH;
                zone_id   <= zone_id + 2'd1;   // muter 0,1,2,3,0,... otomatis
                weather_cycle <= weather_cycle + 3'd1;
                zone_badge_timer <= ZONE_BADGE_FRAMES;
                // Zona berikutnya kota kalau zone_id sekarang genap.
                // Hitung kunjungan kota di sini biar landmark_active
                // udah final pas kotanya mulai kegambar.
                if (!zone_id[0]) begin
                    landmark_active <= (city_visit_count == 2'd2); // menara jam tiap kunjungan kota ke-3
                    city_visit_count <= (city_visit_count == 2'd2) ? 2'd0 : (city_visit_count + 2'd1);
                end
            end else begin
                zone_dist <= zone_dist + world_scroll_speed;
            end
        end
    end

    wire in_city_zone  = zone_id[0];          // 1 & 3 = kota
    wire in_snow_zone  = (zone_id == 2'd2);   // pegunungan salju
    wire in_night_zone = (zone_id == 2'd3);   // kota malam

    // Jadwal hujan: aktif di 2 dari 8 pergantian zona. Mau hujan lebih
    // sering, tambahin kondisi || (weather_cycle == 3'dN) lagi.
    wire rain_active = (weather_cycle == 3'd2) || (weather_cycle == 3'd5);

    // ==== odometer jarak tempuh (buat HUD "DIST") ====
    reg [23:0] distance_traveled;
    initial distance_traveled = 24'd0;

    always @(posedge clk) begin
        if (reset)
            distance_traveled <= 24'd0;
        else if (x == 10'd0 && y == 10'd0 && !game_over && game_started)
            distance_traveled <= distance_traveled + {14'd0, world_scroll_speed};
    end

    // ==== clamp_center_x: penjaga biar jalan/objek ga "wrap" keluar layar ====
    // Jangan diutak-atik kecuali ngerti -- ini yang bikin tikungan tajam
    // aman (dulu tikungan tajam bikin jalan glitch di deket horizon).
    function [9:0] clamp_center_x;
        input signed [13:0] cx;
        input [9:0] half_extent;
        reg signed [13:0] lo, hi, e, knee_out;
        // "Soft knee": pinggiran clamp dibikin melengkung halus, bukan
        // patah mendadak -- tanpa ini ada garis patah keliatan pas
        // tikungan paling tajam.
        localparam signed HALF_KNEE = 14'sd32;
        begin
            lo = $signed({4'd0, half_extent});
            hi = 14'sd639 - $signed({4'd0, half_extent});

            if (cx > hi - HALF_KNEE) begin
                e = cx - (hi - HALF_KNEE);
                if (e >= (HALF_KNEE <<< 1))
                    knee_out = hi;
                else
                    knee_out = cx - ((e * e) >>> 7);
                clamp_center_x = knee_out[9:0];
            end else if (cx < lo + HALF_KNEE) begin
                e = (lo + HALF_KNEE) - cx;
                if (e >= (HALF_KNEE <<< 1))
                    knee_out = lo;
                else
                    knee_out = cx + ((e * e) >>> 7);
                clamp_center_x = knee_out[9:0];
            end else begin
                clamp_center_x = cx[9:0];
            end
        end
    endfunction

    // ==== curve_shift_at: rumus "jalan geser ke samping berapa px" ====
    // Dipakai SEMUA elemen (jalan, pohon, lampu, musuh, dst) biar
    // semuanya belok bareng dan kompak. Kuadratik (d*d) biar belokannya
    // melengkung kayak jalan beneran, bukan patah kayak engsel.
    function signed [13:0] curve_shift_at;
        input signed [6:0] camt;
        input        [9:0] dyv;
        reg          [9:0] d;
        reg          [19:0] d_sq;
        reg          [9:0] cbase_fine;
        reg signed  [17:0] prod;
        begin
            d              = 10'd360 - dyv;
            d_sq           = d * d;
            cbase_fine     = d_sq >> 8;
            prod           = camt * $signed({1'b0, cbase_fine});
            curve_shift_at = prod >>> 3;
        end
    endfunction

    wire signed [13:0] curve_shift;
    assign curve_shift = curve_shift_at(curve_amount, dy);

    wire signed [13:0] center_x_signed;
    assign center_x_signed = $signed({1'b0, ROAD_CENTER_X}) + curve_shift;

    wire [9:0] curved_center_x;
    assign curved_center_x = clamp_center_x(center_x_signed, ROAD_HALF_FAR + (dy >> 1));

    // (dy >> 1) = jalan melebar setengah pixel tiap baris ke bawah.
    // Ganti jadi (dy >> 2) kalau mau jalannya lebih sempit ke bawah.
    assign road_left  = curved_center_x - (ROAD_HALF_FAR + (dy >> 1));
    assign road_right = curved_center_x + (ROAD_HALF_FAR + (dy >> 1));

    // Marka pinggir & tebal garis otomatis ngikutin lebar jalan.
    assign road_width  = road_right - road_left;
    assign line_margin = road_width >> 5;
    assign line_thick = (road_width >> 4 < 10'd2) ? 10'd2 : (road_width >> 6);

    wire road_area;
    wire left_solid_line;
    wire right_solid_line;
    wire center_dash;
    wire car_body;
    wire car_window;
    wire car_tire_left;
    wire car_tire_right;

    // ==== blend4: fungsi campur warna (dipakai buat anti-alias, fade,
    // flash, dll). a = warna awal, b = warna tujuan, w = seberapa jauh
    // campurnya (0..15). ====
    function [7:0] blend4;
        input [7:0] a, b;
        input [3:0] w;
        reg [11:0] sum;
        begin
            sum = (a * (5'd16 - {1'b0, w})) + (b * {1'b0, w});
            blend4 = sum[11:4];
        end
    endfunction

    // Anti-alias ringan di tepi jalan & marka putih -- biar pinggiran
    // ga bergerigi. Ga perlu disentuh.
    wire [3:0] road_edge_w;
    assign road_edge_w = dy[0] ? 4'd8 : 4'd0;

    wire left_road_edge_aa, right_road_edge_aa;
    assign left_road_edge_aa  = (y >= 10'd120) && (x == road_left  - 10'd1);
    assign right_road_edge_aa = (y >= 10'd120) && (x == road_right + 10'd1);

    wire [3:0] line_edge_w;
    assign line_edge_w = road_width[3:0];

    wire left_line_edge_aa, right_line_edge_aa;
    assign left_line_edge_aa  = road_area && (x == road_left  + line_margin - 10'd1);
    assign right_line_edge_aa = road_area && (x == road_right - line_margin + 10'd1);

    // ==== trotoar (kerb belang hitam-putih di pinggir aspal) ====
    // Mau trotoarnya lebih lebar? Gedein angka ini.
    localparam TROTOAR_WIDTH = 10'd6;
    wire trotoar_left, trotoar_right;

    // Tekstur bintik aspal biar ga polos kayak cat rata.
    wire asphalt_fleck;

    // ==== scroll_y: counter yang bikin ilusi gerak maju ====
    // Semua yang "keliatan meluncur ke arah kamera" (garis putus,
    // bintik aspal, pohon) nyampel posisinya pakai ini.
    reg [9:0] scroll_y;

    always @(posedge clk) begin
        if (reset)
            scroll_y <= 10'd0;
        else if (x == 10'd0 && y == 10'd0 && !game_over && game_started)
            scroll_y <= scroll_y + world_scroll_speed;
    end

    // PENTING: kurang, bukan tambah. (y - scroll_y) = pola keliatan
    // turun ke bawah = maju. Kalau diganti tambah, keliatannya mundur.
    wire [9:0] anim_y = y - scroll_y;

    assign asphalt_fleck = x[1] ^ x[4] ^ anim_y[2] ^ anim_y[5];

    // Kilau tipis di aspal basah (pas hujan), ikut gerak bareng aspal.
    wire wet_glint = anim_y[1] ^ x[0];

    // 4 gradasi halus warna rumput biar ga keliatan karpet hijau polos.
    wire grass_speck_a, grass_speck_b;
    assign grass_speck_a = x[0] ^ anim_y[0];
    assign grass_speck_b = x[2] ^ anim_y[2];

    // ==== fase animasi langit & cuaca ====
    // snow_scroll = fase turun salju (jauh lebih pelan dari hujan)
    // sky_scroll  = geser burung & awan. SENGAJA jalan terus walau game
    //               belum mulai / game over, biar langitnya tetep hidup.
    reg [9:0]  snow_scroll;
    reg [11:0] sky_scroll;
    initial snow_scroll = 10'd0;
    initial sky_scroll  = 12'd0;

    // wrap_x: pembungkus koordinat x mod 640 tanpa pembagi (640 bukan
    // pangkat 2, kalau pakai % Quartus bikin divider berat).
    function [9:0] wrap_x;
        input [12:0] v0;
        reg [12:0] v;
        begin
            v = v0;
            if (v >= 13'd640) v = v - 13'd640;
            if (v >= 13'd640) v = v - 13'd640;
            if (v >= 13'd640) v = v - 13'd640;
            if (v >= 13'd640) v = v - 13'd640;
            if (v >= 13'd640) v = v - 13'd640;
            wrap_x = v[9:0];
        end
    endfunction

    // ==== burung: siluet "v" tipis yang ngepak-ngepak ====
    function bird_at;
        input [9:0] px, py;
        input [9:0] bx, by;
        input [4:0] s;      // setengah rentang sayap
        input       flap;
        reg [10:0] adx, wing, ytar;
        begin
            adx  = (px >= bx) ? ({1'b0, px} - {1'b0, bx}) : ({1'b0, bx} - {1'b0, px});
            wing = flap ? (adx >> 1) : (adx >> 2);
            ytar = ({1'b0, by} > wing) ? ({1'b0, by} - wing) : 11'd0;
            bird_at = (adx <= {6'd0, s}) &&
                      (({1'b0, py} == ytar) || ({1'b0, py} == (ytar + 11'd1)));
        end
    endfunction

    // ==== awan: 3 elips pipih digabung biar bergumpal ====
    // Perkaliannya sengaja dilebarkan dulu -- fungsi ini jalan untuk
    // SETIAP pixel layar, kalau ga dilebarin bisa wrap dan muncul
    // pixel nyasar aneh di tempat jauh.
    function cloud_at;
        input [9:0] px, py;
        input [9:0] cx, cy;
        input [5:0] r;
        reg signed [12:0] rx, ry, e0, e1, e2;
        reg        [12:0] a0, a1, a2, ay;
        reg        [25:0] q0, q1, q2, sq, rr0, rr1, rr2;
        begin
            rx = $signed({3'b0, px}) - $signed({3'b0, cx});
            ry = $signed({3'b0, py}) - $signed({3'b0, cy});
            ay = ry[12] ? (-ry) : ry;
            sq = ({13'd0, ay} * {13'd0, ay}) <<< 2;

            e0 = rx + $signed({7'd0, r});
            e1 = rx;
            e2 = rx - $signed({7'd0, r});
            a0 = e0[12] ? (-e0) : e0;
            a1 = e1[12] ? (-e1) : e1;
            a2 = e2[12] ? (-e2) : e2;

            q0 = {13'd0, a0} * {13'd0, a0};
            q1 = {13'd0, a1} * {13'd0, a1};
            q2 = {13'd0, a2} * {13'd0, a2};

            rr1 = {20'd0, r} * {20'd0, r};
            rr0 = {20'd0, (r - (r >> 2))} * {20'd0, (r - (r >> 2))};
            rr2 = {20'd0, (r >> 1)}       * {20'd0, (r >> 1)};

            cloud_at = ((q0 + sq) <= rr0) || ((q1 + sq) <= rr1) || ((q2 + sq) <= rr2);
        end
    endfunction

    // ==== posisi awal 3 burung. Mau nambah burung? Tambah localparam
    // BIRD4_*, bikin bird4_x pakai wrap_x, tambahin ke bird_pixel. ====
    localparam [9:0] BIRD1_X0 = 10'd40,  BIRD1_Y = 10'd34;
    localparam [9:0] BIRD2_X0 = 10'd230, BIRD2_Y = 10'd52;
    localparam [9:0] BIRD3_X0 = 10'd430, BIRD3_Y = 10'd26;

    wire [9:0] bird1_x = wrap_x({3'd0, BIRD1_X0} + {1'b0, sky_scroll});
    wire [9:0] bird2_x = wrap_x({3'd0, BIRD2_X0} + {1'b0, sky_scroll});
    wire [9:0] bird3_x = wrap_x({3'd0, BIRD3_X0} + {1'b0, sky_scroll});

    wire bird_flap = sky_scroll[4];

    wire bird_pixel = (y < 10'd118) &&
                      (bird_at(x, y, bird1_x, BIRD1_Y, 5'd7,  bird_flap) ||
                       bird_at(x, y, bird2_x, BIRD2_Y, 5'd5, ~bird_flap) ||
                       bird_at(x, y, bird3_x, BIRD3_Y, 5'd6,  bird_flap));

    // ==== 3 awan, gerak 4x lebih pelan dari burung (parallax) ====
    localparam [9:0] CLOUD1_X0 = 10'd110, CLOUD1_Y = 10'd30;
    localparam [9:0] CLOUD2_X0 = 10'd350, CLOUD2_Y = 10'd18;
    localparam [9:0] CLOUD3_X0 = 10'd540, CLOUD3_Y = 10'd44;

    wire [9:0] cloud_shift = sky_scroll[11:2];

    wire [9:0] cloud1_x = wrap_x({3'd0, CLOUD1_X0} + {3'd0, cloud_shift});
    wire [9:0] cloud2_x = wrap_x({3'd0, CLOUD2_X0} + {3'd0, cloud_shift});
    wire [9:0] cloud3_x = wrap_x({3'd0, CLOUD3_X0} + {3'd0, cloud_shift});

    wire cloud_pixel = (y < 10'd95) &&
                       (cloud_at(x, y, cloud1_x, CLOUD1_Y, 6'd26) ||
                        cloud_at(x, y, cloud2_x, CLOUD2_Y, 6'd20) ||
                        cloud_at(x, y, cloud3_x, CLOUD3_Y, 6'd30));

    // ==== wrap_ty: bikin objek pinggir jalan muter terus dari horizon
    // ke bawah layar, ga cuma lewat sekali terus ilang ====
    // CATATAN: dulu pakai % 360, itu bikin Quartus sintesis divider
    // beneran (berat, bisa crash di RAM kecil). Sekarang pakai
    // pengurangan berulang -- hasil sama, jauh lebih ringan.
    function [9:0] wrap_ty;
        input [9:0] ty;
        input [9:0] scroll;
        localparam [9:0] Y_MIN  = 10'd120;
        localparam [9:0] Y_MAX  = 10'd480;
        localparam [9:0] RANGE  = Y_MAX - Y_MIN;
        reg [10:0] offset;
        begin
            offset = {1'b0, ty} - {1'b0, Y_MIN} + {1'b0, scroll};
            if (offset >= {1'b0, RANGE}) offset = offset - {1'b0, RANGE};
            if (offset >= {1'b0, RANGE}) offset = offset - {1'b0, RANGE};
            if (offset >= {1'b0, RANGE}) offset = offset - {1'b0, RANGE};
            if (offset >= {1'b0, RANGE}) offset = offset - {1'b0, RANGE};
            wrap_ty = Y_MIN + offset[9:0];
        end
    endfunction

    // ==== tree_at: bentuk pohon (kanopi bulat + batang), atau cemara
    // kerucut kalau is_pine=1 (dipakai di zona salju). Cel-shaded:
    // sisi kiri terang, kanan bayangan.
    // Return: 001=kanopi terang, 010=kanopi bayangan, 011=outline,
    //         100=batang terang, 101=batang bayangan, 000=bukan pohon
    function [2:0] tree_at;
        input [9:0] px, py;
        input [9:0] tx, ty;
        input [4:0] cr;       // radius kanopi
        input [4:0] tw, th;   // lebar & tinggi batang
        input       is_pine;
        reg   [9:0] cy;
        reg   [9:0] dx, dyv;
        reg   [19:0] dist2, r2, inner_r2;
        reg   [4:0] inner_cr;
        reg         is_lit;
        reg   [9:0] pine_apex, pine_base, pine_h, pine_dyfa;
        reg   [19:0] pine_lhs, pine_rhs_out, pine_rhs_in;
        begin
            cy   = ty - th - cr + 10'd3;
            dx   = (px >= tx) ? (px - tx) : (tx - px);
            dyv  = (py >= cy) ? (py - cy) : (cy - py);
            dist2 = dx * dx + dyv * dyv;
            r2    = {15'd0, cr} * {15'd0, cr};

            inner_cr = (cr > 5'd1) ? (cr - 5'd1) : 5'd0;
            inner_r2 = {15'd0, inner_cr} * {15'd0, inner_cr};

            is_lit = (px < tx); // "cahaya dari kiri" tetap, sama di semua objek

            pine_base = ty - {5'd0, th >> 1};
            pine_apex = pine_base - ({5'd0, cr} << 1) - {5'd0, cr};
            pine_h    = pine_base - pine_apex;
            pine_dyfa = (py >= pine_apex) ? (py - pine_apex) : 10'd0;
            pine_lhs     = {10'd0, dx} * {10'd0, pine_h};
            pine_rhs_out = {15'd0, cr} * {10'd0, pine_dyfa};
            pine_rhs_in  = {15'd0, inner_cr} * {10'd0, (pine_dyfa > 10'd2) ? (pine_dyfa - 10'd2) : 10'd0};

            if (is_pine) begin
                if ((py >= pine_apex) && (py <= pine_base) && (pine_lhs <= pine_rhs_out)) begin
                    if (pine_lhs > pine_rhs_in)
                        tree_at = 3'b011; // tepi kerucut -- jadi "rim salju"
                    else if (is_lit)
                        tree_at = 3'b001;
                    else
                        tree_at = 3'b010;
                end else if ((px >= tx - {5'd0, tw >> 1}) && (px <= tx + {5'd0, tw >> 1}) &&
                             (py >= ty - {5'd0, th}) && (py <= ty)) begin
                    tree_at = is_lit ? 3'b100 : 3'b101;
                end else
                    tree_at = 3'b000;
            end else if (dist2 <= r2) begin
                if (dist2 > inner_r2)
                    tree_at = 3'b011;
                else if (is_lit)
                    tree_at = 3'b001;
                else
                    tree_at = 3'b010;
            end else if ((px >= tx - {5'd0, tw >> 1}) && (px <= tx + {5'd0, tw >> 1}) &&
                     (py >= ty - {5'd0, th}) && (py <= ty)) begin
                tree_at = is_lit ? 3'b100 : 3'b101;
            end else
                tree_at = 3'b000;
        end
    endfunction

    // ==== house_at: rumah (dinding + atap segitiga + pintu + 2 jendela) ====
    // Return: 001=dinding terang, 010=dinding bayangan, 011=atap,
    //         100=jendela, 101=pintu
    function [2:0] house_at;
        input [9:0] px, py;
        input [9:0] hx, hy;
        input [4:0] hw;        // setengah lebar dinding
        input [4:0] hh;        // tinggi dinding
        input [4:0] rh;        // tinggi atap
        input [4:0] rhw;       // setengah lebar atap (overhang)
        reg   [9:0] roof_base_y, apex_y;
        reg   [9:0] dx, dy_from_apex;
        reg         is_lit;
        reg   [9:0] door_hw, door_top;
        reg   [9:0] win_off, win_half, win_top, win_bot;
        begin
            roof_base_y = hy - {5'd0, hh};
            apex_y      = roof_base_y - {5'd0, rh};
            dx          = (px >= hx) ? (px - hx) : (hx - px);
            is_lit      = (px < hx);

            door_hw  = {6'd0, hw} >> 2;
            if (door_hw < 10'd2) door_hw = 10'd2;
            door_top = hy - ({6'd0, hh} >> 1);

            win_half = {6'd0, hw} >> 3;
            if (win_half < 10'd1) win_half = 10'd1;
            win_off  = {6'd0, hw} >> 1;
            win_top  = roof_base_y + ({6'd0, hh} >> 3) + 10'd1;
            win_bot  = win_top + (win_half << 1);

            if ((py >= apex_y) && (py < roof_base_y) && (dx <= {5'd0, rhw})) begin
                dy_from_apex = py - apex_y;
                if ((dx * {5'd0, rh}) <= ({5'd0, rhw} * dy_from_apex))
                    house_at = 3'b011; // atap
                else
                    house_at = 3'b000;
            end else if ((py >= roof_base_y) && (py <= hy) && (dx <= {5'd0, hw})) begin
                if ((dx <= door_hw) && (py >= door_top))
                    house_at = 3'b101; // pintu
                else if ((py >= win_top) && (py <= win_bot) &&
                         (((dx >= win_off - win_half - win_half) && (dx <= win_off - win_half)) ||
                          ((dx >= win_half) && (dx <= win_half + win_half))))
                    house_at = 3'b100; // jendela
                else
                    house_at = is_lit ? 3'b001 : 3'b010;
            end else
                house_at = 3'b000;
        end
    endfunction

    // ==== BARISAN POHON ====
    // Yang enak diutak-atik:
    //   NUM_TREES_SIDE  = jumlah pohon per sisi (gedein = lebih rimbun,
    //                     TAPI sintesis makin berat -- dulu 8 bikin
    //                     Quartus keberatan, makanya diturunin ke 5)
    //   TREE_GAP        = jarak pohon dari pinggir jalan
    //   TREE_BASE_HALF  = ukuran pohon di horizon (kecil = jauh)
    //   TREE_SCALE_SHIFT= makin KECIL angkanya = pohon makin cepat membesar
    localparam NUM_TREES_SIDE      = 5;
    localparam [9:0] TREE_Y_MIN    = 10'd120;
    localparam [9:0] TREE_Y_MAX    = 10'd480;
    localparam [9:0] TREE_Y_STEP   = (TREE_Y_MAX - TREE_Y_MIN) / NUM_TREES_SIDE;
    localparam [9:0] RIGHT_PHASE_OFFSET = TREE_Y_STEP >> 1; // kiri-kanan selang-seling biar ga simetris kaku
    localparam [9:0] TREE_GAP       = 10'd6;
    localparam [9:0] TREE_BASE_HALF = 10'd4;
    localparam       TREE_SCALE_SHIFT = 4;

    wire [2:0] tp_left  [0:NUM_TREES_SIDE-1];
    wire [2:0] tp_right [0:NUM_TREES_SIDE-1];

    genvar gi;
    generate
        for (gi = 0; gi < NUM_TREES_SIDE; gi = gi + 1) begin : gen_left_tree
            localparam [9:0] base_ty = TREE_Y_MIN + (TREE_Y_STEP >> 1) + gi * TREE_Y_STEP;

            wire [9:0] this_ty    = wrap_ty(base_ty, scroll_y);
            wire [9:0] this_dy    = this_ty - TREE_Y_MIN;
            wire [9:0] this_half  = TREE_BASE_HALF + (this_dy >> TREE_SCALE_SHIFT);
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);

            wire signed [13:0] this_cshift  = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig  = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_tx = this_center - this_rhalf - TREE_GAP - this_half;

            assign tp_left[gi] = tree_at(x, y, this_tx, this_ty,
                                          this_half[4:0], this_half[4:0] >> 1, this_half[4:0],
                                          in_snow_zone);
        end

        for (gi = 0; gi < NUM_TREES_SIDE; gi = gi + 1) begin : gen_right_tree
            localparam [9:0] base_ty = TREE_Y_MIN + (TREE_Y_STEP >> 1) + RIGHT_PHASE_OFFSET + gi * TREE_Y_STEP;

            wire [9:0] this_ty    = wrap_ty(base_ty, scroll_y);
            wire [9:0] this_dy    = this_ty - TREE_Y_MIN;
            wire [9:0] this_half  = TREE_BASE_HALF + (this_dy >> TREE_SCALE_SHIFT);
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);

            wire signed [13:0] this_cshift  = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig  = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_tx = this_center + this_rhalf + TREE_GAP + this_half;

            assign tp_right[gi] = tree_at(x, y, this_tx, this_ty,
                                           this_half[4:0], this_half[4:0] >> 1, this_half[4:0],
                                           in_snow_zone);
        end
    endgenerate

    // Gabungin semua pohon jadi 5 flag kategori buat pemilih warna.
    reg tree_canopy_lit, tree_canopy_shadow, tree_canopy_outline, tree_trunk_lit, tree_trunk_shadow;
    integer ti;
    always @(*) begin
        tree_canopy_lit     = 1'b0;
        tree_canopy_shadow  = 1'b0;
        tree_canopy_outline = 1'b0;
        tree_trunk_lit      = 1'b0;
        tree_trunk_shadow   = 1'b0;
        for (ti = 0; ti < NUM_TREES_SIDE; ti = ti + 1) begin
            if (tp_left[ti] == 3'b001 || tp_right[ti] == 3'b001) tree_canopy_lit     = 1'b1;
            if (tp_left[ti] == 3'b010 || tp_right[ti] == 3'b010) tree_canopy_shadow  = 1'b1;
            if (tp_left[ti] == 3'b011 || tp_right[ti] == 3'b011) tree_canopy_outline = 1'b1;
            if (tp_left[ti] == 3'b100 || tp_right[ti] == 3'b100) tree_trunk_lit      = 1'b1;
            if (tp_left[ti] == 3'b101 || tp_right[ti] == 3'b101) tree_trunk_shadow   = 1'b1;
        end
    end

    // ==== streetlight_at: lampu jalan PJU (tiang + lengan + kepala lampu
    // + panel surya + glow kecil) ====
    // Return: 001=tiang terang, 010=tiang bayangan, 011=lengan,
    //         100=rumah lampu, 101=cahaya, 110=panel surya
    function [2:0] streetlight_at;
        input [9:0] px, py;
        input [9:0] lx, ly;
        input [4:0] pw;        // lebar tiang
        input [5:0] ph;        // tinggi tiang
        input       bend_dir;  // 1 = lengan nekuk ke kanan (tiang sisi kiri jalan)
        reg   [9:0] pole_top_y;
        reg   [9:0] arm_len, arm_th;
        reg   [9:0] lamp_w, lamp_h, lamp_cx, lamp_cy;
        reg   [9:0] panel_w, panel_h, panel_x0, panel_y0;
        reg   [9:0] glow_cx, glow_cy, gdx, gdy;
        reg   [4:0] glow_r;
        reg   [19:0] gdist2, glow_r2;
        reg          is_lit;
        begin
            pole_top_y = ly - {4'd0, ph};

            arm_len = ({4'd0, ph} >> 2 < 10'd3) ? 10'd3 : ({4'd0, ph} >> 2);
            arm_th  = (pw > 5'd1) ? {5'd0, pw} : 10'd1;

            lamp_w  = arm_th + 10'd3;
            lamp_h  = arm_th + 10'd1;
            lamp_cx = bend_dir ? (lx + arm_len) : (lx - arm_len);
            lamp_cy = pole_top_y + (arm_th >> 1) + 10'd2;

            // Glow lampu sengaja ukurannya TETAP kecil, ga ikut membesar
            // pas deket -- dulu versi awal glow-nya jadi bola raksasa.
            glow_cx = lamp_cx;
            glow_cy = lamp_cy + (lamp_h >> 1) + 10'd1;
            glow_r  = (pw > 5'd3) ? 5'd3 : 5'd2;
            gdx = (px >= glow_cx) ? (px - glow_cx) : (glow_cx - px);
            gdy = (py >= glow_cy) ? (py - glow_cy) : (glow_cy - py);
            gdist2  = gdx * gdx + gdy * gdy;
            glow_r2 = {15'd0, glow_r} * {15'd0, glow_r};

            panel_w  = (arm_len > 10'd2) ? (arm_len - 10'd2) : 10'd2;
            panel_h  = (arm_th > 10'd1) ? (arm_th - 10'd1) : 10'd1;
            panel_x0 = bend_dir ? lx : (lx - panel_w);
            panel_y0 = pole_top_y + arm_th + 10'd2;

            is_lit = (px < lx);

            if (gdist2 <= glow_r2) begin
                streetlight_at = 3'b101;
            end else if ((px >= lamp_cx - (lamp_w >> 1)) && (px <= lamp_cx + (lamp_w >> 1)) &&
                         (py >= lamp_cy - (lamp_h >> 1)) && (py <= lamp_cy + (lamp_h >> 1))) begin
                streetlight_at = 3'b100;
            end else if (bend_dir ?
                         ((px >= lx) && (px <= lx + arm_len) &&
                          (py >= pole_top_y - (arm_th >> 1)) && (py <= pole_top_y + (arm_th >> 1))) :
                         ((px <= lx) && (px >= lx - arm_len) &&
                          (py >= pole_top_y - (arm_th >> 1)) && (py <= pole_top_y + (arm_th >> 1)))) begin
                streetlight_at = 3'b011;
            end else if ((px >= panel_x0) && (px <= panel_x0 + panel_w) &&
                         (py >= panel_y0) && (py <= panel_y0 + panel_h)) begin
                streetlight_at = 3'b110;
            end else if ((px >= lx - {5'd0, pw >> 1}) && (px <= lx + {5'd0, pw >> 1}) &&
                         (py >= pole_top_y) && (py <= ly)) begin
                streetlight_at = is_lit ? 3'b001 : 3'b010;
            end else
                streetlight_at = 3'b000;
        end
    endfunction

    // ==== jumlah & ukuran lampu jalan ====
    localparam NUM_LIGHTS_SIDE      = 4;  // jumlah lampu per sisi -- jangan kebanyakan, berat sintesis
    localparam [9:0] LIGHT_Y_MIN    = TREE_Y_MIN;
    localparam [9:0] LIGHT_Y_MAX    = TREE_Y_MAX;
    localparam [9:0] LIGHT_Y_STEP   = (LIGHT_Y_MAX - LIGHT_Y_MIN) / NUM_LIGHTS_SIDE;
    localparam [9:0] LIGHT_PHASE_OFFSET = LIGHT_Y_STEP >> 2; // beda fase dari pohon biar ga sejajar terus
    localparam [9:0] LIGHT_GAP       = 10'd1;
    localparam [9:0] LIGHT_BASE_HALF = 10'd1;
    localparam       LIGHT_SCALE_SHIFT = 5;    // tumbuh lebih pelan dari pohon

    wire [2:0] lp_left  [0:NUM_LIGHTS_SIDE-1];
    wire [2:0] lp_right [0:NUM_LIGHTS_SIDE-1];
    // Pantulan lampu di aspal basah -- cuma nyala pas hujan.
    wire       rfl_left  [0:NUM_LIGHTS_SIDE-1];
    wire       rfl_right [0:NUM_LIGHTS_SIDE-1];

    generate
        for (gi = 0; gi < NUM_LIGHTS_SIDE; gi = gi + 1) begin : gen_left_light
            localparam [9:0] base_ly = LIGHT_Y_MIN + (LIGHT_Y_STEP >> 1) + gi * LIGHT_Y_STEP;

            wire [9:0] this_ly    = wrap_ty(base_ly, scroll_y);
            wire [9:0] this_dy    = this_ly - LIGHT_Y_MIN;
            wire [9:0] this_half  = LIGHT_BASE_HALF + (this_dy >> LIGHT_SCALE_SHIFT);
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);
            // Tinggi tiang = 5x lebarnya, biar proporsinya kayak PJU beneran.
            wire [9:0] this_ph    = (this_half << 2) + this_half;

            // Lebar tiang DIKUNCI max 2px -- kalau ikut membesar, tiang
            // bisa nimpa pohon (pernah kejadian, makanya dikunci).
            wire [9:0] this_pw    = (this_half > 10'd2) ? 10'd2 : this_half;

            wire signed [13:0] this_cshift  = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig  = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_lx = this_center - this_rhalf - LIGHT_GAP - this_pw;

            // Posisi kepala lampu (buat pantulan di aspal basah).
            wire [9:0] this_lampx = this_lx + (this_ph >> 2);
            wire [9:0] this_rw    = (this_pw << 1) + 10'd3;

            assign lp_left[gi] = streetlight_at(x, y, this_lx, this_ly,
                                                 this_pw[4:0], this_ph[5:0], 1'b1);

            assign rfl_left[gi] = rain_active && road_area &&
                                   (y >= this_ly) && (y < this_ly + this_ph) &&
                                   ((x + this_rw) >= this_lampx) &&
                                   (x <= this_lampx + this_rw);
        end

        for (gi = 0; gi < NUM_LIGHTS_SIDE; gi = gi + 1) begin : gen_right_light
            localparam [9:0] base_ly = LIGHT_Y_MIN + (LIGHT_Y_STEP >> 1) + LIGHT_PHASE_OFFSET + gi * LIGHT_Y_STEP;

            wire [9:0] this_ly    = wrap_ty(base_ly, scroll_y);
            wire [9:0] this_dy    = this_ly - LIGHT_Y_MIN;
            wire [9:0] this_half  = LIGHT_BASE_HALF + (this_dy >> LIGHT_SCALE_SHIFT);
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);
            wire [9:0] this_ph    = (this_half << 2) + this_half;
            wire [9:0] this_pw    = (this_half > 10'd2) ? 10'd2 : this_half;

            wire signed [13:0] this_cshift  = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig  = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_lx = this_center + this_rhalf + LIGHT_GAP + this_pw;

            wire [9:0] this_armlen = this_ph >> 2;
            wire [9:0] this_lampx  = (this_lx > this_armlen) ? (this_lx - this_armlen) : 10'd0;
            wire [9:0] this_rw     = (this_pw << 1) + 10'd3;

            assign lp_right[gi] = streetlight_at(x, y, this_lx, this_ly,
                                                  this_pw[4:0], this_ph[5:0], 1'b0);

            assign rfl_right[gi] = rain_active && road_area &&
                                    (y >= this_ly) && (y < this_ly + this_ph) &&
                                    ((x + this_rw) >= this_lampx) &&
                                    (x <= this_lampx + this_rw);
        end
    endgenerate

    reg light_pole_lit, light_pole_shadow, light_arm, light_lamp_housing, light_glow, light_panel;
    reg light_reflection;
    integer li;
    always @(*) begin
        light_pole_lit      = 1'b0;
        light_pole_shadow   = 1'b0;
        light_arm           = 1'b0;
        light_lamp_housing  = 1'b0;
        light_glow          = 1'b0;
        light_panel         = 1'b0;
        light_reflection    = 1'b0;
        for (li = 0; li < NUM_LIGHTS_SIDE; li = li + 1) begin
            if (lp_left[li] == 3'b001 || lp_right[li] == 3'b001) light_pole_lit     = 1'b1;
            if (lp_left[li] == 3'b010 || lp_right[li] == 3'b010) light_pole_shadow  = 1'b1;
            if (lp_left[li] == 3'b011 || lp_right[li] == 3'b011) light_arm          = 1'b1;
            if (lp_left[li] == 3'b100 || lp_right[li] == 3'b100) light_lamp_housing = 1'b1;
            if (lp_left[li] == 3'b101 || lp_right[li] == 3'b101) light_glow         = 1'b1;
            if (lp_left[li] == 3'b110 || lp_right[li] == 3'b110) light_panel        = 1'b1;
            if (rfl_left[li] || rfl_right[li])                   light_reflection   = 1'b1;
        end
    end

    // ==== KOLAM ====
    // Dua gumpalan air per sisi, jauh di belakang barisan pohon/rumah.
    // Yang enak diutak-atik:
    //   NUM_PONDS_SIDE  = jumlah kolam per sisi
    //   POND_EXTRA_GAP  = seberapa jauh kolam dari pinggir jalan
    //   POND_BASE_R     = ukuran kolam di horizon (jangan kegedean --
    //                     bisa overflow port 5-bit di pond_at)
    localparam NUM_PONDS_SIDE   = 2;
    localparam [9:0] POND_EXTRA_GAP  = 10'd55;
    localparam [9:0] POND_BASE_R     = 10'd8;
    localparam       POND_SCALE_SHIFT = TREE_SCALE_SHIFT;

    // pond_at: gabungan 2 blob pipih biar bentuknya kayak genangan
    // asimetris, bukan lingkaran sempurna. Ada ring "tepi lumpur" tipis.
    // Return: 001=air terang, 010=air bayangan, 011=tepi lumpur
    function [2:0] pond_at;
        input [9:0] px, py;
        input [9:0] cx, cy;
        input [4:0] r1;
        input signed [8:0] dx2, dy2; // offset blob kedua
        input [4:0] r2;
        reg signed [10:0] ddx1, ddy1, ddx2, ddy2;
        reg   [10:0] adx1, ady1, adx2, ady2;
        reg signed [10:0] cx2, cy2;
        reg   [4:0]  shrink1, shrink2, inner_r1, inner_r2;
        reg   [21:0] dist2_1, outer1, inner1, dist2_2, outer2, inner2;
        reg          is_lit, in1, in1i, in2, in2i;
        begin
            cx2 = $signed({1'b0, cx}) + dx2;
            cy2 = $signed({1'b0, cy}) + dy2;

            ddx1 = $signed({1'b0, px}) - $signed({1'b0, cx});
            ddy1 = $signed({1'b0, py}) - $signed({1'b0, cy});
            adx1 = ddx1[10] ? (-ddx1) : ddx1;
            ady1 = ddy1[10] ? (-ddy1) : ddy1;

            ddx2 = $signed({1'b0, px}) - cx2;
            ddy2 = $signed({1'b0, py}) - cy2;
            adx2 = ddx2[10] ? (-ddx2) : ddx2;
            ady2 = ddy2[10] ? (-ddy2) : ddy2;

            is_lit = (px < cx);

            shrink1 = (r1 >> 3); if (shrink1 < 5'd1) shrink1 = 5'd1;
            inner_r1 = (r1 > shrink1) ? (r1 - shrink1) : 5'd0;
            shrink2 = (r2 >> 3); if (shrink2 < 5'd1) shrink2 = 5'd1;
            inner_r2 = (r2 > shrink2) ? (r2 - shrink2) : 5'd0;

            dist2_1 = ({11'd0, adx1} * {11'd0, adx1}) + (({11'd0, ady1} * {11'd0, ady1}) <<< 1);
            outer1  = ({11'd0, r1}       * {11'd0, r1})       <<< 1;
            inner1  = ({11'd0, inner_r1} * {11'd0, inner_r1}) <<< 1;

            dist2_2 = ({11'd0, adx2} * {11'd0, adx2}) + (({11'd0, ady2} * {11'd0, ady2}) <<< 1);
            outer2  = ({11'd0, r2}       * {11'd0, r2})       <<< 1;
            inner2  = ({11'd0, inner_r2} * {11'd0, inner_r2}) <<< 1;

            in1  = dist2_1 <= outer1;
            in1i = dist2_1 <= inner1;
            in2  = dist2_2 <= outer2;
            in2i = dist2_2 <= inner2;

            if (in1i || in2i)
                pond_at = is_lit ? 3'b001 : 3'b010;
            else if (in1 || in2)
                pond_at = 3'b011;
            else
                pond_at = 3'b000;
        end
    endfunction

    wire [2:0] pnd_left  [0:NUM_PONDS_SIDE-1];
    wire [2:0] pnd_right [0:NUM_PONDS_SIDE-1];

    generate
        for (gi = 0; gi < NUM_PONDS_SIDE; gi = gi + 1) begin : gen_left_pond
            // SEED ini "random" versi compile-time -- tiap kolam dapat
            // posisi/bentuk beda tanpa hardware random beneran.
            localparam [15:0] SEED     = (gi * 16'd28657) + 16'd9973;
            localparam [9:0]  Y_JIT    = SEED % (TREE_Y_MAX - TREE_Y_MIN);
            localparam [9:0]  GAP_JIT  = {6'd0, SEED[9:6]} << 2;
            localparam signed LOBE_SX  = SEED[10] ? -1 : 1;
            localparam signed LOBE_SY  = SEED[11] ? -1 : 1;
            localparam [9:0]  base_py  = TREE_Y_MIN + Y_JIT;

            wire [9:0] this_py    = wrap_ty(base_py, scroll_y);
            wire [9:0] this_dy    = this_py - TREE_Y_MIN;
            wire [9:0] this_r     = POND_BASE_R + (this_dy >> POND_SCALE_SHIFT);
            wire [9:0] this_r2    = (this_r >> 1) + (this_r >> 2);
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);
            wire [9:0] this_reach = this_r + (this_r >> 1);

            wire signed [8:0] this_dx2 = LOBE_SX * $signed({3'd0, this_r[5:0]});
            wire signed [8:0] this_dy2 = LOBE_SY * $signed({3'd0, this_r2[5:0]});

            wire signed [13:0] this_cshift = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_px = this_center - this_rhalf - TREE_GAP - SCEN_BASE_GAP - POND_EXTRA_GAP - GAP_JIT - this_reach;

            assign pnd_left[gi] = pond_at(x, y, this_px, this_py, this_r[4:0], this_dx2, this_dy2, this_r2[4:0]);
        end

        for (gi = 0; gi < NUM_PONDS_SIDE; gi = gi + 1) begin : gen_right_pond
            localparam [15:0] SEED     = (gi * 16'd28657) + 16'd41221;
            localparam [9:0]  Y_JIT    = SEED % (TREE_Y_MAX - TREE_Y_MIN);
            localparam [9:0]  GAP_JIT  = {6'd0, SEED[9:6]} << 2;
            localparam signed LOBE_SX  = SEED[10] ? -1 : 1;
            localparam signed LOBE_SY  = SEED[11] ? -1 : 1;
            localparam [9:0]  base_py  = TREE_Y_MIN + Y_JIT;

            wire [9:0] this_py    = wrap_ty(base_py, scroll_y);
            wire [9:0] this_dy    = this_py - TREE_Y_MIN;
            wire [9:0] this_r     = POND_BASE_R + (this_dy >> POND_SCALE_SHIFT);
            wire [9:0] this_r2    = (this_r >> 1) + (this_r >> 2);
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);
            wire [9:0] this_reach = this_r + (this_r >> 1);

            wire signed [8:0] this_dx2 = LOBE_SX * $signed({3'd0, this_r[5:0]});
            wire signed [8:0] this_dy2 = LOBE_SY * $signed({3'd0, this_r2[5:0]});

            wire signed [13:0] this_cshift = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_px = this_center + this_rhalf + TREE_GAP + SCEN_BASE_GAP + POND_EXTRA_GAP + GAP_JIT + this_reach;

            assign pnd_right[gi] = pond_at(x, y, this_px, this_py, this_r[4:0], this_dx2, this_dy2, this_r2[4:0]);
        end
    endgenerate

    reg pond_water_lit, pond_water_shadow, pond_shore;
    integer ri;
    always @(*) begin
        pond_water_lit    = 1'b0;
        pond_water_shadow = 1'b0;
        pond_shore        = 1'b0;
        if (!in_city_zone) begin
            // Kolam cuma fitur pedesaan -- di kota di-skip biar trotoar
            // ga tiba-tiba ada genangan.
            for (ri = 0; ri < NUM_PONDS_SIDE; ri = ri + 1) begin
                if (pnd_left[ri] == 3'b001 || pnd_right[ri] == 3'b001) pond_water_lit    = 1'b1;
                if (pnd_left[ri] == 3'b010 || pnd_right[ri] == 3'b010) pond_water_shadow = 1'b1;
                if (pnd_left[ri] == 3'b011 || pnd_right[ri] == 3'b011) pond_shore        = 1'b1;
            end
        end
    end

    // ==== kilau air kolam (shimmer) ====
    // Gedein SHIMMER_PERIOD_DIV = kilauannya bergeser lebih pelan.
    localparam [7:0] SHIMMER_PERIOD_DIV = 8'd10;

    reg [7:0] shimmer_phase;
    reg [7:0] shimmer_counter;
    initial shimmer_phase   = 8'd0;
    initial shimmer_counter = 8'd0;

    always @(posedge clk) begin
        if (reset) begin
            shimmer_phase   <= 8'd0;
            shimmer_counter <= 8'd0;
        end else if (x == 10'd0 && y == 10'd0 && !game_over && game_started) begin
            if (shimmer_counter >= SHIMMER_PERIOD_DIV - 8'd1) begin
                shimmer_counter <= 8'd0;
                shimmer_phase   <= shimmer_phase + 8'd1;
            end else begin
                shimmer_counter <= shimmer_counter + 8'd1;
            end
        end
    end

    wire [4:0] shimmer_val  = (x[2:0] + y[2:0] + shimmer_phase[4:0]) & 5'h1F;
    wire       pond_shimmer = pond_water_lit && (shimmer_val < 5'd3);

    // ==== ORANG di halaman rumah ====
    // Dulu orang-orangan sawah, sekarang orang beneran (kepala, badan,
    // tangan, kaki). Nama konstanta masih SCARECROW_* biar ga usah
    // rename ke mana-mana. Jumlahnya di NUM_SCARECROWS_SIDE.
    localparam NUM_SCARECROWS_SIDE = 2;
    localparam [9:0] SCARECROW_BASE_H  = 10'd10; // tinggi orang di horizon
    localparam       SCARECROW_SCALE_SHIFT = 4;
    localparam [9:0] SCARECROW_Y_STEP    = (TREE_Y_MAX - TREE_Y_MIN) / NUM_SCARECROWS_SIDE;
    localparam [9:0] SCARECROW_PHASE_OFF = (SCARECROW_Y_STEP >> 2) + 10'd15; // sengaja bukan setengah-step, biar ga numpuk sama rumah
    localparam [9:0] SCARECROW_BASE_GAP  = 10'd22;
    localparam [9:0] SCARECROW_RIGHT_OFF = SCARECROW_Y_STEP >> 1;

    // person_at: bentuk orang berdiri.
    // Return: 0=bukan, 1=kaki, 2=badan, 3=tangan, 4=muka/kulit, 5=rambut
    function [2:0] person_at;
        input [9:0] px, py;
        input [9:0] cx, cy;  // cy = tanah (kaki)
        input [5:0] h;        // tinggi total
        reg  [9:0] leg_h, torso_h, head_r;
        reg  [9:0] leg_w, leg_gap, torso_hw, arm_w, arm_gap, arm_len;
        reg  [9:0] leg_top, torso_top, head_cy;
        reg signed [10:0] ddx, ddy;
        reg  [10:0] adx, ady;
        reg  [21:0] dist2, r2;
        begin
            head_r  = {4'd0, (h >> 2)}; if (head_r < 10'd3) head_r = 10'd3;
            leg_h   = {4'd0, (h >> 1)};
            torso_h = ({4'd0, h} > (leg_h + (head_r << 1))) ? ({4'd0, h} - leg_h - (head_r << 1)) : 10'd2;

            leg_w    = {5'd0, (h >> 4)}; if (leg_w < 10'd1) leg_w = 10'd1;
            leg_gap  = 10'd1;
            torso_hw = (leg_w <<< 1) + leg_gap;
            arm_w    = leg_w;
            arm_gap  = 10'd1;
            arm_len  = torso_h - (torso_h >> 3);

            leg_top   = cy - leg_h;
            torso_top = leg_top - torso_h;
            head_cy   = torso_top - head_r;

            ddx = $signed({1'b0, px}) - $signed({1'b0, cx});
            ddy = $signed({1'b0, py}) - $signed({1'b0, head_cy});
            adx = ddx[10] ? (-ddx) : ddx;
            ady = ddy[10] ? (-ddy) : ddy;

            // Perkalian dilebarin -- fungsi ini jalan buat semua pixel
            // layar, kalau ga dilebarin bisa muncul pixel nyasar.
            dist2 = ({11'd0, adx} * {11'd0, adx}) + ({11'd0, ady} * {11'd0, ady});
            r2    = {11'd0, head_r} * {11'd0, head_r};

            if ((py >= leg_top) && (py <= cy) &&
                (((px >= cx - leg_gap - leg_w) && (px <= cx - leg_gap)) ||
                 ((px >= cx + leg_gap)         && (px <= cx + leg_gap + leg_w))))
                person_at = 3'd1;
            else if ((py >= torso_top) && (py <= leg_top) && (px >= cx - torso_hw) && (px <= cx + torso_hw))
                person_at = 3'd2;
            else if ((py >= torso_top) && (py <= torso_top + arm_len) &&
                     (((px >= cx - torso_hw - arm_gap - arm_w) && (px <= cx - torso_hw - arm_gap)) ||
                      ((px >= cx + torso_hw + arm_gap)         && (px <= cx + torso_hw + arm_gap + arm_w))))
                person_at = 3'd3;
            else if (dist2 <= r2)
                person_at = (ddy <= -({1'b0, head_r} >>> 1)) ? 3'd5 : 3'd4;
            else
                person_at = 3'd0;
        end
    endfunction

    wire [2:0] scr_left  [0:NUM_SCARECROWS_SIDE-1];
    wire [2:0] scr_right [0:NUM_SCARECROWS_SIDE-1];

    generate
        for (gi = 0; gi < NUM_SCARECROWS_SIDE; gi = gi + 1) begin : gen_left_scarecrow
            localparam [15:0] SEED    = (gi * 16'd19661) + 16'd5081;
            localparam [9:0]  PHASE_JIT = {6'd0, SEED[6:3]};
            localparam [9:0]  GAP_JIT = {6'd0, SEED[13:10]} << 1;
            localparam [9:0]  base_py = TREE_Y_MIN + (SCARECROW_Y_STEP >> 1) + SCARECROW_PHASE_OFF + gi * SCARECROW_Y_STEP + PHASE_JIT;

            wire [9:0] this_py    = wrap_ty(base_py, scroll_y);
            wire [9:0] this_dy    = this_py - TREE_Y_MIN;
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);
            wire [9:0] this_h     = SCARECROW_BASE_H + (this_dy >> SCARECROW_SCALE_SHIFT);

            wire signed [13:0] this_cshift = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_px = this_center - this_rhalf - TREE_GAP - SCARECROW_BASE_GAP - GAP_JIT - (this_h >> 1);

            assign scr_left[gi] = person_at(x, y, this_px, this_py, this_h[5:0]);
        end

        for (gi = 0; gi < NUM_SCARECROWS_SIDE; gi = gi + 1) begin : gen_right_scarecrow
            localparam [15:0] SEED    = (gi * 16'd19661) + 16'd37423;
            localparam [9:0]  PHASE_JIT = {6'd0, SEED[6:3]};
            localparam [9:0]  GAP_JIT = {6'd0, SEED[13:10]} << 1;
            localparam [9:0]  base_py = TREE_Y_MIN + (SCARECROW_Y_STEP >> 1) + SCARECROW_PHASE_OFF + SCARECROW_RIGHT_OFF + gi * SCARECROW_Y_STEP + PHASE_JIT;

            wire [9:0] this_py    = wrap_ty(base_py, scroll_y);
            wire [9:0] this_dy    = this_py - TREE_Y_MIN;
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);
            wire [9:0] this_h     = SCARECROW_BASE_H + (this_dy >> SCARECROW_SCALE_SHIFT);

            wire signed [13:0] this_cshift = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_px = this_center + this_rhalf + TREE_GAP + SCARECROW_BASE_GAP + GAP_JIT + (this_h >> 1);

            assign scr_right[gi] = person_at(x, y, this_px, this_py, this_h[5:0]);
        end
    endgenerate

    reg person_legs, person_torso, person_arms, person_head, person_hair;
    integer pi;
    always @(*) begin
        person_legs  = 1'b0;
        person_torso = 1'b0;
        person_arms  = 1'b0;
        person_head  = 1'b0;
        person_hair  = 1'b0;
        for (pi = 0; pi < NUM_SCARECROWS_SIDE; pi = pi + 1) begin
            if (scr_left[pi] == 3'd1 || scr_right[pi] == 3'd1) person_legs  = 1'b1;
            if (scr_left[pi] == 3'd2 || scr_right[pi] == 3'd2) person_torso = 1'b1;
            if (scr_left[pi] == 3'd3 || scr_right[pi] == 3'd3) person_arms  = 1'b1;
            if (scr_left[pi] == 3'd4 || scr_right[pi] == 3'd4) person_head  = 1'b1;
            if (scr_left[pi] == 3'd5 || scr_right[pi] == 3'd5) person_hair  = 1'b1;
        end
    end


    // ==== windmill_at: kincir angin (menara + 4 bilah muter) ====
    // Muternya trik murah: bolak-balik bentuk "+" dan "x".
    // Return: 001=menara terang, 010=menara bayangan, 011=bilah, 100=poros
    function [2:0] windmill_at;
        input [9:0] px, py;
        input [9:0] wx, wy;
        input [4:0] tw;       // setengah lebar menara
        input [4:0] th;       // tinggi menara
        input [4:0] bl;       // panjang bilah
        input       spin;     // 0 = posisi "+", 1 = posisi "x"
        reg   [9:0] hub_y;
        reg signed [10:0] ddx, ddy, sum_s, diff_s;
        reg   [10:0] adx, ady, asum, adiff;
        reg   [4:0]  thick;
        reg          is_lit, plus_blade, x_blade, hub_pixel;
        begin
            hub_y  = wy - {5'd0, th};
            is_lit = (px < wx);
            thick  = (bl >> 2);
            if (thick < 5'd1) thick = 5'd1;

            if ((px >= wx - {5'd0, tw}) && (px <= wx + {5'd0, tw}) && (py >= hub_y) && (py <= wy)) begin
                windmill_at = is_lit ? 3'b001 : 3'b010;
            end else begin
                ddx = $signed({1'b0, px}) - $signed({1'b0, wx});
                ddy = $signed({1'b0, py}) - $signed({1'b0, hub_y});
                adx = ddx[10] ? (-ddx) : ddx;
                ady = ddy[10] ? (-ddy) : ddy;

                sum_s  = ddx + ddy;
                diff_s = ddx - ddy;
                asum   = sum_s[10]  ? (-sum_s)  : sum_s;
                adiff  = diff_s[10] ? (-diff_s) : diff_s;

                plus_blade = ((adx <= {6'd0, thick}) && (ady <= {6'd0, bl})) ||
                             ((ady <= {6'd0, thick}) && (adx <= {6'd0, bl}));
                x_blade    = ((adiff <= ({6'd0, thick} <<< 1)) && (adx <= {6'd0, bl}) && (ady <= {6'd0, bl})) ||
                             ((asum  <= ({6'd0, thick} <<< 1)) && (adx <= {6'd0, bl}) && (ady <= {6'd0, bl}));
                hub_pixel  = (adx <= {6'd0, thick}) && (ady <= {6'd0, thick});

                if (hub_pixel)
                    windmill_at = 3'b100;
                else if (spin ? x_blade : plus_blade)
                    windmill_at = 3'b011;
                else
                    windmill_at = 3'b000;
            end
        end
    endfunction

    // Kecepatan "putaran" kincir: kecilin WINDMILL_SPIN_PERIOD = muter
    // lebih cepat.
    localparam [7:0] WINDMILL_SPIN_PERIOD = 8'd24;
    reg windmill_spin;
    reg [7:0] windmill_spin_counter;
    initial windmill_spin         = 1'b0;
    initial windmill_spin_counter = 8'd0;

    always @(posedge clk) begin
        if (reset) begin
            windmill_spin         <= 1'b0;
            windmill_spin_counter <= 8'd0;
        end else if (x == 10'd0 && y == 10'd0 && !game_over && game_started) begin
            if (windmill_spin_counter >= WINDMILL_SPIN_PERIOD - 8'd1) begin
                windmill_spin_counter <= 8'd0;
                windmill_spin         <= ~windmill_spin;
            end else begin
                windmill_spin_counter <= windmill_spin_counter + 8'd1;
            end
        end
    end

    // ==== building_at: gedung kota (dinding tinggi + grid jendela nyala) ====
    // Return: 001=dinding terang, 010=dinding bayangan, 011=tepi atap,
    //         100=jendela
    function [2:0] building_at;
        input [9:0] px, py;
        input [9:0] bx, by;
        input [4:0] bw;       // setengah lebar
        input [4:0] bh;       // tinggi
        reg   [9:0] dx;
        reg   [9:0] wall_top;
        reg   [9:0] local_x, local_y;
        reg         is_lit, win_col, win_row;
        begin
            wall_top = by - {5'd0, bh};
            dx       = (px >= bx) ? (px - bx) : (bx - px);
            is_lit   = (px < bx);
            if ((py >= wall_top) && (py <= by) && (dx <= {5'd0, bw})) begin
                if (py < wall_top + 10'd3) begin
                    building_at = 3'b011;
                end else begin
                    local_x = dx;
                    local_y = py - wall_top;
                    // Grid jendela dari bit-slice murah. Mau jendelanya
                    // lebih rapat/renggang, ganti [2:0] dan < 3'd2 ini.
                    win_col = (local_x[2:0] < 3'd2) && (dx < {5'd0, bw} - 10'd1);
                    win_row = (local_y[2:0] < 3'd2) && (py < by - 10'd1);
                    if (win_col && win_row)
                        building_at = 3'b100;
                    else
                        building_at = is_lit ? 3'b001 : 3'b010;
                end
            end else
                building_at = 3'b000;
        end
    endfunction

    // ==== minimarket_at: toko kecil (atap datar + papan nama + pintu
    // kaca + etalase) ====
    // Return: 001/010=dinding, 011=atap, 100=etalase, 101=pintu, 110=papan
    function [2:0] minimarket_at;
        input [9:0] px, py;
        input [9:0] mx, my;
        input [4:0] mw;
        input [4:0] mh;
        reg   [9:0] dx;
        reg   [9:0] wall_top, sign_bot, door_top, door_hw, win_l, win_r;
        reg         is_lit;
        begin
            wall_top = my - {5'd0, mh};
            sign_bot = wall_top + ({5'd0, mh} >> 2) + 10'd2;
            door_top = my - ({6'd0, mh} >> 1);
            door_hw  = {6'd0, mw} >> 2;
            if (door_hw < 10'd2) door_hw = 10'd2;
            win_l  = door_hw + 10'd2;
            win_r  = {5'd0, mw} - 10'd1;
            dx     = (px >= mx) ? (px - mx) : (mx - px);
            is_lit = (px < mx);
            if ((py >= wall_top) && (py <= my) && (dx <= {5'd0, mw})) begin
                if (py < wall_top + 10'd2)
                    minimarket_at = 3'b011;
                else if (py < sign_bot)
                    minimarket_at = 3'b110;
                else if ((dx <= door_hw) && (py >= door_top))
                    minimarket_at = 3'b101;
                else if ((dx >= win_l) && (dx <= win_r) && (py >= door_top))
                    minimarket_at = 3'b100;
                else
                    minimarket_at = is_lit ? 3'b001 : 3'b010;
            end else
                minimarket_at = 3'b000;
        end
    endfunction

    // ==== billboard_at: papan iklan (tiang + papan berbingkai + pita
    // aksen di tengah) ====
    // Return: 001/010=tiang, 011=bingkai, 100=muka papan, 101=pita aksen
    function [2:0] billboard_at;
        input [9:0] px, py;
        input [9:0] mx, my;
        input [4:0] board_hw;   // setengah lebar papan
        input [4:0] board_h;    // tinggi papan
        input [4:0] pole_h;     // tinggi tiang
        reg   [9:0] dx;
        reg   [9:0] board_bot, board_top, stripe_top, stripe_bot;
        reg   [4:0] pole_hw;
        begin
            board_bot  = my - {5'd0, pole_h};
            board_top  = board_bot - {5'd0, board_h};
            stripe_top = board_top + ({5'd0, board_h} >> 2) + 10'd1;
            stripe_bot = board_bot - ({5'd0, board_h} >> 2) - 10'd1;
            pole_hw    = 5'd2;
            dx = (px >= mx) ? (px - mx) : (mx - px);

            if ((py >= board_top) && (py < board_bot) && (dx <= {5'd0, board_hw})) begin
                if ((py < board_top + 10'd2) || (py >= board_bot - 10'd2) ||
                    (dx >= {5'd0, board_hw} - 10'd2))
                    billboard_at = 3'b011;
                else if ((py >= stripe_top) && (py < stripe_bot))
                    billboard_at = 3'b101;
                else
                    billboard_at = 3'b100;
            end else if ((py >= board_bot) && (py <= my) && (dx <= {5'd0, pole_hw})) begin
                billboard_at = (px < mx) ? 3'b001 : 3'b010;
            end else
                billboard_at = 3'b000;
        end
    endfunction

    // ==== KAMPUNG / KOTA: penempatan rumah, kincir, gedung, minimarket,
    // billboard di 7 "slot" per sisi ====
    // Tiap slot milih sendiri isinya dari hash SEED (random compile-time,
    // gratis di hardware). Yang enak diutak-atik:
    //   NUM_SCENERY_SIDE = jumlah slot per sisi (gedein = makin padat,
    //                      makin berat sintesis)
    //   SCEN_BASE_GAP    = jarak dasar bangunan dari barisan pohon
    //   *_BASE_HALF      = ukuran masing-masing objek di horizon
    localparam NUM_SCENERY_SIDE        = 7;
    localparam [9:0] SCEN_Y_STEP       = (TREE_Y_MAX - TREE_Y_MIN) / NUM_SCENERY_SIDE;
    localparam [9:0] SCEN_RIGHT_OFF    = SCEN_Y_STEP >> 1;
    localparam [9:0] SCEN_BASE_GAP     = 10'd22;
    localparam [9:0] HOUSE_BASE_HALF   = 10'd6;
    localparam       HOUSE_SCALE_SHIFT = 4;
    localparam [9:0] WINDMILL_BASE_HALF   = 10'd3;
    localparam       WINDMILL_SCALE_SHIFT = 4;
    localparam [9:0] BUILDING_BASE_HALF   = 10'd6;
    localparam       BUILDING_SCALE_SHIFT = 5;
    localparam [9:0] MARKET_BASE_HALF     = 10'd9;
    localparam       MARKET_SCALE_SHIFT   = 4;
    localparam [9:0] BILLBOARD_BASE_HALF     = 10'd26;
    localparam       BILLBOARD_SCALE_SHIFT   = 6;
    localparam [9:0] BILLBOARD_H_BASE        = 10'd16;
    localparam       BILLBOARD_H_SCALE_SHIFT = 6;
    localparam [9:0] BILLBOARD_POLE_H_BASE   = 10'd6;
    localparam       BILLBOARD_POLE_SCALE_SHIFT = 5;

    wire [2:0] hp_left  [0:NUM_SCENERY_SIDE-1];
    wire [2:0] hp_right [0:NUM_SCENERY_SIDE-1];
    wire [2:0] wp_left  [0:NUM_SCENERY_SIDE-1];
    wire [2:0] wp_right [0:NUM_SCENERY_SIDE-1];
    wire [2:0] bp_left  [0:NUM_SCENERY_SIDE-1];
    wire [2:0] bp_right [0:NUM_SCENERY_SIDE-1];
    wire [2:0] mp_left  [0:NUM_SCENERY_SIDE-1];
    wire [2:0] mp_right [0:NUM_SCENERY_SIDE-1];
    wire [2:0] adp_left  [0:NUM_SCENERY_SIDE-1]; // billboard kiri
    wire [2:0] adp_right [0:NUM_SCENERY_SIDE-1]; // billboard kanan

    generate
        for (gi = 0; gi < NUM_SCENERY_SIDE; gi = gi + 1) begin : gen_left_scenery
            localparam [15:0] SEED       = (gi * 16'd40503) + 16'd18041;
            // TYPE_SEL nentuin slot ini isinya apa. Mau ngubah rasio
            // rumah/kincir/billboard? Ganti pembagian angka 0-7 di
            // IS_HOUSE / IS_WINDMILL / IS_BILLBOARD di bawah.
            localparam [2:0]  TYPE_SEL   = SEED[2:0];
            localparam [9:0]  PHASE_JIT  = {6'd0, SEED[6:3]};
            localparam [9:0]  GAP_JIT    = {7'd0, SEED[9:7]} << 2;
            // Jarak acak ekstra KHUSUS gedung kota -- ini yang bikin
            // deretan gedung ga nempel jadi satu tembok.
            localparam [9:0]  BLDG_XTRA_JIT = {4'd0, SEED[15:10]};
            localparam        IS_HOUSE   = (TYPE_SEL <= 3'd3);
            localparam        IS_WINDMILL = (TYPE_SEL == 3'd4) || (TYPE_SEL == 3'd5) || (TYPE_SEL == 3'd7);
            localparam        IS_BILLBOARD = (TYPE_SEL == 3'd6);
            localparam        IS_BUILDING = (TYPE_SEL <= 3'd4) || (TYPE_SEL == 3'd6);
            localparam        IS_MARKET   = (TYPE_SEL == 3'd5) || (TYPE_SEL == 3'd7);

            localparam [9:0] base_sy = TREE_Y_MIN + (SCEN_Y_STEP >> 1) + gi * SCEN_Y_STEP + PHASE_JIT;

            wire [9:0] this_sy    = wrap_ty(base_sy, scroll_y);
            wire [9:0] this_dy    = this_sy - TREE_Y_MIN;
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);

            wire signed [13:0] this_cshift = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_house_half = HOUSE_BASE_HALF    + (this_dy >> HOUSE_SCALE_SHIFT);
            wire [9:0] this_wind_half  = WINDMILL_BASE_HALF + (this_dy >> WINDMILL_SCALE_SHIFT);
            // Footprint kincir = jangkauan BILAHNYA, bukan cuma menaranya
            // -- kalau nggak, bilahnya bisa nyabet barisan pohon.
            wire [9:0] this_wind_blade_r = (this_wind_half <<< 1) + 10'd8;
            wire [9:0] this_board_half = BILLBOARD_BASE_HALF + (this_dy >> BILLBOARD_SCALE_SHIFT);
            wire [9:0] this_board_h    = BILLBOARD_H_BASE    + (this_dy >> BILLBOARD_H_SCALE_SHIFT);
            wire [9:0] this_pole_h     = BILLBOARD_POLE_H_BASE + (this_dy >> BILLBOARD_POLE_SCALE_SHIFT);
            wire [9:0] this_rural_half = IS_HOUSE ? this_house_half
                                       : IS_WINDMILL ? this_wind_blade_r
                                       : this_board_half;

            wire [9:0] this_building_half   = BUILDING_BASE_HALF + (this_dy >> BUILDING_SCALE_SHIFT);
            wire [9:0] this_building_height = this_building_half + (this_building_half >> 1) + 10'd5;
            wire [9:0] this_market_half     = MARKET_BASE_HALF + (this_dy >> MARKET_SCALE_SHIFT);
            wire [9:0] this_market_height   = (this_market_half >> 1) + 10'd3;
            wire [9:0] this_city_half   = IS_BUILDING ? this_building_half : this_market_half;

            wire [9:0] this_obj_half = in_city_zone ? this_city_half : this_rural_half;

            wire [9:0] this_bldg_extra = (in_city_zone && IS_BUILDING) ? BLDG_XTRA_JIT : 10'd0;

            wire [9:0] this_sx = this_center - this_rhalf - TREE_GAP - SCEN_BASE_GAP - GAP_JIT - this_bldg_extra - this_obj_half;

            assign hp_left[gi] = (!in_city_zone && IS_HOUSE) ? house_at(x, y, this_sx, this_sy,
                                                this_house_half[4:0], (this_house_half[4:0] >> 1) + 5'd2,
                                                (this_house_half[4:0] >> 1) + 5'd3, this_house_half[4:0] + 5'd2)
                                           : 3'b000;
            assign wp_left[gi] = (!in_city_zone && IS_WINDMILL) ? windmill_at(x, y, this_sx, this_sy,
                                                this_wind_half[4:0], (this_wind_half[4:0] <<< 1) + 5'd6,
                                                this_wind_blade_r[4:0], windmill_spin)
                                              : 3'b000;
            assign adp_left[gi] = (!in_city_zone && IS_BILLBOARD) ? billboard_at(x, y, this_sx, this_sy,
                                                this_board_half[4:0], this_board_h[4:0], this_pole_h[4:0])
                                              : 3'b000;
            assign bp_left[gi] = (in_city_zone && IS_BUILDING) ? building_at(x, y, this_sx, this_sy,
                                                this_building_half[4:0], this_building_height[4:0])
                                              : 3'b000;
            assign mp_left[gi] = (in_city_zone && IS_MARKET) ? minimarket_at(x, y, this_sx, this_sy,
                                                this_market_half[4:0], this_market_height[4:0])
                                              : 3'b000;
        end

        for (gi = 0; gi < NUM_SCENERY_SIDE; gi = gi + 1) begin : gen_right_scenery
            localparam [15:0] SEED       = (gi * 16'd40503) + 16'd52237;
            localparam [2:0]  TYPE_SEL   = SEED[2:0];
            localparam [9:0]  PHASE_JIT  = {6'd0, SEED[6:3]};
            localparam [9:0]  GAP_JIT    = {7'd0, SEED[9:7]} << 2;
            localparam [9:0]  BLDG_XTRA_JIT = {4'd0, SEED[15:10]};
            localparam        IS_HOUSE   = (TYPE_SEL <= 3'd3);
            localparam        IS_WINDMILL = (TYPE_SEL == 3'd4) || (TYPE_SEL == 3'd5) || (TYPE_SEL == 3'd7);
            localparam        IS_BILLBOARD = (TYPE_SEL == 3'd6);
            localparam        IS_BUILDING = (TYPE_SEL <= 3'd4) || (TYPE_SEL == 3'd6);
            localparam        IS_MARKET   = (TYPE_SEL == 3'd5) || (TYPE_SEL == 3'd7);

            localparam [9:0] base_sy = TREE_Y_MIN + (SCEN_Y_STEP >> 1) + SCEN_RIGHT_OFF + gi * SCEN_Y_STEP + PHASE_JIT;

            wire [9:0] this_sy    = wrap_ty(base_sy, scroll_y);
            wire [9:0] this_dy    = this_sy - TREE_Y_MIN;
            wire [9:0] this_rhalf = ROAD_HALF_FAR + (this_dy >> 1);

            wire signed [13:0] this_cshift = curve_shift_at(curve_amount, this_dy);
            wire signed [13:0] this_censig = $signed({1'b0, ROAD_CENTER_X}) + this_cshift;
            wire [9:0] this_center = clamp_center_x(this_censig, 10'd5);

            wire [9:0] this_house_half = HOUSE_BASE_HALF    + (this_dy >> HOUSE_SCALE_SHIFT);
            wire [9:0] this_wind_half  = WINDMILL_BASE_HALF + (this_dy >> WINDMILL_SCALE_SHIFT);
            wire [9:0] this_wind_blade_r = (this_wind_half <<< 1) + 10'd8;
            wire [9:0] this_board_half = BILLBOARD_BASE_HALF + (this_dy >> BILLBOARD_SCALE_SHIFT);
            wire [9:0] this_board_h    = BILLBOARD_H_BASE    + (this_dy >> BILLBOARD_H_SCALE_SHIFT);
            wire [9:0] this_pole_h     = BILLBOARD_POLE_H_BASE + (this_dy >> BILLBOARD_POLE_SCALE_SHIFT);
            wire [9:0] this_rural_half = IS_HOUSE ? this_house_half
                                       : IS_WINDMILL ? this_wind_blade_r
                                       : this_board_half;

            wire [9:0] this_building_half   = BUILDING_BASE_HALF + (this_dy >> BUILDING_SCALE_SHIFT);
            wire [9:0] this_building_height = this_building_half + (this_building_half >> 1) + 10'd5;
            wire [9:0] this_market_half     = MARKET_BASE_HALF + (this_dy >> MARKET_SCALE_SHIFT);
            wire [9:0] this_market_height   = (this_market_half >> 1) + 10'd3;
            wire [9:0] this_city_half   = IS_BUILDING ? this_building_half : this_market_half;

            wire [9:0] this_obj_half = in_city_zone ? this_city_half : this_rural_half;

            wire [9:0] this_bldg_extra = (in_city_zone && IS_BUILDING) ? BLDG_XTRA_JIT : 10'd0;

            wire [9:0] this_sx = this_center + this_rhalf + TREE_GAP + SCEN_BASE_GAP + GAP_JIT + this_bldg_extra + this_obj_half;

            assign hp_right[gi] = (!in_city_zone && IS_HOUSE) ? house_at(x, y, this_sx, this_sy,
                                                this_house_half[4:0], (this_house_half[4:0] >> 1) + 5'd2,
                                                (this_house_half[4:0] >> 1) + 5'd3, this_house_half[4:0] + 5'd2)
                                            : 3'b000;
            assign wp_right[gi] = (!in_city_zone && IS_WINDMILL) ? windmill_at(x, y, this_sx, this_sy,
                                                this_wind_half[4:0], (this_wind_half[4:0] <<< 1) + 5'd6,
                                                this_wind_blade_r[4:0], windmill_spin)
                                               : 3'b000;
            assign adp_right[gi] = (!in_city_zone && IS_BILLBOARD) ? billboard_at(x, y, this_sx, this_sy,
                                                this_board_half[4:0], this_board_h[4:0], this_pole_h[4:0])
                                               : 3'b000;
            assign bp_right[gi] = (in_city_zone && IS_BUILDING) ? building_at(x, y, this_sx, this_sy,
                                                this_building_half[4:0], this_building_height[4:0])
                                               : 3'b000;
            assign mp_right[gi] = (in_city_zone && IS_MARKET) ? minimarket_at(x, y, this_sx, this_sy,
                                                this_market_half[4:0], this_market_height[4:0])
                                               : 3'b000;
        end
    endgenerate

    // Gabungin semua instance jadi flag kategori buat pemilih warna.
    reg house_wall_lit, house_wall_shadow, house_roof, house_window, house_door;
    reg windmill_tower_lit, windmill_tower_shadow, windmill_blade, windmill_hub;
    reg building_wall_lit, building_wall_shadow, building_roof, building_window;
    reg market_wall_lit, market_wall_shadow, market_roof, market_window, market_door, market_sign;
    reg billboard_pole_lit, billboard_pole_shadow, billboard_frame, billboard_face, billboard_stripe;
    integer hi_i;
    always @(*) begin
        house_wall_lit    = 1'b0;
        house_wall_shadow = 1'b0;
        house_roof        = 1'b0;
        house_window      = 1'b0;
        house_door        = 1'b0;
        windmill_tower_lit    = 1'b0;
        windmill_tower_shadow = 1'b0;
        windmill_blade         = 1'b0;
        windmill_hub            = 1'b0;
        building_wall_lit    = 1'b0;
        building_wall_shadow = 1'b0;
        building_roof        = 1'b0;
        building_window      = 1'b0;
        market_wall_lit    = 1'b0;
        market_wall_shadow = 1'b0;
        market_roof        = 1'b0;
        market_window      = 1'b0;
        market_door        = 1'b0;
        market_sign        = 1'b0;
        billboard_pole_lit    = 1'b0;
        billboard_pole_shadow = 1'b0;
        billboard_frame       = 1'b0;
        billboard_face        = 1'b0;
        billboard_stripe      = 1'b0;
        for (hi_i = 0; hi_i < NUM_SCENERY_SIDE; hi_i = hi_i + 1) begin
            if (hp_left[hi_i] == 3'b001 || hp_right[hi_i] == 3'b001) house_wall_lit    = 1'b1;
            if (hp_left[hi_i] == 3'b010 || hp_right[hi_i] == 3'b010) house_wall_shadow = 1'b1;
            if (hp_left[hi_i] == 3'b011 || hp_right[hi_i] == 3'b011) house_roof        = 1'b1;
            if (hp_left[hi_i] == 3'b100 || hp_right[hi_i] == 3'b100) house_window      = 1'b1;
            if (hp_left[hi_i] == 3'b101 || hp_right[hi_i] == 3'b101) house_door        = 1'b1;

            if (wp_left[hi_i] == 3'b001 || wp_right[hi_i] == 3'b001) windmill_tower_lit    = 1'b1;
            if (wp_left[hi_i] == 3'b010 || wp_right[hi_i] == 3'b010) windmill_tower_shadow = 1'b1;
            if (wp_left[hi_i] == 3'b011 || wp_right[hi_i] == 3'b011) windmill_blade        = 1'b1;
            if (wp_left[hi_i] == 3'b100 || wp_right[hi_i] == 3'b100) windmill_hub          = 1'b1;

            if (bp_left[hi_i] == 3'b001 || bp_right[hi_i] == 3'b001) building_wall_lit    = 1'b1;
            if (bp_left[hi_i] == 3'b010 || bp_right[hi_i] == 3'b010) building_wall_shadow = 1'b1;
            if (bp_left[hi_i] == 3'b011 || bp_right[hi_i] == 3'b011) building_roof        = 1'b1;
            if (bp_left[hi_i] == 3'b100 || bp_right[hi_i] == 3'b100) building_window      = 1'b1;

            if (mp_left[hi_i] == 3'b001 || mp_right[hi_i] == 3'b001) market_wall_lit    = 1'b1;
            if (mp_left[hi_i] == 3'b010 || mp_right[hi_i] == 3'b010) market_wall_shadow = 1'b1;
            if (mp_left[hi_i] == 3'b011 || mp_right[hi_i] == 3'b011) market_roof        = 1'b1;
            if (mp_left[hi_i] == 3'b100 || mp_right[hi_i] == 3'b100) market_window      = 1'b1;
            if (mp_left[hi_i] == 3'b101 || mp_right[hi_i] == 3'b101) market_door        = 1'b1;
            if (mp_left[hi_i] == 3'b110 || mp_right[hi_i] == 3'b110) market_sign        = 1'b1;

            if (adp_left[hi_i] == 3'b001 || adp_right[hi_i] == 3'b001) billboard_pole_lit    = 1'b1;
            if (adp_left[hi_i] == 3'b010 || adp_right[hi_i] == 3'b010) billboard_pole_shadow = 1'b1;
            if (adp_left[hi_i] == 3'b011 || adp_right[hi_i] == 3'b011) billboard_frame       = 1'b1;
            if (adp_left[hi_i] == 3'b100 || adp_right[hi_i] == 3'b100) billboard_face        = 1'b1;
            if (adp_left[hi_i] == 3'b101 || adp_right[hi_i] == 3'b101) billboard_stripe      = 1'b1;
        end
    end

    // ==== deteksi tikungan yang akan datang (buat panah HUD di atas) ====
    // Gedein SIGN_WINDOW = peringatannya muncul lebih awal.
    localparam [19:0] SIGN_WINDOW = 20'd220;

    wire sign_upcoming_right = (phase == PHASE_STRAIGHT_1);
    wire sign_upcoming_left  = (phase == PHASE_STRAIGHT_2);
    wire sign_timing         = (seg_dist >= (SEGMENT_LENGTH - SIGN_WINDOW));
    wire sign_visible        = (sign_upcoming_right || sign_upcoming_left) && sign_timing;

	 // ==== ROM gambar latar (gunung di atas horizon) ====
	wire [16:0] bg_addr;
	wire [11:0] bg_pixel;

    // Parallax: latar ikut geser dikit pas mobil belok. Gedein
    // PARALLAX_SHIFT_DIV = gesernya makin halus/subtle.
    localparam PARALLAX_SHIFT_DIV = 4;

    wire signed [10:0] parallax_shift = car_offset >>> PARALLAX_SHIFT_DIV;

    wire signed [10:0] bg_sample_x_signed = $signed({1'b0, x}) - parallax_shift;
    wire [9:0] bg_sample_x = (bg_sample_x_signed < 11'sd0)          ? (bg_sample_x_signed + 11'sd640) :
                             (bg_sample_x_signed >= 11'sd640)        ? (bg_sample_x_signed - 11'sd640) :
                                                                       bg_sample_x_signed[9:0];

	assign bg_addr = (y < 120) ? (y * 640 + {7'd0, bg_sample_x}) : 17'd0;

	background_rom bg_rom (
    .address(bg_addr),
    .clock(clk),
    .q(bg_pixel)
);

    // Instance kedua ROM yang sama, selalu baca baris terakhir gambar
    // (garis horizon) -- warnanya dipakai buat "fade" tanah nyambung
    // ke langit, biar ga ada potongan kasar di y=120.
    wire [16:0] bg_horizon_addr;
    wire [11:0] bg_horizon_pixel;

    assign bg_horizon_addr = 17'd119 * 17'd640 + {7'd0, bg_sample_x};

    background_rom bg_rom_horizon (
        .address(bg_horizon_addr),
        .clock(clk),
        .q(bg_horizon_pixel)
    );

    wire [7:0] horizon_r = {bg_horizon_pixel[11:8], bg_horizon_pixel[11:8]};
    wire [7:0] horizon_g = {bg_horizon_pixel[7:4],  bg_horizon_pixel[7:4]};
    wire [7:0] horizon_b = {bg_horizon_pixel[3:0],  bg_horizon_pixel[3:0]};

    // Warna horizon EFEKTIF: ikut digelapin pas kota malam, dipucatkan
    // pas zona salju -- biar fade-nya nyambung sama langitnya.
    wire [7:0] horizon_r_eff = in_night_zone ? {1'b0, horizon_r[7:1]} :
                               in_snow_zone  ? blend4(horizon_r, 8'd245, 4'd5) :
                                               horizon_r;
    wire [7:0] horizon_g_eff = in_night_zone ? {1'b0, horizon_g[7:1]} :
                               in_snow_zone  ? blend4(horizon_g, 8'd248, 4'd5) :
                                               horizon_g;
    wire [7:0] horizon_b_eff = in_night_zone ? ({1'b0, horizon_b[7:1]} + {3'b0, horizon_b[7:3]}) :
                               in_snow_zone  ? blend4(horizon_b, 8'd252, 4'd5) :
                                               horizon_b;

    // Lebar pita fade di bawah horizon. Dibiarin 16 aja -- pas dengan
    // rentang 0-15 blend4, ga perlu pembagian.
    localparam HORIZON_BLEND_H = 10'd16;
    wire in_horizon_blend = (y >= 10'd120) && (y < (10'd120 + HORIZON_BLEND_H));
    wire [3:0] horizon_blend_w = (y - 10'd120);

    // ==== gunung siluet lapis belakang (5 puncak) ====
    // Mau geser/rombak gunung: MBn_PX = posisi x puncak, MBn_PY =
    // ketinggian puncak (makin kecil = makin tinggi), MBn_HB = lebar kaki.
    localparam MB1_PX = 60,  MB1_PY = 45, MB1_HB = 70;
    localparam MB2_PX = 180, MB2_PY = 35, MB2_HB = 90;
    localparam MB3_PX = 330, MB3_PY = 50, MB3_HB = 80;
    localparam MB4_PX = 470, MB4_PY = 38, MB4_HB = 100;
    localparam MB5_PX = 590, MB5_PY = 55, MB5_HB = 60;

    localparam MTN_HORIZON = 120;

    wire [9:0] mb1_dx, mb2_dx, mb3_dx, mb4_dx, mb5_dx;
    assign mb1_dx = (x >= MB1_PX) ? (x - MB1_PX) : (MB1_PX - x);
    assign mb2_dx = (x >= MB2_PX) ? (x - MB2_PX) : (MB2_PX - x);
    assign mb3_dx = (x >= MB3_PX) ? (x - MB3_PX) : (MB3_PX - x);
    assign mb4_dx = (x >= MB4_PX) ? (x - MB4_PX) : (MB4_PX - x);
    assign mb5_dx = (x >= MB5_PX) ? (x - MB5_PX) : (MB5_PX - x);

   
    wire mb1, mb2, mb3, mb4, mb5;

    assign mb1 = (y >= MB1_PY) && (mb1_dx * (MTN_HORIZON - MB1_PY) <= MB1_HB * (y - MB1_PY));
    assign mb2 = (y >= MB2_PY) && (mb2_dx * (MTN_HORIZON - MB2_PY) <= MB2_HB * (y - MB2_PY));
    assign mb3 = (y >= MB3_PY) && (mb3_dx * (MTN_HORIZON - MB3_PY) <= MB3_HB * (y - MB3_PY));
    assign mb4 = (y >= MB4_PY) && (mb4_dx * (MTN_HORIZON - MB4_PY) <= MB4_HB * (y - MB4_PY));
    assign mb5 = (y >= MB5_PY) && (mb5_dx * (MTN_HORIZON - MB5_PY) <= MB5_HB * (y - MB5_PY));

    wire mtn_back1;
    assign mtn_back1 = mb1 || mb2 || mb3 || mb4 || mb5;

    assign road_area = (y >= 10'd120) &&
                       (x >= road_left) &&
                       (x <= road_right);

    assign left_solid_line = road_area &&
                             (x >= road_left + line_margin) &&
                             (x <= road_left + line_margin + line_thick);

    assign right_solid_line = road_area &&
                              (x >= road_right - line_margin - line_thick) &&
                              (x <= road_right - line_margin);

    // Garis tengah putus-putus. anim_y[5] = panjang putus-putusnya;
    // ganti ke [4] = lebih rapat, [6] = lebih panjang.
    assign center_dash = road_area &&
                         (x >= curved_center_x - (line_thick >> 1)) &&
                         (x <= curved_center_x + (line_thick >> 1)) &&
                         (anim_y[5] == 1'b0);
   
    assign trotoar_left  = (y >= 10'd120) &&
                            (x >= road_left - TROTOAR_WIDTH) &&
                            (x <  road_left);

    assign trotoar_right = (y >= 10'd120) &&
                            (x >  road_right) &&
                            (x <= road_right + TROTOAR_WIDTH);

    // Belang trotoar: anim_y[4] = jarak belangnya, ganti bit-nya kalau
    // mau lebih rapat/renggang.
    wire trotoar_stripe = anim_y[4];

// ==== MOBIL PEMAIN ====
// CAR_W/H = ukuran sprite (harus sama dengan ukuran gambar di ROM!).
// CAR_Y = posisi vertikal mobil di layar (gedein = makin ke bawah).
localparam CAR_W = 10'd128;
    localparam CAR_H = 10'd128;
    localparam CAR_X_BASE = 10'd256; // (640-128)/2 -> mobil start di tengah
    localparam CAR_Y = 10'd330;

    // Mobil geser bebas (tahan tombol = geser, lepas = berhenti di situ).
    // CAR_STEP_BASE = kecepatan geser dasar; gedein biar responsif.
    localparam signed CAR_STEP_BASE    = 3;
    localparam signed [10:0] CAR_OFFSET_MIN  = -11'sd256; // batas layar kiri
    localparam signed [10:0] CAR_OFFSET_MAX  =  11'sd256; // batas layar kanan

    // ==== hitbox mobil ====
    // Sprite 128x128 tapi gambar mobilnya ga ngisi penuh -- margin ini
    // motong bagian kosong biar ga "kena dari jauh". Kalau tabrakan
    // masih kerasa ga adil, ini yang di-tune:
    //   MARGIN_TOP gedein  = hitbox atas makin pendek (makin longgar)
    //   MARGIN_SIDE gedein = hitbox samping makin kurus
    localparam CAR_HITBOX_MARGIN_TOP    = 10'd60;
    localparam CAR_HITBOX_MARGIN_BOTTOM = 10'd5;
    localparam CAR_HITBOX_MARGIN_SIDE   = 10'd12;

    reg signed [10:0] car_offset;

    // Batas geser mobil ngikutin TEPI JALAN asli (termasuk lengkungannya),
    // dihitung di baris tempat bagian tersempit hitbox berada.
    wire [9:0] dy_car         = (CAR_Y + CAR_HITBOX_MARGIN_TOP) - 10'd120;
    wire signed [13:0] curve_shift_car     = curve_shift_at(curve_amount, dy_car);
    wire signed [13:0] center_x_car_signed = $signed({1'b0, ROAD_CENTER_X}) + curve_shift_car;
    wire [9:0] road_half_car  = ROAD_HALF_FAR + (dy_car >> 1);
    wire [9:0] curved_center_x_car = clamp_center_x(center_x_car_signed, road_half_car);
    wire [9:0] road_left_car  = curved_center_x_car - road_half_car;
    wire [9:0] road_right_car = curved_center_x_car + road_half_car;

    wire signed [10:0] offset_min_road = $signed({1'b0, road_left_car})  - $signed({1'b0, CAR_HITBOX_MARGIN_SIDE}) - $signed({1'b0, CAR_X_BASE});
    wire signed [10:0] offset_max_road = $signed({1'b0, road_right_car}) + $signed({1'b0, CAR_HITBOX_MARGIN_SIDE}) - $signed({1'b0, CAR_W}) - $signed({1'b0, CAR_X_BASE});

    wire signed [10:0] car_offset_min_eff = (offset_min_road > CAR_OFFSET_MIN) ? offset_min_road : CAR_OFFSET_MIN;
    wire signed [10:0] car_offset_max_eff = (offset_max_road < CAR_OFFSET_MAX) ? offset_max_road : CAR_OFFSET_MAX;

    // FIX penting: di tikungan tajam, ruang gerak mobil bisa kejepit
    // sampai lebih sempit dari hitbox-nya sendiri -> mobil kekunci &
    // kena musuh padahal ga bisa ngehindar. Kalau ruangnya < MIN_
    // DRIVABLE_WIDTH, dipaksa dilebarkan lagi di sekitar titik tengahnya.
    localparam signed [10:0] MIN_DRIVABLE_WIDTH = 11'sd170; // hitbox mobil (104px) + ruang ngehindar

    wire signed [10:0] eff_width = car_offset_max_eff - car_offset_min_eff;
    wire signed [10:0] eff_mid   = (car_offset_max_eff + car_offset_min_eff) >>> 1;

    wire signed [10:0] widened_min_raw = eff_mid - (MIN_DRIVABLE_WIDTH >>> 1);
    wire signed [10:0] widened_max_raw = eff_mid + (MIN_DRIVABLE_WIDTH >>> 1);

    wire signed [10:0] widened_min = (widened_min_raw < CAR_OFFSET_MIN) ? CAR_OFFSET_MIN : widened_min_raw;
    wire signed [10:0] widened_max = (widened_max_raw > CAR_OFFSET_MAX) ? CAR_OFFSET_MAX : widened_max_raw;

    wire signed [10:0] car_offset_min_final = (eff_width < MIN_DRIVABLE_WIDTH) ? widened_min : car_offset_min_eff;
    wire signed [10:0] car_offset_max_final = (eff_width < MIN_DRIVABLE_WIDTH) ? widened_max : car_offset_max_eff;

    always @(posedge clk) begin
        if (reset) begin
            car_offset <= 11'sd0;
        end else if (x == 10'd0 && y == 10'd0 && !game_over && game_started) begin   // sekali per frame
            if (steer_left && !steer_right) begin
                if ((car_offset - CAR_STEP) < car_offset_min_final)
                    car_offset <= car_offset_min_final;
                else
                    car_offset <= car_offset - CAR_STEP;
            end else if (steer_right && !steer_left) begin
                if ((car_offset + CAR_STEP) > car_offset_max_final)
                    car_offset <= car_offset_max_final;
                else
                    car_offset <= car_offset + CAR_STEP;
            end else begin
                // Ga ada tombol ditahan -> diam, tapi tetap dijepit
                // ulang kalau jalannya baru nyempit di bawah mobil.
                if (car_offset < car_offset_min_final)
                    car_offset <= car_offset_min_final;
                else if (car_offset > car_offset_max_final)
                    car_offset <= car_offset_max_final;
            end
        end
    end

    wire signed [10:0] car_x_signed;
    assign car_x_signed = $signed({1'b0, CAR_X_BASE}) + car_offset;

    wire [9:0] CAR_X;
    assign CAR_X = car_x_signed[9:0];

    // ==== ganti sprite mobil serong kiri/kanan ====
    // Ngikutin arah TIKUNGAN JALAN (curve_amount), bukan tombol setir.
    // Deadzone biar ga kedip-kedip pas jalannya pas lurus.
    localparam signed TURN_SPRITE_DEADZONE = 1;

    wire turn_left_active  = curve_amount < -TURN_SPRITE_DEADZONE;
    wire turn_right_active = curve_amount >  TURN_SPRITE_DEADZONE;

    wire signed [10:0] col_rel = $signed({1'b0, x}) - $signed({1'b0, CAR_X});
    wire is_car_col_valid = (col_rel >= 11'sd0) && (col_rel < $signed({1'b0, CAR_W}));

    wire is_car_area = is_car_col_valid && (y >= CAR_Y) && (y < CAR_Y + CAR_H);

    // Alamat ROM sprite mobil (x128 dioptimasi jadi shift oleh FPGA).
    wire [13:0] rom_addr = ((y - CAR_Y) * CAR_W) + col_rel[9:0];

    // ==== MUSUH / RINTANGAN (obstacle) ====
    // Kendaraan yang datang dari horizon ke arah mobil. Tiap muncul,
    // di-roll acak: mobil atau motor, lajur kiri/kanan.
    // Yang enak diutak-atik:
    //   OBS_BASE_HALF_W/H = ukuran musuh di horizon (kecil = jauh)
    //   OBS_SCALE_SHIFT   = kecilin = musuh membesar lebih cepat pas deket
    localparam OBS_Y_START      = 10'd130;          // baris munculnya, pas lewat horizon
    localparam OBS_Y_END        = CAR_Y + CAR_H;     // sampai sini = udah lewat mobil
    localparam OBS_BASE_HALF_W  = 10'd4;
    localparam OBS_BASE_HALF_H  = 10'd4;
    localparam OBS_SCALE_SHIFT  = 4;

    // ==== NAIK LEVEL KESULITAN ====
    // Tiap OBSTACLE_SPEEDUP_SCORE poin, musuh +1 kecepatan, mentok di
    // OBSTACLE_SPEED_MAX_BONUS. Mau game lebih cepat susah? Kecilin
    // angka pertama. Mau cap kesulitannya lebih tinggi? Gedein yang kedua
    // (tapi tabel threshold di bawah harus ikut disesuaikan).
    localparam [15:0] OBSTACLE_SPEEDUP_SCORE   = 16'd50;
    localparam [9:0]  OBSTACLE_SPEED_MAX_BONUS = 10'd7;

    // Bonus kecepatan dihitung pakai rantai komparator (bukan bagi 50)
    // biar ringan disintesis. Kalau ubah OBSTACLE_SPEEDUP_SCORE, ubah
    // juga angka-angka threshold di sini (50,100,150,...).
    wire [9:0] obstacle_speed_bonus =
        (score >= 16'd350) ? 10'd7 :
        (score >= 16'd300) ? 10'd6 :
        (score >= 16'd250) ? 10'd5 :
        (score >= 16'd200) ? 10'd4 :
        (score >= 16'd150) ? 10'd3 :
        (score >= 16'd100) ? 10'd2 :
        (score >= 16'd50)  ? 10'd1 :
                              10'd0;
    wire [9:0] OBSTACLE_SPEED = world_scroll_speed;

    // Kecepatan geser mobil naik pakai bonus yang SAMA persis dengan
    // musuh -- biar rasionya tetap adil dari skor 0 sampai tinggi.
    wire signed [10:0] CAR_STEP = $signed({1'b0, CAR_STEP_BASE}) + $signed({1'b0, obstacle_speed_bonus});

    reg [9:0] obstacle_y;
    reg [1:0] obstacle_lane;   // 0=kiri, 1=tengah, 2=kanan
    reg       obstacle_is_car; // 0=motor, 1=mobil (di-roll ulang tiap muncul)
    reg [7:0] obstacle_rand;   // LFSR 8-bit buat lajur acak
    reg       obstacle_overlap_prev;

    // Jeda "napas" antar musuh (biar ga nempel terus). Gedein
    // OBSTACLE_SPAWN_GAP = jarak antar musuh lebih longgar.
    localparam [15:0] OBSTACLE_SPAWN_GAP = 16'd50; // ~0.8 detik
    reg        obstacle_active;
    reg [15:0] obstacle_spawn_timer;

    // ==== NYAWA ====
    // LIVES_START = nyawa awal, LIVES_MAX = maksimal (nambah dari bintang),
    // LIFE_LOST_PENALTY = poin kepotong tiap kena.
    localparam [2:0]  LIVES_START       = 3'd3;
    localparam [2:0]  LIVES_MAX         = 3'd5;
    localparam [15:0] LIFE_LOST_PENALTY = 16'd10;

    reg [2:0] lives;
    initial lives = LIVES_START;

    // ==== PICKUP BINTANG (+1 nyawa) ====
    // BONUS_SPAWN_INTERVAL = jeda antar bintang (kecilin = lebih sering).
    // BONUS_BASE_R = ukuran bintang di horizon.
    localparam [15:0] BONUS_SPAWN_INTERVAL = 16'd480; // ~8 detik
    localparam [9:0]  BONUS_BASE_R         = 10'd5;
    localparam        BONUS_SCALE_SHIFT    = 4;

    reg        bonus_active;
    reg [9:0]  bonus_y;
    reg [1:0]  bonus_lane;
    reg        bonus_overlap_prev;
    reg [15:0] bonus_spawn_timer;

    initial bonus_active       = 1'b0;
    initial bonus_y            = OBS_Y_START;
    initial bonus_lane         = 2'd1;
    initial bonus_overlap_prev = 1'b0;
    initial bonus_spawn_timer  = BONUS_SPAWN_INTERVAL;

    // ==== PICKUP NITRO ====
    // Pakai slot spawn yang sama dengan bintang, cuma di-roll tipenya.
    // NITRO_DURATION = lama efek ngebut, NITRO_PICKUP_SCORE = bonus poin.
    localparam [15:0] NITRO_DURATION     = 16'd240; // ~4 detik
    localparam [15:0] NITRO_PICKUP_SCORE = 16'd25;

    reg        bonus_is_nitro;
    reg [15:0] nitro_timer;
    initial bonus_is_nitro = 1'b0;
    initial nitro_timer    = 16'd0;

    wire nitro_active = (nitro_timer != 16'd0);

    // ==== MOBIL RIVAL / TRAFFIC ====
    // Mobil lain yang jalan SEARAH (lebih pelan dari dunia), bisa DISALIP
    // (bonus poin) atau ditabrak (kena kayak rintangan).
    //   RIVAL_SPAWN_INTERVAL = jeda antar traffic
    //   POINTS_PER_OVERTAKE  = bonus nyalip biasa
    //   POINTS_PER_VIP       = bonus nyalip mobil VIP emas langka
    localparam [15:0] RIVAL_SPAWN_INTERVAL = 16'd300;
    localparam [15:0] POINTS_PER_OVERTAKE  = 16'd15;
    localparam [15:0] POINTS_PER_VIP       = 16'd120;

    reg        rival_active;
    reg [9:0]  rival_y;
    reg [1:0]  rival_lane;
    reg        rival_overlap_prev;
    reg [15:0] rival_spawn_timer;
    reg        rival_is_vip;
    initial rival_active       = 1'b0;
    initial rival_y            = OBS_Y_START;
    initial rival_lane         = 2'd0;
    initial rival_overlap_prev = 1'b0;
    initial rival_spawn_timer  = RIVAL_SPAWN_INTERVAL;
    initial rival_is_vip       = 1'b0;

    // Mendekat setengah laju dunia (+1 biar ga pernah 0): relatif ke
    // aspal dia tetap maju, pemain yang nyusul.
    wire [9:0] RIVAL_SPEED = (world_scroll_speed >> 1) + 10'd1;

    // ==== NEAR-MISS (nyaris nabrak) ====
    // Kalau lewat mepet banget (kotak diperlebar nyentuh, tapi kotak
    // asli enggak) -> bonus poin. NEAR_MARGIN = seberapa "mepet"
    // dihitung near-miss, NEAR_MISS_BONUS = bonusnya.
    localparam [9:0]  NEAR_MARGIN_W   = 10'd14;
    localparam [9:0]  NEAR_MARGIN_H   = 10'd10;
    localparam [15:0] NEAR_MISS_BONUS = 16'd10;

    reg near_miss_latch;
    initial near_miss_latch = 1'b0;

    // ==== counter feedback visual (flash/confetti/cuaca) ====
    // MILESTONE_STEP = tiap berapa poin dirayakan confetti.
    localparam [15:0] MILESTONE_STEP = 16'd1000;

    reg [3:0]  hit_flash;        // kekuatan flash merah pas nabrak
    reg [3:0]  nm_flash;         // kilatan emas near-miss
    reg [4:0]  celebrate_timer;  // sisa frame confetti
    reg [15:0] milestone_target; // ambang skor berikutnya buat confetti
    reg [9:0]  rain_scroll;      // fase jatuh hujan
    reg [3:0]  lightning_flash;    // kilatan petir
    reg [9:0]  lightning_cooldown; // jeda antar petir

    // Screen shake: goyangan singkat, sengaja CUMA di panel HUD (bukan
    // seluruh scene) -- kalau nge-shake seluruh 3D harus ubah semua
    // fungsi geometri, ribet & berisiko demi efek "juice" doang.
    reg signed [2:0] shake_offset_x, shake_offset_y;
    reg [3:0]        shake_timer;
    initial shake_offset_x = 3'sd0;
    initial shake_offset_y = 3'sd0;
    initial shake_timer    = 4'd0;

    initial hit_flash        = 4'd0;
    initial nm_flash         = 4'd0;
    initial celebrate_timer  = 5'd0;
    initial milestone_target = MILESTONE_STEP;
    initial rain_scroll      = 10'd0;
    initial lightning_flash    = 4'd0;
    initial lightning_cooldown = 10'd90;

    initial obstacle_y            = OBS_Y_START;
    initial obstacle_lane         = 2'd0;
    initial obstacle_is_car       = 1'b1;
    initial obstacle_rand         = 8'hA5; // WAJIB non-zero, LFSR nol nyangkut di nol
    initial obstacle_overlap_prev = 1'b0;
    initial obstacle_active       = 1'b1;
    initial obstacle_spawn_timer  = 16'd0;
    initial score                 = 16'd0;
    initial game_over              = 1'b0;

    wire obstacle_reached_end = obstacle_active && ((obstacle_y + OBSTACLE_SPEED) >= OBS_Y_END);

    // Pemilih lajur pakai fold 2 pasang bit LFSR. Lajur 3 dipetakan ke
    // 1 (tengah) biar cuma ada 3 lajur valid.
    wire [1:0] next_lane_raw = obstacle_rand[1:0] ^ obstacle_rand[6:5];
    wire [1:0] next_lane     = (next_lane_raw == 2'd3) ? 2'd1 : next_lane_raw;

    // Musuh cuma spawn di lajur kiri/kanan (tengah sengaja dikosongin
    // biar selalu ada jalur aman di tengah).
    wire [1:0] obstacle_next_lane = (obstacle_rand[1] ^ obstacle_rand[6]) ? 2'd2 : 2'd0;

    // Tipe kendaraan berikutnya, dari bit LFSR beda biar ga berkorelasi.
    wire next_is_car = obstacle_rand[7] ^ obstacle_rand[2];

    // Matematika perspektif musuh (sama dengan jalan, tapi di jarak musuh).
    wire [9:0] dy_obs         = obstacle_y - 10'd120;
    wire signed [13:0] curve_shift_obs = curve_shift_at(curve_amount, dy_obs);
    wire signed [13:0] center_x_obs_signed = $signed({1'b0, ROAD_CENTER_X}) + curve_shift_obs;
    wire [9:0] road_half_obs  = ROAD_HALF_FAR + (dy_obs >> 1);

    wire signed [10:0] lane_offset = (obstacle_lane == 2'd0) ? -$signed({1'b0, road_half_obs}) >>> 1 :
                                      (obstacle_lane == 2'd2) ?  $signed({1'b0, road_half_obs}) >>> 1 :
                                                                  11'sd0;

    wire signed [10:0] obstacle_x_signed = center_x_obs_signed + lane_offset;
    wire [9:0] obstacle_x = clamp_center_x(obstacle_x_signed, 10'd25);

    // Motor hitbox lebih kurus dari mobil (emang lebih kecil, biar adil).
    wire [9:0] obs_half_w = obstacle_is_car
        ? (OBS_BASE_HALF_W + (dy_obs >> OBS_SCALE_SHIFT) + 10'd2)
        : (((OBS_BASE_HALF_W + (dy_obs >> OBS_SCALE_SHIFT)) >> 1) + 10'd1);
    wire [9:0] obs_half_h = OBS_BASE_HALF_H + (dy_obs >> OBS_SCALE_SHIFT);

    wire signed [10:0] obs_col_rel = $signed({1'b0, x}) - $signed({1'b0, obstacle_x});
    wire signed [10:0] obs_row_rel = $signed({1'b0, y}) - $signed({1'b0, obstacle_y});

    wire is_obstacle_area = obstacle_active &&
                             (obs_col_rel >= -$signed({1'b0, obs_half_w})) && (obs_col_rel <= $signed({1'b0, obs_half_w})) &&
                             (obs_row_rel >= -$signed({1'b0, obs_half_h})) && (obs_row_rel <= $signed({1'b0, obs_half_h}));

    // Siluet kendaraan (dilihat dari belakang), dibagi 4 pita horizontal.
    wire signed [10:0] obs_top   = -$signed({1'b0, obs_half_h});
    wire signed [10:0] obs_bot   =  $signed({1'b0, obs_half_h});
    wire signed [10:0] obs_left  = -$signed({1'b0, obs_half_w});
    wire signed [10:0] obs_right =  $signed({1'b0, obs_half_w});

    wire signed [10:0] obs_row_off_s = obs_row_rel + $signed({1'b0, obs_half_h});
    wire [9:0] obs_row_off    = obs_row_off_s[9:0];
    wire [9:0] obs_quarter_h  = (obs_half_h > 10'd1) ? (obs_half_h >> 1) : 10'd1;
    wire [9:0] obs_half_hgt   = (obs_half_h > 10'd0) ? obs_half_h        : 10'd1;

    wire obs_band0 = obs_row_off <  obs_quarter_h;                                       // atap / helm
    wire obs_band1 = (obs_row_off >= obs_quarter_h) && (obs_row_off < obs_half_hgt);      // kaca / bahu
    wire obs_band2 = (obs_row_off >= obs_half_hgt)  && (obs_row_off < obs_half_hgt + obs_quarter_h); // bodi / jok
    wire obs_band3 = obs_row_off >= (obs_half_hgt + obs_quarter_h);                       // bumper / roda

    // ---- bagian mobil ----
    wire [9:0] obs_car_roof_w = (obs_half_w > (obs_half_w >> 2)) ? (obs_half_w - (obs_half_w >> 2)) : 10'd1;
    wire obs_car_roof = obstacle_is_car && obs_band0 &&
                        (obs_col_rel >= -$signed({1'b0, obs_car_roof_w})) &&
                        (obs_col_rel <=  $signed({1'b0, obs_car_roof_w}));

    wire [9:0] obs_car_win_w = (obs_half_w > 10'd1) ? (obs_half_w >> 1) : 10'd1;
    wire obs_car_window = obstacle_is_car && obs_band1 &&
                          (obs_col_rel >= -$signed({1'b0, obs_car_win_w})) &&
                          (obs_col_rel <=  $signed({1'b0, obs_car_win_w}));

    wire [9:0] obs_car_plate_w = (obs_half_w > 10'd2) ? (obs_half_w >> 2) : 10'd1;
    wire obs_car_plate = obstacle_is_car && obs_band3 &&
                         (obs_col_rel >= -$signed({1'b0, obs_car_plate_w})) &&
                         (obs_col_rel <=  $signed({1'b0, obs_car_plate_w}));

    wire [9:0] obs_car_light_w = (obs_half_w > 10'd3) ? (obs_half_w >> 2) : 10'd1;
    wire obs_car_taillight = obstacle_is_car && obs_band3 &&
                             (((obs_col_rel >= obs_left) && (obs_col_rel <= obs_left + $signed({1'b0, obs_car_light_w}))) ||
                              ((obs_col_rel <= obs_right) && (obs_col_rel >= obs_right - $signed({1'b0, obs_car_light_w}))));

    // ---- bagian motor ----
    wire [9:0] obs_moto_helmet_w = (obs_half_w > (obs_half_w >> 2)) ? (obs_half_w - (obs_half_w >> 2)) : 10'd1;
    wire obs_moto_helmet = !obstacle_is_car && obs_band0 &&
                          (obs_col_rel >= -$signed({1'b0, obs_moto_helmet_w})) &&
                          (obs_col_rel <=  $signed({1'b0, obs_moto_helmet_w}));

    wire obs_moto_shoulders = !obstacle_is_car && obs_band1;

    wire [9:0] obs_moto_seat_w = (obs_half_w > 10'd1) ? (obs_half_w >> 1) : 10'd1;
    wire obs_moto_seat = !obstacle_is_car && obs_band2 &&
                        (obs_col_rel >= -$signed({1'b0, obs_moto_seat_w})) &&
                        (obs_col_rel <=  $signed({1'b0, obs_moto_seat_w}));

    wire [9:0] obs_moto_wheel_w = (obs_half_w > 10'd1) ? (obs_half_w >> 1) : 10'd1;
    wire obs_moto_wheel = !obstacle_is_car && obs_band3 &&
                         (obs_col_rel >= -$signed({1'b0, obs_moto_wheel_w})) &&
                         (obs_col_rel <=  $signed({1'b0, obs_moto_wheel_w}));

    wire [9:0] obs_moto_light_w = (obs_half_w > 10'd2) ? (obs_half_w >> 2) : 10'd1;
    wire obs_moto_taillight = !obstacle_is_car && obs_band3 &&
                              (obs_row_off < (obs_half_hgt + obs_quarter_h) + (obs_quarter_h >> 1)) &&
                              (obs_col_rel >= -$signed({1'b0, obs_moto_light_w})) &&
                              (obs_col_rel <=  $signed({1'b0, obs_moto_light_w}));

    // ==== perspektif bintang bonus (sama dengan musuh, di jarak bonus) ====
    wire [9:0] dy_bonus                    = bonus_y - 10'd120;
    wire signed [13:0] curve_shift_bonus   = curve_shift_at(curve_amount, dy_bonus);
    wire signed [13:0] center_x_bonus_signed = $signed({1'b0, ROAD_CENTER_X}) + curve_shift_bonus;
    wire [9:0] road_half_bonus             = ROAD_HALF_FAR + (dy_bonus >> 1);

    wire signed [10:0] bonus_lane_offset = (bonus_lane == 2'd0) ? -$signed({1'b0, road_half_bonus}) >>> 1 :
                                            (bonus_lane == 2'd2) ?  $signed({1'b0, road_half_bonus}) >>> 1 :
                                                                     11'sd0;

    wire signed [10:0] bonus_x_signed = center_x_bonus_signed + bonus_lane_offset;
    wire [9:0] bonus_x = clamp_center_x(bonus_x_signed, 10'd25);
    wire [9:0] bonus_r = BONUS_BASE_R + (dy_bonus >> BONUS_SCALE_SHIFT);

    // star_at: bintang emas 4 sudut (badan belah ketupat + 4 duri).
    // Return: 0=bukan, 1=badan/duri, 2=inti terang.
    function [1:0] star_at;
        input [9:0] px, py;
        input [9:0] sx, sy;
        input [4:0] r;
        reg signed [10:0] ddx, ddy;
        reg [10:0] adx, ady;
        reg [10:0] thick, rr;
        reg [21:0] lhs_v, rhs_v, lhs_h, rhs_h; // perkalian dilebarin -- jalan buat semua pixel, ga boleh wrap
        reg core, body, vspike, hspike;
        begin
            ddx = $signed({1'b0, px}) - $signed({1'b0, sx});
            ddy = $signed({1'b0, py}) - $signed({1'b0, sy});
            adx = ddx[10] ? (-ddx) : ddx;
            ady = ddy[10] ? (-ddy) : ddy;
            rr    = {6'd0, r};
            thick = rr >> 2;
            if (thick < 11'd1) thick = 11'd1;

            core   = (adx + ady) <= (rr >> 2);
            body   = (adx + ady) <= (rr >> 1);

            lhs_v = {11'd0, adx}   * {11'd0, rr};
            rhs_v = {11'd0, thick} * {11'd0, (ady <= rr) ? (rr - ady) : 11'd0};
            lhs_h = {11'd0, ady}   * {11'd0, rr};
            rhs_h = {11'd0, thick} * {11'd0, (adx <= rr) ? (rr - adx) : 11'd0};

            vspike = (ady <= rr) && (lhs_v <= rhs_v);
            hspike = (adx <= rr) && (lhs_h <= rhs_h);

            if (core)
                star_at = 2'd2;
            else if (body || vspike || hspike)
                star_at = 2'd1;
            else
                star_at = 2'd0;
        end
    endfunction

    wire [1:0] bonus_shape  = bonus_active ? star_at(x, y, bonus_x, bonus_y, bonus_r[4:0]) : 2'd0;
    wire is_bonus_area = (bonus_shape != 2'd0);
    wire bonus_core    = (bonus_shape == 2'd2);
    wire bonus_body    = (bonus_shape == 2'd1);

    // ==== kotak tabrakan mobil vs musuh ====
    wire signed [10:0] obs_left_s   = $signed({1'b0, obstacle_x}) - $signed({1'b0, obs_half_w});
    wire signed [10:0] obs_right_s  = $signed({1'b0, obstacle_x}) + $signed({1'b0, obs_half_w});
    wire signed [10:0] obs_top_s    = $signed({1'b0, obstacle_y}) - $signed({1'b0, obs_half_h});
    wire signed [10:0] obs_bottom_s = $signed({1'b0, obstacle_y}) + $signed({1'b0, obs_half_h});

    // Hitbox mobil pakai margin (biar ga kena dari area kosong sprite).
    wire signed [10:0] car_left_s   = $signed({1'b0, CAR_X}) + $signed({1'b0, CAR_HITBOX_MARGIN_SIDE});
    wire signed [10:0] car_right_s  = $signed({1'b0, CAR_X}) + $signed({1'b0, CAR_W}) - $signed({1'b0, CAR_HITBOX_MARGIN_SIDE});
    wire signed [10:0] car_top_s    = $signed({1'b0, CAR_Y}) + $signed({1'b0, CAR_HITBOX_MARGIN_TOP});
    wire signed [10:0] car_bottom_s = $signed({1'b0, CAR_Y}) + $signed({1'b0, CAR_H}) - $signed({1'b0, CAR_HITBOX_MARGIN_BOTTOM});

    wire obstacle_car_overlap = obstacle_active &&
                                (obs_left_s   < car_right_s) && (obs_right_s  > car_left_s) &&
                                (obs_top_s    < car_bottom_s) && (obs_bottom_s > car_top_s);

    // Cuma tepi naik (baru mulai nyentuh) -- biar collision cuma 1 pulsa,
    // bukan puluhan frame selama kotak masih tumpang tindih.
    wire collision_edge = obstacle_car_overlap && !obstacle_overlap_prev;

    // ==== kotak tangkapan bintang ====
    wire signed [10:0] bonus_left_s   = $signed({1'b0, bonus_x}) - $signed({1'b0, bonus_r});
    wire signed [10:0] bonus_right_s  = $signed({1'b0, bonus_x}) + $signed({1'b0, bonus_r});
    wire signed [10:0] bonus_top_s    = $signed({1'b0, bonus_y}) - $signed({1'b0, bonus_r});
    wire signed [10:0] bonus_bottom_s = $signed({1'b0, bonus_y}) + $signed({1'b0, bonus_r});

    wire bonus_car_overlap = bonus_active &&
                              (bonus_left_s   < car_right_s) && (bonus_right_s  > car_left_s) &&
                              (bonus_top_s    < car_bottom_s) && (bonus_bottom_s > car_top_s);

    wire bonus_collision_edge = bonus_car_overlap && !bonus_overlap_prev;
    wire bonus_reached_end    = bonus_active && ((bonus_y + OBSTACLE_SPEED) >= OBS_Y_END);

    // ==================================================================
    // ================== FITUR BARU: kumpulan wire ====================
    // Semua identifier di sini udah dideklarasikan lebih atas, jadi blok
    // ini aman dikumpulin di satu tempat.
    // ==================================================================

    // ---- rival: perspektif & lajur (salinan pipeline musuh) ----
    wire [9:0] dy_rival                     = rival_y - 10'd120;
    wire signed [13:0] curve_shift_rival    = curve_shift_at(curve_amount, dy_rival);
    wire signed [13:0] center_x_rival_signed = $signed({1'b0, ROAD_CENTER_X}) + curve_shift_rival;
    wire [9:0] road_half_rival              = ROAD_HALF_FAR + (dy_rival >> 1);

    wire signed [10:0] rival_lane_offset = (rival_lane == 2'd0) ? -$signed({1'b0, road_half_rival}) >>> 1 :
                                            (rival_lane == 2'd2) ?  $signed({1'b0, road_half_rival}) >>> 1 :
                                                                     11'sd0;

    wire signed [10:0] rival_x_signed = center_x_rival_signed + rival_lane_offset;
    wire [9:0] rival_x = clamp_center_x(rival_x_signed, 10'd25);

    wire [9:0] riv_half_w = OBS_BASE_HALF_W + (dy_rival >> OBS_SCALE_SHIFT) + 10'd2;
    wire [9:0] riv_half_h = OBS_BASE_HALF_H + (dy_rival >> OBS_SCALE_SHIFT);

    wire signed [10:0] riv_col_rel = $signed({1'b0, x}) - $signed({1'b0, rival_x});
    wire signed [10:0] riv_row_rel = $signed({1'b0, y}) - $signed({1'b0, rival_y});

    wire is_rival_area = rival_active &&
                         (riv_col_rel >= -$signed({1'b0, riv_half_w})) && (riv_col_rel <= $signed({1'b0, riv_half_w})) &&
                         (riv_row_rel >= -$signed({1'b0, riv_half_h})) && (riv_row_rel <= $signed({1'b0, riv_half_h}));

    wire signed [10:0] riv_row_off_s = riv_row_rel + $signed({1'b0, riv_half_h});
    wire [9:0] riv_row_off   = riv_row_off_s[9:0];
    wire [9:0] riv_quarter_h = (riv_half_h > 10'd1) ? (riv_half_h >> 1) : 10'd1;
    wire [9:0] riv_half_hgt  = (riv_half_h > 10'd0) ? riv_half_h        : 10'd1;

    wire riv_band0 = riv_row_off <  riv_quarter_h;
    wire riv_band1 = (riv_row_off >= riv_quarter_h) && (riv_row_off < riv_half_hgt);
    wire riv_band3 = riv_row_off >= (riv_half_hgt + riv_quarter_h);

    wire [9:0] riv_roof_w  = (riv_half_w > (riv_half_w >> 2)) ? (riv_half_w - (riv_half_w >> 2)) : 10'd1;
    wire [9:0] riv_win_w   = (riv_half_w > 10'd1) ? (riv_half_w >> 1) : 10'd1;
    wire [9:0] riv_light_w = (riv_half_w > 10'd3) ? (riv_half_w >> 2) : 10'd1;
    wire [9:0] riv_plate_w = (riv_half_w > 10'd2) ? (riv_half_w >> 2) : 10'd1;

    wire riv_roof = riv_band0 &&
                    (riv_col_rel >= -$signed({1'b0, riv_roof_w})) &&
                    (riv_col_rel <=  $signed({1'b0, riv_roof_w}));
    wire riv_window = riv_band1 &&
                      (riv_col_rel >= -$signed({1'b0, riv_win_w})) &&
                      (riv_col_rel <=  $signed({1'b0, riv_win_w}));
    wire riv_plate = riv_band3 &&
                     (riv_col_rel >= -$signed({1'b0, riv_plate_w})) &&
                     (riv_col_rel <=  $signed({1'b0, riv_plate_w}));
    wire riv_taillight = riv_band3 &&
                         (((riv_col_rel <= -$signed({1'b0, riv_half_w}) + $signed({1'b0, riv_light_w}))) ||
                          ((riv_col_rel >=  $signed({1'b0, riv_half_w}) - $signed({1'b0, riv_light_w}))));

    // ---- rival: kotak tabrakan & tepi ----
    wire signed [10:0] riv_left_s   = $signed({1'b0, rival_x}) - $signed({1'b0, riv_half_w});
    wire signed [10:0] riv_right_s  = $signed({1'b0, rival_x}) + $signed({1'b0, riv_half_w});
    wire signed [10:0] riv_top_s    = $signed({1'b0, rival_y}) - $signed({1'b0, riv_half_h});
    wire signed [10:0] riv_bottom_s = $signed({1'b0, rival_y}) + $signed({1'b0, riv_half_h});

    wire rival_car_overlap = rival_active &&
                             (riv_left_s   < car_right_s)  && (riv_right_s  > car_left_s) &&
                             (riv_top_s    < car_bottom_s) && (riv_bottom_s > car_top_s);

    wire rival_collision_edge = rival_car_overlap && !rival_overlap_prev;
    wire rival_reached_end    = rival_active && ((rival_y + RIVAL_SPEED) >= OBS_Y_END);

    wire [1:0] rival_lane_raw   = obstacle_rand[4:3] ^ obstacle_rand[7:6];
    wire [1:0] rival_lane_pick0 = (rival_lane_raw == 2'd3) ? 2'd0 : rival_lane_raw;
    wire [1:0] rival_lane_pick  = (rival_lane_pick0 == obstacle_lane)
                                  ? ((rival_lane_pick0 == 2'd2) ? 2'd0 : (rival_lane_pick0 + 2'd1))
                                  : rival_lane_pick0;

    // Peluang traffic jadi VIP = 1/8. Mau VIP lebih sering muncul, ubah
    // pola bit ini (mis. == 3'd5 jadi cek 2 bit doang).
    wire next_is_vip = (obstacle_rand[7:5] == 3'd5);

    // ---- near-miss: kotak musuh diperlebar ----
    wire obstacle_near_overlap = obstacle_active &&
                                 (obs_left_s   - $signed({1'b0, NEAR_MARGIN_W}) < car_right_s)  &&
                                 (obs_right_s  + $signed({1'b0, NEAR_MARGIN_W}) > car_left_s)   &&
                                 (obs_top_s    - $signed({1'b0, NEAR_MARGIN_H}) < car_bottom_s) &&
                                 (obs_bottom_s + $signed({1'b0, NEAR_MARGIN_H}) > car_top_s);

    // Roll tipe pickup berikutnya: bintang nyawa vs nitro.
    wire next_is_nitro = obstacle_rand[6] ^ obstacle_rand[0];

    // ---- landmark: menara jam di kota (digambar manual, bukan via
    // building_at, biar bisa lebih tinggi dari gedung biasa) ----
    wire landmark_on = in_city_zone && landmark_active;

    localparam [9:0] LM_BASE_SY = TREE_Y_MIN + 10'd95;

    wire [9:0] lm_sy    = wrap_ty(LM_BASE_SY, scroll_y);
    wire [9:0] lm_dy    = lm_sy - TREE_Y_MIN;
    wire [9:0] lm_rhalf = ROAD_HALF_FAR + (lm_dy >> 1);

    wire signed [13:0] lm_cshift = curve_shift_at(curve_amount, lm_dy);
    wire signed [13:0] lm_censig = $signed({1'b0, ROAD_CENTER_X}) + lm_cshift;
    wire [9:0] lm_center = clamp_center_x(lm_censig, 10'd5);

    wire [9:0] lm_half   = 10'd8 + (lm_dy >> 4);
    wire [9:0] lm_height = (lm_half << 1) + (lm_half >> 1) + 10'd12;
    wire [9:0] lm_sx     = lm_center - lm_rhalf - TREE_GAP - SCEN_BASE_GAP - 10'd8 - lm_half;

    wire [9:0] lm_wall_top = lm_sy - lm_height;
    wire [9:0] lm_dx       = (x >= lm_sx) ? (x - lm_sx) : (lm_sx - x);
    wire       lm_is_lit   = (x < lm_sx);

    wire lm_in_body = landmark_on && (y >= 10'd120) &&
                      (y >= lm_wall_top) && (y <= lm_sy) && (lm_dx <= lm_half);

    wire [9:0] lm_clock_cy = lm_wall_top + lm_half + 10'd4;
    wire [9:0] lm_cdy      = (y >= lm_clock_cy) ? (y - lm_clock_cy) : (lm_clock_cy - y);
    wire [9:0] lm_clock_r  = (lm_half > 10'd3) ? (lm_half - 10'd2) : 10'd1;
    wire [10:0] lm_cdist   = {1'b0, lm_dx} + {1'b0, lm_cdy};

    wire lm_clock_face = lm_in_body && (lm_cdist <= {1'b0, lm_clock_r});
    wire lm_clock_ring = lm_clock_face && (lm_cdist + 11'd2 > {1'b0, lm_clock_r});
    wire lm_clock_dot  = lm_in_body && (lm_cdist <= 11'd1);

    wire lm_roof_px = lm_in_body && (y < lm_wall_top + 10'd3);
    wire [9:0] lm_ly = y - lm_wall_top;
    wire lm_window = lm_in_body && (y > lm_clock_cy + lm_clock_r + 10'd2) && (y < lm_sy - 10'd2) &&
                     (lm_dx[2:0] < 3'd2) && (lm_dx < lm_half - 10'd1) &&
                     (lm_ly[2:0] < 3'd2);

    // ---- hujan: garis diagonal jatuh ----
    // Mau hujan lebih deras/rapat, otak-atik pola hash & angka 4'd0 /
    // < 5'd18 di bawah.
    wire [9:0] rain_yy = y - rain_scroll;
    wire [9:0] rain_xx = x + (y >> 3);
    wire [4:0] rain_col_hash = rain_xx[4:0] ^ {rain_xx[7:6], rain_xx[8], 2'b00};
    wire rain_streak = rain_active && (rain_col_hash[4:1] == 4'd0) && (rain_yy[4:0] < 5'd18);

    // ---- salju: butiran kecil jatuh pelan (miring lawan arah hujan) ----
    wire [9:0] snow_yy = y - snow_scroll;
    wire [9:0] snow_xx = x - (snow_yy >> 4);
    wire [4:0] snow_col_hash = snow_xx[4:0] ^ {snow_xx[7:6], snow_xx[8], 2'b00} ^ {3'b0, snow_yy[7:6]};
    wire snow_flake = in_snow_zone && (snow_col_hash[4:1] == 4'd1) && (snow_yy[3:0] < 4'd2);

    // ---- debu belok tajam (di belakang mobil pas nyetir tajam) ----
    wire dust_time_ok = game_started && !game_over && (steer_left ^ steer_right);
    wire dust_band    = (y >= CAR_Y + CAR_H - 10'd22) && (y < CAR_Y + CAR_H + 10'd2);
    wire dust_side    = (steer_right && (x >= CAR_X + 10'd4)  && (x < CAR_X + 10'd30)) ||
                        (steer_left  && (x >= CAR_X + CAR_W - 10'd30) && (x < CAR_X + CAR_W - 10'd4));
    wire dust_pattern = (x[1] ^ anim_y[1] ^ shimmer_phase[0]) & (x[3] ^ anim_y[2]);
    wire dust_pixel   = dust_time_ok && dust_band && dust_side && dust_pattern;

    // ---- api nitro di belakang mobil ----
    wire nitro_flame_area = nitro_active && game_started && !game_over &&
                            (y >= CAR_Y + CAR_H - 10'd4) && (y < CAR_Y + CAR_H + 10'd10) &&
                            (x >= CAR_X + 10'd38) && (x < CAR_X + CAR_W - 10'd38);
    wire nitro_flame_hot  = (x[2] ^ y[1] ^ shimmer_phase[0]);

    // ---- confetti perayaan ----
    wire confetti_on = (celebrate_timer != 5'd0);
    wire confetti_px = confetti_on &&
                       (((x[4:0] ^ y[4:0] ^ shimmer_phase[4:0]) == 5'd0) ||
                        ((x[4:0] + y[4:0] + shimmer_phase[4:0]) == 6'd7));

    // ---- pixel yang TETAP terang di kota malam ----
    // Jendela/lampu/pickup/mobil pemain ga ikut digelapin, biar kontras.
    wire night_keep_bright = building_window || market_window || market_sign || house_window ||
                             lm_clock_face || lm_window ||
                             is_bonus_area ||
                             (is_obstacle_area && (obs_car_taillight || obs_moto_taillight)) ||
                             (is_rival_area && riv_taillight) ||
                             (is_car_area && car_rgb != 24'hFFFFFF) ||
                             (nitro_flame_area && nitro_flame_hot);

    // ==== POIN ====
    // POINTS_PER_DODGE = poin tiap sukses ngehindar 1 musuh.
    localparam [15:0] POINTS_PER_DODGE = 16'd10;

    // ==== COMBO ====
    // Ngehindar beruntun (tanpa nabrak) = bonus makin gede, mentok di cap.
    //   COMBO_BONUS_STEP = tambahan poin per level combo
    //   COMBO_BONUS_CAP  = maksimal bonus per satu dodge
    localparam [15:0] COMBO_BONUS_STEP = 16'd2;
    localparam [15:0] COMBO_BONUS_CAP  = 16'd50;

    reg [7:0] combo_count;
    initial combo_count = 8'd0;

    wire [15:0] combo_bonus_raw = {8'd0, combo_count} * COMBO_BONUS_STEP;
    wire [15:0] combo_bonus     = (combo_bonus_raw > COMBO_BONUS_CAP) ? COMBO_BONUS_CAP : combo_bonus_raw;

    // ==== recap run terakhir (buat layar START berikutnya) ====
    // last_run_score & has_played_once SENGAJA ga direset -- biar bertahan
    // melewati reset yang terjadi tepat setelah game over.
    reg [15:0] last_run_score;
    reg        has_played_once;
    initial last_run_score  = 16'd0;
    initial has_played_once = 1'b0;

    // ==================================================================
    // ==== LOGIKA GAME UTAMA (skor, nyawa, spawn musuh/pickup/rival) ====
    // Ini otak permainannya. Jalan sekali per frame (x==0 && y==0).
    // ==================================================================
    always @(posedge clk) begin
        if (reset) begin
            obstacle_y            <= OBS_Y_START;
            obstacle_lane         <= 2'd0;
            obstacle_is_car       <= 1'b1;
            obstacle_rand         <= 8'hA5;   // seed non-zero (LFSR nol nyangkut)
            obstacle_overlap_prev <= 1'b0;
            obstacle_active       <= 1'b1;
            obstacle_spawn_timer  <= 16'd0;
            collision             <= 1'b0;
            score                 <= 16'd0;
            game_over              <= 1'b0;
            combo_count            <= 8'd0;
            lives                  <= LIVES_START;
            bonus_active           <= 1'b0;
            bonus_y                <= OBS_Y_START;
            bonus_lane             <= 2'd1;
            bonus_overlap_prev     <= 1'b0;
            bonus_spawn_timer      <= BONUS_SPAWN_INTERVAL;
            bonus_is_nitro         <= 1'b0;
            nitro_timer            <= 16'd0;
            rival_active           <= 1'b0;
            rival_y                <= OBS_Y_START;
            rival_lane             <= 2'd0;
            rival_overlap_prev     <= 1'b0;
            rival_spawn_timer      <= RIVAL_SPAWN_INTERVAL;
            rival_is_vip           <= 1'b0;
            near_miss_latch        <= 1'b0;
        end else if (x == 10'd0 && y == 10'd0 && game_started) begin   // sekali per frame, cuma setelah start
            // LFSR 8-bit (taps 8,6,5,4) buat angka acak lajur/tipe.
            obstacle_rand <= {obstacle_rand[6:0],
                               obstacle_rand[7] ^ obstacle_rand[5] ^ obstacle_rand[4] ^ obstacle_rand[3]};
            obstacle_overlap_prev <= obstacle_car_overlap;
            rival_overlap_prev    <= rival_car_overlap;
            // collision keluar = nabrak musuh ATAU nabrak rival.
            collision <= collision_edge || rival_collision_edge;

            if (nitro_timer != 16'd0)
                nitro_timer <= nitro_timer - 16'd1;

            if (!game_over) begin
                // Nabrak = -1 nyawa & -poin (poin turun otomatis nurunin
                // kesulitan juga). game_over cuma pas nyawa habis.
                if (collision_edge) begin
                    combo_count <= 8'd0;
                    score       <= (score >= LIFE_LOST_PENALTY) ? (score - LIFE_LOST_PENALTY) : 16'd0;

                    if (lives <= 3'd1) begin
                        lives           <= 3'd0;
                        game_over       <= 1'b1;
                        last_run_score  <= score;
                        has_played_once <= 1'b1;
                    end else begin
                        lives <= lives - 3'd1;
                    end
                end else if (obstacle_reached_end) begin
                    // Sukses lewat musuh -> poin (dasar + combo + bonus
                    // near-miss kalau lewatnya mepet) + combo nambah.
                    score       <= score + POINTS_PER_DODGE + combo_bonus
                                   + (near_miss_latch ? NEAR_MISS_BONUS : 16'd0);
                    combo_count <= combo_count + 8'd1;
                end

                // Catat near-miss (kotak lebar nyentuh tapi kotak asli enggak).
                if (obstacle_near_overlap && !obstacle_car_overlap)
                    near_miss_latch <= 1'b1;

                // Musuh habis -> non-aktif dulu OBSTACLE_SPAWN_GAP frame
                // (jeda napas), baru respawn.
                if (collision_edge || obstacle_reached_end) begin
                    obstacle_active        <= 1'b0;
                    obstacle_spawn_timer   <= OBSTACLE_SPAWN_GAP;
                    obstacle_overlap_prev  <= 1'b0;
                    near_miss_latch        <= 1'b0;
                end else if (!obstacle_active) begin
                    if (obstacle_spawn_timer <= 16'd1) begin
                        obstacle_active  <= 1'b1;
                        obstacle_y       <= OBS_Y_START;
                        obstacle_lane    <= obstacle_next_lane;
                        obstacle_is_car  <= next_is_car;
                    end else begin
                        obstacle_spawn_timer <= obstacle_spawn_timer - 16'd1;
                    end
                end else begin
                    obstacle_y <= obstacle_y + OBSTACLE_SPEED;
                end

                // ---- pickup bintang/nitro (spawn & timer sendiri) ----
                bonus_overlap_prev <= bonus_car_overlap;

                if (bonus_active) begin
                    if (bonus_collision_edge) begin
                        bonus_active       <= 1'b0;
                        bonus_spawn_timer  <= BONUS_SPAWN_INTERVAL;
                        if (bonus_is_nitro) begin
                            nitro_timer <= NITRO_DURATION;
                            score       <= score + NITRO_PICKUP_SCORE;
                        end else if (lives < LIVES_MAX)
                            lives <= lives + 3'd1;
                    end else if (bonus_reached_end) begin
                        bonus_active      <= 1'b0;
                        bonus_spawn_timer <= BONUS_SPAWN_INTERVAL;
                    end else begin
                        bonus_y <= bonus_y + OBSTACLE_SPEED;
                    end
                end else begin
                    if (bonus_spawn_timer <= 16'd1) begin
                        bonus_active           <= 1'b1;
                        bonus_y                <= OBS_Y_START;
                        bonus_lane             <= next_lane;
                        bonus_is_nitro         <= next_is_nitro;
                        bonus_overlap_prev     <= 1'b0;
                    end else begin
                        bonus_spawn_timer <= bonus_spawn_timer - 16'd1;
                    end
                end

                // ---- rival/traffic (ditaruh terakhir on purpose: kalau
                // dua event nyentuh register sama di frame yang sama,
                // yang menang assignment terakhir = prioritas hukuman
                // tabrakan, itu yang kita mau) ----
                if (rival_active) begin
                    if (rival_collision_edge) begin
                        // Nabrak rival = seberat nabrak rintangan.
                        combo_count  <= 8'd0;
                        score        <= (score >= LIFE_LOST_PENALTY) ? (score - LIFE_LOST_PENALTY) : 16'd0;
                        if (lives <= 3'd1) begin
                            lives           <= 3'd0;
                            game_over       <= 1'b1;
                            last_run_score  <= score;
                            has_played_once <= 1'b1;
                        end else begin
                            lives <= lives - 3'd1;
                        end
                        rival_active      <= 1'b0;
                        rival_spawn_timer <= RIVAL_SPAWN_INTERVAL;
                    end else if (rival_reached_end) begin
                        // Berhasil DISALIP -> bonus poin (VIP jauh lebih gede).
                        score        <= score
                                        + (rival_is_vip ? POINTS_PER_VIP : POINTS_PER_OVERTAKE)
                                        + combo_bonus;
                        combo_count  <= combo_count + 8'd1;
                        rival_active      <= 1'b0;
                        rival_spawn_timer <= RIVAL_SPAWN_INTERVAL;
                    end else begin
                        rival_y <= rival_y + RIVAL_SPEED;
                    end
                end else begin
                    if (rival_spawn_timer <= 16'd1) begin
                        rival_active       <= 1'b1;
                        rival_y            <= OBS_Y_START;
                        rival_lane         <= rival_lane_pick;
                        rival_is_vip       <= next_is_vip;
                        rival_overlap_prev <= 1'b0;
                    end else begin
                        rival_spawn_timer <= rival_spawn_timer - 16'd1;
                    end
                end
            end
            // kalau game_over udah tinggi, semua beku sampai reset.
        end else if (x == 10'd0 && y == 10'd0) begin
            // Belum start: collision tetap di-clear biar ga nyangkut.
            collision <= 1'b0;
        end else begin
            collision <= 1'b0;   // collision cuma tinggi 1 clock tepat di frame tick tadi
        end
    end

    // ==== fade layar ke hitam pas game over ====
    // Gedein FADE_MAX = fade lebih gelap; FADE_STEP = kecepatan fade.
    localparam [3:0] FADE_MAX  = 4'd15;
    localparam [3:0] FADE_STEP = 4'd1;

    reg [3:0] fade_level;
    initial fade_level = 4'd0;

    wire [3:0] fade_target = game_over ? FADE_MAX : 4'd0;

    always @(posedge clk) begin
        if (x == 10'd0 && y == 10'd0) begin   // sekali per frame
            if (fade_level < fade_target)
                fade_level <= fade_level + FADE_STEP;
            else if (fade_level > fade_target)
                fade_level <= fade_level - FADE_STEP;
        end
    end

    // ==== update semua efek visual per frame ====
    // Semua di sini cuma buat pewarnaan, ga nyentuh state game -- aman
    // di-tune sesuka hati. Angka-angka kayak 4'd12, 5'd28, dst =
    // seberapa lama/kuat tiap efek.
    always @(posedge clk) begin
        if (reset) begin
            hit_flash          <= 4'd0;
            nm_flash           <= 4'd0;
            celebrate_timer    <= 5'd0;
            milestone_target   <= MILESTONE_STEP;
            rain_scroll        <= 10'd0;
            snow_scroll        <= 10'd0;
            lightning_flash    <= 4'd0;
            lightning_cooldown <= 10'd90;
            shake_timer        <= 4'd0;
            shake_offset_x     <= 3'sd0;
            shake_offset_y     <= 3'sd0;
        end else if (x == 10'd0 && y == 10'd0) begin   // sekali per frame
            // Flash merah pas nabrak (4'd12 = kekuatan awal).
            if (game_started && !game_over && (collision_edge || rival_collision_edge))
                hit_flash <= 4'd12;
            else if (hit_flash != 4'd0)
                hit_flash <= hit_flash - 4'd1;

            // Shake HUD pas nabrak.
            if (game_started && !game_over && (collision_edge || rival_collision_edge))
                shake_timer <= 4'd10;
            else if (shake_timer != 4'd0)
                shake_timer <= shake_timer - 4'd1;

            if (shake_timer != 4'd0) begin
                shake_offset_x <= (obstacle_rand[1] ? 3'sd1 : -3'sd1) * $signed({1'b0, shake_timer[3:2]});
                shake_offset_y <= (obstacle_rand[3] ? 3'sd1 : -3'sd1) * $signed({1'b0, shake_timer[3:2]});
            end else begin
                shake_offset_x <= 3'sd0;
                shake_offset_y <= 3'sd0;
            end

            // Kilatan emas near-miss / VIP disalip.
            if (game_started && !game_over && obstacle_reached_end &&
                near_miss_latch && !collision_edge)
                nm_flash <= 4'd8;
            else if (game_started && !game_over && rival_reached_end &&
                     rival_is_vip && !rival_collision_edge)
                nm_flash <= 4'd12;
            else if (nm_flash != 4'd0)
                nm_flash <= nm_flash - 4'd1;

            // Confetti: pas nyalip VIP, atau pas skor lewat kelipatan 1000.
            if (game_started && !game_over && rival_reached_end &&
                rival_is_vip && !rival_collision_edge) begin
                celebrate_timer <= 5'd28;
            end else if (score >= milestone_target) begin
                celebrate_timer  <= 5'd28;
                milestone_target <= milestone_target + MILESTONE_STEP;
            end else if (celebrate_timer != 5'd0) begin
                celebrate_timer <= celebrate_timer - 5'd1;
            end

            // Hujan jatuh ~10px/frame (jalan terus walau ga hujan, murah).
            rain_scroll <= rain_scroll + 10'd10;

            // Salju jatuh jauh lebih pelan (3px/frame).
            snow_scroll <= snow_scroll + 10'd3;

            // Langit terus geser -- ga digating, jadi burung & awan tetap
            // jalan di layar START & game over.
            sky_scroll  <= (sky_scroll >= 12'd2559) ? 12'd0 : (sky_scroll + 12'd1);

            // Petir: peluang kecil (1/8) tiap frame pas hujan & cooldown habis.
            if (lightning_cooldown != 10'd0)
                lightning_cooldown <= lightning_cooldown - 10'd1;

            if (lightning_cooldown == 10'd0 && rain_active &&
                (obstacle_rand[2:0] == 3'd0)) begin
                lightning_flash    <= 4'd14;
                lightning_cooldown <= {2'b0, obstacle_rand} + 10'd120;
            end else if (lightning_flash != 4'd0) begin
                lightning_flash <= lightning_flash - 4'd1;
            end
        end
    end

    // ==== high score (SENGAJA ga direset -- nyimpen rekor selama board
    // masih nyala) ====
    reg [15:0] high_score;
    initial high_score = 16'd0;

    always @(posedge clk) begin
        if (score > high_score)
            high_score <= score;
    end

    // ==== ROM sprite mobil (lurus / serong kiri / serong kanan) ====
    // Mau ganti gambar mobil? Ganti file .mif yang di-load ROM ini
    // (car_rom / car_rom_left / car_rom_right), bukan di sini.
    wire [23:0] car_rgb_straight, car_rgb_left, car_rgb_right;
    wire [23:0] car_rgb;

    car_rom my_car_rom (
        .address (rom_addr),
        .clock   (clk),
        .q       (car_rgb_straight)
    );

    car_rom_left my_car_rom_left (
        .address (rom_addr),
        .clock   (clk),
        .q       (car_rgb_left)
    );

    car_rom_right my_car_rom_right (
        .address (rom_addr),
        .clock   (clk),
        .q       (car_rgb_right)
    );

    assign car_rgb = turn_left_active  ? car_rgb_left  :
                      turn_right_active ? car_rgb_right :
                                          car_rgb_straight;

    // ==================================================================
    // ==== HUD: font 5x7 buatan sendiri + panel skor/nyawa/dll ====
    // ==================================================================

    // glyph_row: kembalikan pola 5-bit satu baris huruf. Ini "font"-nya,
    // di-hardcode. Mau ubah bentuk huruf, edit pola bit di case-nya.
    // Kode huruf: 0-9=angka, 10=G 11=A 12=M 13=E 14=O 15=V 16=R 17=spasi
    // 18=H 19=I 20=S 21=T 22=L 23=B 24=D.
    function [4:0] glyph_row;
        input [4:0] chsel;
        input [2:0] row;
        reg [4:0] r;
        begin
            case (chsel)
                5'd0: case(row) // '0'
                    3'd0: r=5'b01110; 3'd1: r=5'b10001; 3'd2: r=5'b10011; 3'd3: r=5'b10101;
                    3'd4: r=5'b11001; 3'd5: r=5'b10001; 3'd6: r=5'b01110; default: r=5'b00000;
                    endcase
                5'd1: case(row) // '1'
                    3'd0: r=5'b00100; 3'd1: r=5'b01100; 3'd2: r=5'b00100; 3'd3: r=5'b00100;
                    3'd4: r=5'b00100; 3'd5: r=5'b00100; 3'd6: r=5'b01110; default: r=5'b00000;
                    endcase
                5'd2: case(row) // '2'
                    3'd0: r=5'b01110; 3'd1: r=5'b10001; 3'd2: r=5'b00001; 3'd3: r=5'b00010;
                    3'd4: r=5'b00100; 3'd5: r=5'b01000; 3'd6: r=5'b11111; default: r=5'b00000;
                    endcase
                5'd3: case(row) // '3'
                    3'd0: r=5'b11111; 3'd1: r=5'b00010; 3'd2: r=5'b00100; 3'd3: r=5'b00010;
                    3'd4: r=5'b00001; 3'd5: r=5'b10001; 3'd6: r=5'b01110; default: r=5'b00000;
                    endcase
                5'd4: case(row) // '4'
                    3'd0: r=5'b00010; 3'd1: r=5'b00110; 3'd2: r=5'b01010; 3'd3: r=5'b10010;
                    3'd4: r=5'b11111; 3'd5: r=5'b00010; 3'd6: r=5'b00010; default: r=5'b00000;
                    endcase
                5'd5: case(row) // '5'
                    3'd0: r=5'b11111; 3'd1: r=5'b10000; 3'd2: r=5'b11110; 3'd3: r=5'b00001;
                    3'd4: r=5'b00001; 3'd5: r=5'b10001; 3'd6: r=5'b01110; default: r=5'b00000;
                    endcase
                5'd6: case(row) // '6'
                    3'd0: r=5'b00110; 3'd1: r=5'b01000; 3'd2: r=5'b10000; 3'd3: r=5'b11110;
                    3'd4: r=5'b10001; 3'd5: r=5'b10001; 3'd6: r=5'b01110; default: r=5'b00000;
                    endcase
                5'd7: case(row) // '7'
                    3'd0: r=5'b11111; 3'd1: r=5'b00001; 3'd2: r=5'b00010; 3'd3: r=5'b00100;
                    3'd4: r=5'b01000; 3'd5: r=5'b01000; 3'd6: r=5'b01000; default: r=5'b00000;
                    endcase
                5'd8: case(row) // '8'
                    3'd0: r=5'b01110; 3'd1: r=5'b10001; 3'd2: r=5'b10001; 3'd3: r=5'b01110;
                    3'd4: r=5'b10001; 3'd5: r=5'b10001; 3'd6: r=5'b01110; default: r=5'b00000;
                    endcase
                5'd9: case(row) // '9'
                    3'd0: r=5'b01110; 3'd1: r=5'b10001; 3'd2: r=5'b10001; 3'd3: r=5'b01111;
                    3'd4: r=5'b00001; 3'd5: r=5'b00010; 3'd6: r=5'b11100; default: r=5'b00000;
                    endcase
                5'd10: case(row) // 'G'
                    3'd0: r=5'b01110; 3'd1: r=5'b10001; 3'd2: r=5'b10000; 3'd3: r=5'b10111;
                    3'd4: r=5'b10001; 3'd5: r=5'b10001; 3'd6: r=5'b01111; default: r=5'b00000;
                    endcase
                5'd11: case(row) // 'A'
                    3'd0: r=5'b01110; 3'd1: r=5'b10001; 3'd2: r=5'b10001; 3'd3: r=5'b11111;
                    3'd4: r=5'b10001; 3'd5: r=5'b10001; 3'd6: r=5'b10001; default: r=5'b00000;
                    endcase
                5'd12: case(row) // 'M'
                    3'd0: r=5'b10001; 3'd1: r=5'b11011; 3'd2: r=5'b10101; 3'd3: r=5'b10101;
                    3'd4: r=5'b10001; 3'd5: r=5'b10001; 3'd6: r=5'b10001; default: r=5'b00000;
                    endcase
                5'd13: case(row) // 'E'
                    3'd0: r=5'b11111; 3'd1: r=5'b10000; 3'd2: r=5'b10000; 3'd3: r=5'b11110;
                    3'd4: r=5'b10000; 3'd5: r=5'b10000; 3'd6: r=5'b11111; default: r=5'b00000;
                    endcase
                5'd14: case(row) // 'O'
                    3'd0: r=5'b01110; 3'd1: r=5'b10001; 3'd2: r=5'b10001; 3'd3: r=5'b10001;
                    3'd4: r=5'b10001; 3'd5: r=5'b10001; 3'd6: r=5'b01110; default: r=5'b00000;
                    endcase
                5'd15: case(row) // 'V'
                    3'd0: r=5'b10001; 3'd1: r=5'b10001; 3'd2: r=5'b10001; 3'd3: r=5'b10001;
                    3'd4: r=5'b10001; 3'd5: r=5'b01010; 3'd6: r=5'b00100; default: r=5'b00000;
                    endcase
                5'd16: case(row) // 'R'
                    3'd0: r=5'b11110; 3'd1: r=5'b10001; 3'd2: r=5'b10001; 3'd3: r=5'b11110;
                    3'd4: r=5'b10100; 3'd5: r=5'b10010; 3'd6: r=5'b10001; default: r=5'b00000;
                    endcase
                5'd18: case(row) // 'H'
                    3'd0: r=5'b10001; 3'd1: r=5'b10001; 3'd2: r=5'b10001; 3'd3: r=5'b11111;
                    3'd4: r=5'b10001; 3'd5: r=5'b10001; 3'd6: r=5'b10001; default: r=5'b00000;
                    endcase
                5'd19: case(row) // 'I'
                    3'd0: r=5'b01110; 3'd1: r=5'b00100; 3'd2: r=5'b00100; 3'd3: r=5'b00100;
                    3'd4: r=5'b00100; 3'd5: r=5'b00100; 3'd6: r=5'b01110; default: r=5'b00000;
                    endcase
                5'd20: case(row) // 'S'
                    3'd0: r=5'b01111; 3'd1: r=5'b10000; 3'd2: r=5'b10000; 3'd3: r=5'b01110;
                    3'd4: r=5'b00001; 3'd5: r=5'b00001; 3'd6: r=5'b11110; default: r=5'b00000;
                    endcase
                5'd21: case(row) // 'T'
                    3'd0: r=5'b11111; 3'd1: r=5'b00100; 3'd2: r=5'b00100; 3'd3: r=5'b00100;
                    3'd4: r=5'b00100; 3'd5: r=5'b00100; 3'd6: r=5'b00100; default: r=5'b00000;
                    endcase
                5'd22: case(row) // 'L'
                    3'd0: r=5'b10000; 3'd1: r=5'b10000; 3'd2: r=5'b10000; 3'd3: r=5'b10000;
                    3'd4: r=5'b10000; 3'd5: r=5'b10000; 3'd6: r=5'b11111; default: r=5'b00000;
                    endcase
                5'd23: case(row) // 'B'
                    3'd0: r=5'b11110; 3'd1: r=5'b10001; 3'd2: r=5'b10001; 3'd3: r=5'b11110;
                    3'd4: r=5'b10001; 3'd5: r=5'b10001; 3'd6: r=5'b11110; default: r=5'b00000;
                    endcase
                5'd24: case(row) // 'D'
                    3'd0: r=5'b11110; 3'd1: r=5'b10001; 3'd2: r=5'b10001; 3'd3: r=5'b10001;
                    3'd4: r=5'b10001; 3'd5: r=5'b10001; 3'd6: r=5'b11110; default: r=5'b00000;
                    endcase
                default: r = 5'b00000; // 17 = spasi / lainnya
            endcase
            glyph_row = r;
        end
    endfunction

    // Ikon hati 7x6 buat panel nyawa (bitmap hardcode).
    function [6:0] heart_row_bits;
        input [2:0] row;
        reg [6:0] r;
        begin
            case (row)
                3'd0: r = 7'b0110110;
                3'd1: r = 7'b1111111;
                3'd2: r = 7'b1111111;
                3'd3: r = 7'b0111110;
                3'd4: r = 7'b0011100;
                3'd5: r = 7'b0001000;
                default: r = 7'b0000000;
            endcase
            heart_row_bits = r;
        end
    endfunction

    // Huruf apa di tiap slot "GAME OVER".
    function [4:0] gameover_char;
        input [3:0] idx;
        begin
            case (idx)
                4'd0: gameover_char = 5'd10; // G
                4'd1: gameover_char = 5'd11; // A
                4'd2: gameover_char = 5'd12; // M
                4'd3: gameover_char = 5'd13; // E
                4'd4: gameover_char = 5'd17; // spasi
                4'd5: gameover_char = 5'd14; // O
                4'd6: gameover_char = 5'd15; // V
                4'd7: gameover_char = 5'd13; // E
                4'd8: gameover_char = 5'd16; // R
                default: gameover_char = 5'd17;
            endcase
        end
    endfunction

    // Huruf apa di tiap slot "START".
    function [4:0] start_char;
        input [3:0] idx;
        begin
            case (idx)
                4'd0: start_char = 5'd20; // S
                4'd1: start_char = 5'd21; // T
                4'd2: start_char = 5'd11; // A
                4'd3: start_char = 5'd16; // R
                4'd4: start_char = 5'd21; // T
                default: start_char = 5'd17;
            endcase
        end
    endfunction

    // Countdown / "GO!".
    function [4:0] countdown_char;
        input [3:0] idx;
        begin
            if (countdown_active) begin
                case (idx)
                    4'd0: countdown_char = {3'b0, countdown_num}; // '3','2','1'
                    default: countdown_char = 5'd17;
                endcase
            end else begin
                case (idx)
                    4'd0: countdown_char = 5'd10; // G
                    4'd1: countdown_char = 5'd14; // O
                    default: countdown_char = 5'd17;
                endcase
            end
        end
    endfunction

    // "AREA n" buat badge zona.
    function [4:0] badge_char;
        input [3:0] idx;
        begin
            case (idx)
                4'd0: badge_char = 5'd11; // A
                4'd1: badge_char = 5'd16; // R
                4'd2: badge_char = 5'd13; // E
                4'd3: badge_char = 5'd11; // A
                default: badge_char = {3'b0, zone_id} + 5'd1; // '1'..'4'
            endcase
        end
    endfunction

    // "LAST"/"BEST" + digit buat recap.
    function [4:0] recap_char;
        input        is_best;
        input [3:0]  idx;
        input [3:0]  digit_val;
        begin
            if (idx < 4'd4) begin
                if (is_best) begin
                    case (idx)
                        4'd0: recap_char = 5'd23; // B
                        4'd1: recap_char = 5'd13; // E
                        4'd2: recap_char = 5'd20; // S
                        default: recap_char = 5'd21; // T
                    endcase
                end else begin
                    case (idx)
                        4'd0: recap_char = 5'd22; // L
                        4'd1: recap_char = 5'd11; // A
                        4'd2: recap_char = 5'd20; // S
                        default: recap_char = 5'd21; // T
                    endcase
                end
            end else begin
                recap_char = {1'b0, digit_val};
            end
        end
    endfunction

    // bin_to_bcd: ubah angka biner 16-bit jadi 5 digit desimal (buat
    // ditampilin per digit). Double-dabble, murni kombinasional.
    function [19:0] bin_to_bcd;
        input [15:0] bin;
        integer i;
        reg [15:0] shifted;
        reg [19:0] bcd;
        begin
            bcd = 20'd0;
            shifted = bin;
            for (i = 0; i < 16; i = i + 1) begin
                if (bcd[3:0]   >= 5) bcd[3:0]   = bcd[3:0]   + 3;
                if (bcd[7:4]   >= 5) bcd[7:4]   = bcd[7:4]   + 3;
                if (bcd[11:8]  >= 5) bcd[11:8]  = bcd[11:8]  + 3;
                if (bcd[15:12] >= 5) bcd[15:12] = bcd[15:12] + 3;
                if (bcd[19:16] >= 5) bcd[19:16] = bcd[19:16] + 3;
                bcd     = {bcd[18:0], shifted[15]};
                shifted = {shifted[14:0], 1'b0};
            end
            bin_to_bcd = bcd;
        end
    endfunction

    wire [19:0] score_bcd      = bin_to_bcd(score);
    wire [19:0] high_score_bcd = bin_to_bcd(high_score);
    wire [19:0] last_score_bcd = bin_to_bcd(last_run_score);
    wire [19:0] dist_bcd       = bin_to_bcd(distance_traveled[15:0]);

    // Koordinat HUD yang digoyang shake (cuma panel yang mau ikut
    // goyang pas nabrak yang pakai x_hud/y_hud).
    wire signed [10:0] x_shaken_s = $signed({1'b0, x}) - {{8{shake_offset_x[2]}}, shake_offset_x};
    wire signed [10:0] y_shaken_s = $signed({1'b0, y}) - {{8{shake_offset_y[2]}}, shake_offset_y};
    wire [9:0] x_hud = (x_shaken_s < 11'sd0) ? 10'd0 : x_shaken_s[9:0];
    wire [9:0] y_hud = (y_shaken_s < 11'sd0) ? 10'd0 : y_shaken_s[9:0];

    // ==== panel SKOR (kiri atas) ====
    // SCORE_X0/Y0 = posisi; SCORE_CELL = ukuran per digit.
    localparam SCORE_X0 = 10'd20;
    localparam SCORE_Y0 = 10'd14;
    localparam SCORE_DIGITS = 4'd5;
    localparam SCORE_CELL = 10'd16;

    localparam SCORE_PANEL_MARGIN = 10'd6;
    localparam SCORE_BORDER_THICK = 10'd2;

    wire [9:0] score_box_w = SCORE_DIGITS * SCORE_CELL;
    wire [9:0] score_box_h = SCORE_CELL;

    wire in_score_box = (x_hud >= SCORE_X0) && (x_hud < SCORE_X0 + score_box_w) &&
                        (y_hud >= SCORE_Y0) && (y_hud < SCORE_Y0 + score_box_h);

    wire in_score_panel = (x_hud >= SCORE_X0 - SCORE_PANEL_MARGIN) && (x_hud < SCORE_X0 + score_box_w + SCORE_PANEL_MARGIN) &&
                          (y_hud >= SCORE_Y0 - SCORE_PANEL_MARGIN) && (y_hud < SCORE_Y0 + score_box_h + SCORE_PANEL_MARGIN);

    wire in_score_border = in_score_panel &&
                           ((x_hud < SCORE_X0 - SCORE_PANEL_MARGIN + SCORE_BORDER_THICK) ||
                            (x_hud >= SCORE_X0 + score_box_w + SCORE_PANEL_MARGIN - SCORE_BORDER_THICK) ||
                            (y_hud < SCORE_Y0 - SCORE_PANEL_MARGIN + SCORE_BORDER_THICK) ||
                            (y_hud >= SCORE_Y0 + score_box_h + SCORE_PANEL_MARGIN - SCORE_BORDER_THICK));

    wire [9:0] score_xrel = x_hud - SCORE_X0;
    wire [9:0] score_yrel = y_hud - SCORE_Y0;
    wire [3:0] score_digit_idx = score_xrel[9:4];
    wire [2:0] score_col       = score_xrel[3:0] >> 1;
    wire [2:0] score_row       = score_yrel[3:0] >> 1;

    wire [3:0] score_digit_val = (score_digit_idx == 4'd0) ? score_bcd[19:16] :
                                  (score_digit_idx == 4'd1) ? score_bcd[15:12] :
                                  (score_digit_idx == 4'd2) ? score_bcd[11:8]  :
                                  (score_digit_idx == 4'd3) ? score_bcd[7:4]   :
                                                              score_bcd[3:0];

    wire [4:0] score_glyph_row = glyph_row({1'b0, score_digit_val}, score_row[2:0]);
    wire score_glyph_bit = in_score_box && (score_col < 3'd5) && (score_row < 3'd7) &&
                            score_glyph_row[4 - score_col];

    // ==== panel HIGH SCORE ("HI" + 5 digit, di bawah skor) ====
    localparam HI_LABEL_CHARS = 4'd2;
    localparam HI_DIGITS      = 4'd5;
    localparam HI_CELL        = 10'd16;
    localparam HI_X0 = SCORE_X0;
    localparam HI_Y0 = 10'd38;

    wire [9:0] hi_box_w = (HI_LABEL_CHARS + HI_DIGITS) * HI_CELL;
    wire [9:0] hi_box_h = HI_CELL;

    wire in_hi_box = (x_hud >= HI_X0) && (x_hud < HI_X0 + hi_box_w) &&
                     (y_hud >= HI_Y0) && (y_hud < HI_Y0 + hi_box_h);

    wire in_hi_panel = (x_hud >= HI_X0 - SCORE_PANEL_MARGIN) && (x_hud < HI_X0 + hi_box_w + SCORE_PANEL_MARGIN) &&
                       (y_hud >= HI_Y0 - SCORE_PANEL_MARGIN) && (y_hud < HI_Y0 + hi_box_h + SCORE_PANEL_MARGIN);

    wire in_hi_border = in_hi_panel &&
                        ((x_hud < HI_X0 - SCORE_PANEL_MARGIN + SCORE_BORDER_THICK) ||
                         (x_hud >= HI_X0 + hi_box_w + SCORE_PANEL_MARGIN - SCORE_BORDER_THICK) ||
                         (y_hud < HI_Y0 - SCORE_PANEL_MARGIN + SCORE_BORDER_THICK) ||
                         (y_hud >= HI_Y0 + hi_box_h + SCORE_PANEL_MARGIN - SCORE_BORDER_THICK));

    wire [9:0] hi_xrel = x_hud - HI_X0;
    wire [9:0] hi_yrel = y_hud - HI_Y0;
    wire [3:0] hi_cell_idx = hi_xrel[9:4];
    wire [2:0] hi_col      = hi_xrel[3:0] >> 1;
    wire [2:0] hi_row      = hi_yrel[3:0] >> 1;

    wire [3:0] hi_digit_idx = hi_cell_idx - HI_LABEL_CHARS;
    wire [3:0] hi_digit_val = (hi_digit_idx == 4'd0) ? high_score_bcd[19:16] :
                               (hi_digit_idx == 4'd1) ? high_score_bcd[15:12] :
                               (hi_digit_idx == 4'd2) ? high_score_bcd[11:8]  :
                               (hi_digit_idx == 4'd3) ? high_score_bcd[7:4]   :
                                                          high_score_bcd[3:0];

    wire [4:0] hi_chsel = (hi_cell_idx == 4'd0) ? 5'd18 :
                          (hi_cell_idx == 4'd1) ? 5'd19 :
                                                    {1'b0, hi_digit_val};

    wire [4:0] hi_glyph_row = glyph_row(hi_chsel, hi_row);
    wire hi_glyph_bit = in_hi_box && (hi_col < 3'd5) && (hi_row < 3'd7) &&
                        hi_glyph_row[4 - hi_col];

    // ==== "GAME OVER" (tengah, gede SCALE=4) ====
    localparam GO_X0 = 10'd176;
    localparam GO_Y0 = 10'd220;
    localparam GO_CHARS = 4'd9;

    wire in_go_box = game_over &&
                     (x >= GO_X0) && (x < GO_X0 + (GO_CHARS * 10'd32)) &&
                     (y >= GO_Y0) && (y < GO_Y0 + 10'd32);

    wire [9:0] go_xrel = x - GO_X0;
    wire [9:0] go_yrel = y - GO_Y0;
    wire [3:0] go_char_idx = go_xrel[9:5];
    wire [2:0] go_col      = go_xrel[4:0] >> 2;
    wire [2:0] go_row      = go_yrel[4:0] >> 2;

    wire [4:0] go_glyph_row = glyph_row(gameover_char(go_char_idx), go_row);
    wire go_glyph_bit = in_go_box && (go_col < 3'd5) && (go_row < 3'd7) &&
                        go_glyph_row[4 - go_col];

    // ==== "START" (tengah, cuma sebelum start pertama) ====
    localparam ST_CHARS = 4'd5;
    localparam ST_X0 = (10'd640 - ST_CHARS * 10'd32) >> 1;
    localparam ST_Y0 = GO_Y0;

    wire in_st_box = !game_started && !countdown_active &&
                     (x >= ST_X0) && (x < ST_X0 + (ST_CHARS * 10'd32)) &&
                     (y >= ST_Y0) && (y < ST_Y0 + 10'd32);

    wire [9:0] st_xrel = x - ST_X0;
    wire [9:0] st_yrel = y - ST_Y0;
    wire [3:0] st_char_idx = st_xrel[9:5];
    wire [2:0] st_col      = st_xrel[4:0] >> 2;
    wire [2:0] st_row      = st_yrel[4:0] >> 2;

    wire [4:0] st_glyph_row = glyph_row(start_char(st_char_idx), st_row);
    wire st_glyph_bit = in_st_box && (st_col < 3'd5) && (st_row < 3'd7) &&
                        st_glyph_row[4 - st_col];

    wire in_st_panel = !game_started && !countdown_active &&
                       (x >= ST_X0 - SCORE_PANEL_MARGIN) && (x < ST_X0 + (ST_CHARS * 10'd32) + SCORE_PANEL_MARGIN) &&
                       (y >= ST_Y0 - SCORE_PANEL_MARGIN) && (y < ST_Y0 + 10'd32 + SCORE_PANEL_MARGIN);

    // ==== countdown / "GO!" (tempat yang sama dengan START/GAME OVER) ====
    localparam CD_CHARS = 4'd2;
    localparam CD_X0 = (10'd640 - CD_CHARS * 10'd32) >> 1;
    localparam CD_Y0 = GO_Y0;

    wire cd_visible = countdown_active || (go_banner_timer != 6'd0);

    wire in_cd_box = cd_visible &&
                     (x >= CD_X0) && (x < CD_X0 + (CD_CHARS * 10'd32)) &&
                     (y >= CD_Y0) && (y < CD_Y0 + 10'd32);

    wire [9:0] cd_xrel = x - CD_X0;
    wire [9:0] cd_yrel = y - CD_Y0;
    wire [3:0] cd_char_idx = cd_xrel[9:5];
    wire [2:0] cd_col      = cd_xrel[4:0] >> 2;
    wire [2:0] cd_row      = cd_yrel[4:0] >> 2;

    wire [4:0] cd_glyph_row = glyph_row(countdown_char(cd_char_idx), cd_row);
    wire cd_glyph_bit = in_cd_box && (cd_col < 3'd5) && (cd_row < 3'd7) &&
                        cd_glyph_row[4 - cd_col];

    wire in_cd_panel = cd_visible &&
                       (x >= CD_X0 - SCORE_PANEL_MARGIN) && (x < CD_X0 + (CD_CHARS * 10'd32) + SCORE_PANEL_MARGIN) &&
                       (y >= CD_Y0 - SCORE_PANEL_MARGIN) && (y < CD_Y0 + 10'd32 + SCORE_PANEL_MARGIN);

    // ==== recap "LAST"/"BEST" di layar START (kalau udah pernah main) ====
    localparam RECAP_CHARS_LABEL = 4'd4;
    localparam RECAP_DIGITS      = 4'd5;
    localparam RECAP_CELL        = 10'd16;
    localparam RECAP_X0 = (10'd640 - (RECAP_CHARS_LABEL + RECAP_DIGITS) * RECAP_CELL) >> 1;
    localparam RECAP_Y0_LAST = ST_Y0 + 10'd32 + SCORE_PANEL_MARGIN * 2 + 10'd14;
    localparam RECAP_Y0_BEST = RECAP_Y0_LAST + RECAP_CELL + SCORE_PANEL_MARGIN * 2 + 10'd6;

    wire recap_visible = !game_started && !countdown_active && has_played_once;

    // "hampir ngalahin rekor sendiri" -> baris LAST nyala emas berpendar.
    wire near_beat_highscore = has_played_once && (last_run_score < high_score) &&
                                ((high_score - last_run_score) <= 16'd50);

    wire [9:0] recap_box_w = (RECAP_CHARS_LABEL + RECAP_DIGITS) * RECAP_CELL;

    wire in_recap_last_box = recap_visible &&
                              (x >= RECAP_X0) && (x < RECAP_X0 + recap_box_w) &&
                              (y >= RECAP_Y0_LAST) && (y < RECAP_Y0_LAST + RECAP_CELL);
    wire in_recap_last_panel = recap_visible &&
                              (x >= RECAP_X0 - SCORE_PANEL_MARGIN) && (x < RECAP_X0 + recap_box_w + SCORE_PANEL_MARGIN) &&
                              (y >= RECAP_Y0_LAST - SCORE_PANEL_MARGIN) && (y < RECAP_Y0_LAST + RECAP_CELL + SCORE_PANEL_MARGIN);

    wire [9:0] recap_last_xrel = x - RECAP_X0;
    wire [9:0] recap_last_yrel = y - RECAP_Y0_LAST;
    wire [3:0] recap_last_cell_idx = recap_last_xrel[9:4];
    wire [2:0] recap_last_col      = recap_last_xrel[3:0] >> 1;
    wire [2:0] recap_last_row      = recap_last_yrel[3:0] >> 1;
    wire [3:0] recap_last_digit_idx = recap_last_cell_idx - RECAP_CHARS_LABEL;
    wire [3:0] recap_last_digit_val = (recap_last_digit_idx == 4'd0) ? last_score_bcd[19:16] :
                                       (recap_last_digit_idx == 4'd1) ? last_score_bcd[15:12] :
                                       (recap_last_digit_idx == 4'd2) ? last_score_bcd[11:8]  :
                                       (recap_last_digit_idx == 4'd3) ? last_score_bcd[7:4]   :
                                                                          last_score_bcd[3:0];
    wire [4:0] recap_last_chsel = recap_char(1'b0, recap_last_cell_idx, recap_last_digit_val);
    wire [4:0] recap_last_glyph_row = glyph_row(recap_last_chsel, recap_last_row);
    wire recap_last_glyph_bit = in_recap_last_box && (recap_last_col < 3'd5) && (recap_last_row < 3'd7) &&
                                 recap_last_glyph_row[4 - recap_last_col];

    wire in_recap_best_box = recap_visible &&
                              (x >= RECAP_X0) && (x < RECAP_X0 + recap_box_w) &&
                              (y >= RECAP_Y0_BEST) && (y < RECAP_Y0_BEST + RECAP_CELL);
    wire in_recap_best_panel = recap_visible &&
                              (x >= RECAP_X0 - SCORE_PANEL_MARGIN) && (x < RECAP_X0 + recap_box_w + SCORE_PANEL_MARGIN) &&
                              (y >= RECAP_Y0_BEST - SCORE_PANEL_MARGIN) && (y < RECAP_Y0_BEST + RECAP_CELL + SCORE_PANEL_MARGIN);

    wire [9:0] recap_best_xrel = x - RECAP_X0;
    wire [9:0] recap_best_yrel = y - RECAP_Y0_BEST;
    wire [3:0] recap_best_cell_idx = recap_best_xrel[9:4];
    wire [2:0] recap_best_col      = recap_best_xrel[3:0] >> 1;
    wire [2:0] recap_best_row      = recap_best_yrel[3:0] >> 1;
    wire [3:0] recap_best_digit_idx = recap_best_cell_idx - RECAP_CHARS_LABEL;
    wire [3:0] recap_best_digit_val = (recap_best_digit_idx == 4'd0) ? high_score_bcd[19:16] :
                                       (recap_best_digit_idx == 4'd1) ? high_score_bcd[15:12] :
                                       (recap_best_digit_idx == 4'd2) ? high_score_bcd[11:8]  :
                                       (recap_best_digit_idx == 4'd3) ? high_score_bcd[7:4]   :
                                                                          high_score_bcd[3:0];
    wire [4:0] recap_best_chsel = recap_char(1'b1, recap_best_cell_idx, recap_best_digit_val);
    wire [4:0] recap_best_glyph_row = glyph_row(recap_best_chsel, recap_best_row);
    wire recap_best_glyph_bit = in_recap_best_box && (recap_best_col < 3'd5) && (recap_best_row < 3'd7) &&
                                 recap_best_glyph_row[4 - recap_best_col];

    // ==== badge "AREA n" (nongol pas ganti zona) ====
    localparam BADGE_CHARS = 4'd5;
    localparam BADGE_CELL  = 10'd16;
    localparam BADGE_X0 = (10'd640 - BADGE_CHARS * BADGE_CELL) >> 1;
    localparam BADGE_Y0 = 10'd46;

    wire zone_badge_visible = (zone_badge_timer != 7'd0);

    wire [9:0] badge_box_w = BADGE_CHARS * BADGE_CELL;

    wire in_badge_box = zone_badge_visible &&
                        (x >= BADGE_X0) && (x < BADGE_X0 + badge_box_w) &&
                        (y >= BADGE_Y0) && (y < BADGE_Y0 + BADGE_CELL);
    wire in_badge_panel = zone_badge_visible &&
                        (x >= BADGE_X0 - SCORE_PANEL_MARGIN) && (x < BADGE_X0 + badge_box_w + SCORE_PANEL_MARGIN) &&
                        (y >= BADGE_Y0 - SCORE_PANEL_MARGIN) && (y < BADGE_Y0 + BADGE_CELL + SCORE_PANEL_MARGIN);

    wire [9:0] badge_xrel = x - BADGE_X0;
    wire [9:0] badge_yrel = y - BADGE_Y0;
    wire [3:0] badge_cell_idx = badge_xrel[9:4];
    wire [2:0] badge_col      = badge_xrel[3:0] >> 1;
    wire [2:0] badge_row      = badge_yrel[3:0] >> 1;

    wire [4:0] badge_glyph_row = glyph_row(badge_char(badge_cell_idx), badge_row);
    wire badge_glyph_bit = in_badge_box && (badge_col < 3'd5) && (badge_row < 3'd7) &&
                           badge_glyph_row[4 - badge_col];

    // Warna aksen border badge per zona (hijau desa, abu kota, biru-putih
    // salju, ungu malam).
    wire [7:0] badge_accent_r = (zone_id == 2'd0) ? 8'd120 : (zone_id == 2'd1) ? 8'd170 : (zone_id == 2'd2) ? 8'd220 : 8'd150;
    wire [7:0] badge_accent_g = (zone_id == 2'd0) ? 8'd220 : (zone_id == 2'd1) ? 8'd170 : (zone_id == 2'd2) ? 8'd235 : 8'd110;
    wire [7:0] badge_accent_b = (zone_id == 2'd0) ? 8'd140 : (zone_id == 2'd1) ? 8'd180 : (zone_id == 2'd2) ? 8'd250 : 8'd230;

    // ==== panel DIST (jarak tempuh) ====
    localparam DIST_LABEL_CHARS = 4'd4;
    localparam DIST_DIGITS      = 4'd5;
    localparam DIST_CELL        = 10'd16;
    localparam DIST_X0 = SCORE_X0;

    // ==== panel NYAWA (ikon hati, di bawah HI) ====
    localparam LIVES_X0 = SCORE_X0;
    localparam LIVES_Y0 = HI_Y0 + HI_CELL + SCORE_PANEL_MARGIN * 2 + 10'd6;
    localparam LIVES_CELL = 10'd16;
    localparam LIVES_SLOTS = 5;   // = LIVES_MAX

    wire [9:0] lives_box_w = LIVES_SLOTS * LIVES_CELL;
    wire [9:0] lives_box_h = LIVES_CELL;

    wire in_lives_box = (x_hud >= LIVES_X0) && (x_hud < LIVES_X0 + lives_box_w) &&
                        (y_hud >= LIVES_Y0) && (y_hud < LIVES_Y0 + lives_box_h);

    wire in_lives_panel = (x_hud >= LIVES_X0 - SCORE_PANEL_MARGIN) && (x_hud < LIVES_X0 + lives_box_w + SCORE_PANEL_MARGIN) &&
                          (y_hud >= LIVES_Y0 - SCORE_PANEL_MARGIN) && (y_hud < LIVES_Y0 + lives_box_h + SCORE_PANEL_MARGIN);

    wire in_lives_border = in_lives_panel &&
                           ((x_hud < LIVES_X0 - SCORE_PANEL_MARGIN + SCORE_BORDER_THICK) ||
                            (x_hud >= LIVES_X0 + lives_box_w + SCORE_PANEL_MARGIN - SCORE_BORDER_THICK) ||
                            (y_hud < LIVES_Y0 - SCORE_PANEL_MARGIN + SCORE_BORDER_THICK) ||
                            (y_hud >= LIVES_Y0 + lives_box_h + SCORE_PANEL_MARGIN - SCORE_BORDER_THICK));

    wire [9:0] lives_xrel = x_hud - LIVES_X0;
    wire [9:0] lives_yrel = y_hud - LIVES_Y0;
    wire [3:0] lives_cell_idx = lives_xrel[9:4];
    wire [2:0] lives_col      = lives_xrel[3:0] >> 1;
    wire [2:0] lives_row      = lives_yrel[3:0] >> 1;

    wire [6:0] lives_heart_row = heart_row_bits(lives_row - 3'd1);
    wire lives_heart_bit = in_lives_box && (lives_col < 3'd7) &&
                           (lives_row >= 3'd1) && (lives_row < 3'd7) &&
                           lives_heart_row[6 - lives_col];
    wire lives_heart_filled = (lives_cell_idx < {1'b0, lives});

    localparam DIST_Y0 = LIVES_Y0 + LIVES_CELL + SCORE_PANEL_MARGIN * 2 + 10'd6;

    wire [9:0] dist_box_w = (DIST_LABEL_CHARS + DIST_DIGITS) * DIST_CELL;
    wire [9:0] dist_box_h = DIST_CELL;

    wire in_dist_box = (x_hud >= DIST_X0) && (x_hud < DIST_X0 + dist_box_w) &&
                       (y_hud >= DIST_Y0) && (y_hud < DIST_Y0 + dist_box_h);

    wire in_dist_panel = (x_hud >= DIST_X0 - SCORE_PANEL_MARGIN) && (x_hud < DIST_X0 + dist_box_w + SCORE_PANEL_MARGIN) &&
                         (y_hud >= DIST_Y0 - SCORE_PANEL_MARGIN) && (y_hud < DIST_Y0 + dist_box_h + SCORE_PANEL_MARGIN);

    wire in_dist_border = in_dist_panel &&
                          ((x_hud < DIST_X0 - SCORE_PANEL_MARGIN + SCORE_BORDER_THICK) ||
                           (x_hud >= DIST_X0 + dist_box_w + SCORE_PANEL_MARGIN - SCORE_BORDER_THICK) ||
                           (y_hud < DIST_Y0 - SCORE_PANEL_MARGIN + SCORE_BORDER_THICK) ||
                           (y_hud >= DIST_Y0 + dist_box_h + SCORE_PANEL_MARGIN - SCORE_BORDER_THICK));

    wire [9:0] dist_xrel = x_hud - DIST_X0;
    wire [9:0] dist_yrel = y_hud - DIST_Y0;
    wire [3:0] dist_cell_idx = dist_xrel[9:4];
    wire [2:0] dist_col      = dist_xrel[3:0] >> 1;
    wire [2:0] dist_row      = dist_yrel[3:0] >> 1;
    wire [3:0] dist_digit_idx = dist_cell_idx - DIST_LABEL_CHARS;
    wire [3:0] dist_digit_val = (dist_digit_idx == 4'd0) ? dist_bcd[19:16] :
                                 (dist_digit_idx == 4'd1) ? dist_bcd[15:12] :
                                 (dist_digit_idx == 4'd2) ? dist_bcd[11:8]  :
                                 (dist_digit_idx == 4'd3) ? dist_bcd[7:4]   :
                                                              dist_bcd[3:0];
    wire [4:0] dist_chsel = (dist_cell_idx == 4'd0) ? 5'd24 : // 'D'
                            (dist_cell_idx == 4'd1) ? 5'd19 : // 'I'
                            (dist_cell_idx == 4'd2) ? 5'd20 : // 'S'
                            (dist_cell_idx == 4'd3) ? 5'd21 : // 'T'
                                                        {1'b0, dist_digit_val};
    wire [4:0] dist_glyph_row = glyph_row(dist_chsel, dist_row);
    wire dist_glyph_bit = in_dist_box && (dist_col < 3'd5) && (dist_row < 3'd7) &&
                          dist_glyph_row[4 - dist_col];

    // ==== panah arah tikungan (HUD tengah atas) ====
    function hud_arrow_at;
        input [9:0] px, py, cx, cy;
        input [4:0] half;
        input       dir;   // 0 = panah kiri, 1 = panah kanan
        reg signed [10:0] ddx, ddy, ady;
        reg signed [10:0] ddx_tri, r;
        begin
            ddx = $signed({1'b0, px}) - $signed({1'b0, cx});
            ddy = $signed({1'b0, py}) - $signed({1'b0, cy});
            ady = ddy[10] ? -ddy : ddy;
            r   = $signed({1'b0, half});
            ddx_tri = dir ? (ddx + r) : (r - ddx);
            hud_arrow_at = (ddx_tri >= 11'sd0) && (ddx_tri <= (r <<< 1)) &&
                           ((ady <<< 1) + ddx_tri <= (r <<< 1));
        end
    endfunction

    localparam [9:0] CURVE_HUD_W      = 10'd64;
    localparam [9:0] CURVE_HUD_H      = 10'd34;
    localparam [9:0] CURVE_HUD_X0     = (10'd640 - CURVE_HUD_W) >> 1;
    localparam [9:0] CURVE_HUD_Y0     = 10'd6;
    localparam [9:0] CURVE_HUD_BORDER = 10'd2;

    wire in_curve_hud_panel = sign_visible &&
                              (x >= CURVE_HUD_X0) && (x < CURVE_HUD_X0 + CURVE_HUD_W) &&
                              (y >= CURVE_HUD_Y0) && (y < CURVE_HUD_Y0 + CURVE_HUD_H);

    wire in_curve_hud_border = in_curve_hud_panel &&
                              ((x < CURVE_HUD_X0 + CURVE_HUD_BORDER) ||
                               (x >= CURVE_HUD_X0 + CURVE_HUD_W - CURVE_HUD_BORDER) ||
                               (y < CURVE_HUD_Y0 + CURVE_HUD_BORDER) ||
                               (y >= CURVE_HUD_Y0 + CURVE_HUD_H - CURVE_HUD_BORDER));

    wire [9:0] curve_hud_cx = CURVE_HUD_X0 + (CURVE_HUD_W >> 1);
    wire [9:0] curve_hud_cy = CURVE_HUD_Y0 + (CURVE_HUD_H >> 1);

    wire curve_hud_arrow_pixel = sign_visible &&
                                  hud_arrow_at(x, y, curve_hud_cx, curve_hud_cy, 5'd12, sign_upcoming_right);

    reg [7:0] terrain_r, terrain_g, terrain_b;

    // ==================================================================
    // ==== BLOK WARNA FINAL ====
    // DI SINILAH semua warna ditentukan. Tiap objek punya blok
    // red/green/blue-nya sendiri (nilai 0-255). Mau ganti warna apapun,
    // cari nama objeknya di sini, ganti 3 angkanya. Urutan if-else =
    // prioritas: yang dicek duluan "menang" kalau ada tumpang tindih.
    // ==================================================================
    always @(*) begin
        if (!video_on) begin
            red   = 8'd0;
            green = 8'd0;
            blue  = 8'd0;
        end
        // ---- MOBIL PEMAIN (dari ROM; putih 0xFFFFFF dianggap transparan) ----
 	else if (is_car_area && car_rgb != 24'hFFFFFF) begin
         red   = car_rgb[23:16];
         green = car_rgb[15:8];
         blue  = car_rgb[7:0];
     end

        // ---- api nitro (kuning/oranye kedip) ----
        else if (nitro_flame_area) begin
            if (nitro_flame_hot) begin
                red   = 8'd255;
                green = 8'd220;
                blue  = 8'd80;
            end else begin
                red   = 8'd255;
                green = 8'd130;
                blue  = 8'd30;
            end
        end

        // ---- debu belok ----
        else if (dust_pixel) begin
            red   = 8'd150;
            green = 8'd135;
            blue  = 8'd118;
        end

        // ---- MUSUH (mobil merah / motor biru-abu) ----
        else if (is_obstacle_area) begin
            if (obstacle_is_car) begin
                if (obs_car_window) begin
                    red   = 8'd35;  green = 8'd40;  blue  = 8'd50;   // kaca gelap
                end else if (obs_car_taillight) begin
                    red   = 8'd250; green = 8'd40;  blue  = 8'd35;   // lampu rem
                end else if (obs_car_plate) begin
                    red   = 8'd225; green = 8'd215; blue  = 8'd175;  // plat nomor
                end else if (obs_car_roof) begin
                    red   = 8'd140; green = 8'd28;  blue  = 8'd28;   // atap (lebih gelap dari bodi)
                end else begin
                    red   = 8'd175; green = 8'd35;  blue  = 8'd35;   // bodi mobil
                end
            end else begin
                if (obs_moto_taillight) begin
                    red   = 8'd250; green = 8'd40;  blue  = 8'd35;   // lampu rem
                end else if (obs_moto_helmet) begin
                    red   = 8'd60;  green = 8'd60;  blue  = 8'd70;   // helm
                end else if (obs_moto_wheel) begin
                    red   = 8'd60;  green = 8'd60;  blue  = 8'd65;   // roda
                end else if (obs_moto_shoulders) begin
                    red   = 8'd105; green = 8'd115; blue  = 8'd150;  // jaket pengendara
                end else begin
                    red   = 8'd100; green = 8'd105; blue  = 8'd120;  // jok/bodi motor
                end
            end
        end

        // ---- RIVAL (VIP emas / biasa biru) ----
        else if (is_rival_area) begin
            if (rival_is_vip) begin
                // Mobil VIP emas berkilau (dimodulasi shimmer_phase).
                if (riv_window) begin
                    red   = 8'd45;  green = 8'd35;  blue  = 8'd20;
                end else if (riv_taillight) begin
                    red   = 8'd255; green = 8'd120; blue  = 8'd40;
                end else if (riv_plate) begin
                    red   = 8'd255; green = 8'd255; blue  = 8'd235;
                end else if (riv_roof) begin
                    red   = 8'd205; green = 8'd150; blue  = 8'd35;
                end else begin
                    red   = 8'd255;
                    green = 8'd190 + {4'd0, shimmer_phase[3:0]};
                    blue  = 8'd40  + {3'd0, shimmer_phase[4:0]};
                end
            end else begin
                // Traffic biasa biru (bisa disalip).
                if (riv_window) begin
                    red   = 8'd30;  green = 8'd38;  blue  = 8'd55;
                end else if (riv_taillight) begin
                    red   = 8'd250; green = 8'd50;  blue  = 8'd40;
                end else if (riv_plate) begin
                    red   = 8'd225; green = 8'd215; blue  = 8'd175;
                end else if (riv_roof) begin
                    red   = 8'd40;  green = 8'd80;  blue  = 8'd160;
                end else begin
                    red   = 8'd55;  green = 8'd105; blue  = 8'd200;
                end
            end
        end

        // ---- PICKUP (bintang emas / nitro cyan) ----
        else if (is_bonus_area) begin
            if (bonus_core) begin
                red   = 8'd255; green = 8'd255; blue  = 8'd230;  // inti terang
            end else if (bonus_is_nitro) begin
                red   = 8'd50;  green = 8'd200; blue  = 8'd255;  // nitro cyan
            end else begin
                red   = 8'd255; green = 8'd205; blue  = 8'd40;   // bintang nyawa emas
            end
        end

        // ---- LANGIT (y < 120): dari ROM latar + awan/burung + efek malam/salju ----
        else if (y < 10'd120) begin
			red   = {bg_pixel[11:8], bg_pixel[11:8]};
			green = {bg_pixel[7:4],  bg_pixel[7:4]};
			blue  = {bg_pixel[3:0],  bg_pixel[3:0]};

            if (cloud_pixel) begin
                red   = blend4(red,   8'd252, 4'd10);
                green = blend4(green, 8'd252, 4'd10);
                blue  = blend4(blue,  8'd255, 4'd10);
            end
            if (bird_pixel) begin
                red   = 8'd38;  green = 8'd40;  blue  = 8'd50;   // siluet burung gelap
            end

            if (in_night_zone) begin
                // Kota malam: langit diredupkan + taburan bintang.
                red   = {1'b0, red[7:1]};
                green = {1'b0, green[7:1]};
                blue  = {1'b0, blue[7:1]} + {3'b0, blue[7:3]};
                if ((y < 10'd80) &&
                    ((x[4:0] ^ y[4:0] ^ {x[7:5], y[6:5]}) == 5'd0)) begin
                    red   = 8'd230; green = 8'd230; blue  = 8'd255;   // bintang
                end
            end else if (in_snow_zone) begin
                // Salju: langit dipucatkan.
                red   = blend4(red,   8'd245, 4'd5);
                green = blend4(green, 8'd248, 4'd5);
                blue  = blend4(blue,  8'd252, 4'd5);
            end
		  end

        // ---- TANAH & OBJEK DI BAWAH HORIZON (y >= 120) ----
        // Semua diwarnai ke terrain_r/g/b dulu, baru di akhir di-blend
        // horizon fade + efek global (malam/hujan/flash/fade/HUD).
        else begin
            if (left_line_edge_aa || right_line_edge_aa) begin
                terrain_r = blend4(8'd65, 8'd255, line_edge_w);
                terrain_g = blend4(8'd65, 8'd255, line_edge_w);
                terrain_b = blend4(8'd65, 8'd255, line_edge_w);
            end

            else if (left_solid_line || right_solid_line || center_dash) begin
                terrain_r = 8'd255; terrain_g = 8'd255; terrain_b = 8'd255; // marka putih
            end

            else if (road_area) begin
                // Aspal (ungu-abu gelap). asphalt_fleck = bintik tekstur.
                if (asphalt_fleck) begin
                    terrain_r = 8'd66; terrain_g = 8'd62; terrain_b = 8'd84;
                end else begin
                    terrain_r = 8'd56; terrain_g = 8'd52; terrain_b = 8'd76;
                end
            end

            else if (left_road_edge_aa || right_road_edge_aa) begin
                terrain_r = blend4(8'd140, 8'd56, road_edge_w);
                terrain_g = blend4(8'd116, 8'd52, road_edge_w);
                terrain_b = blend4(8'd148, 8'd76, road_edge_w);
            end

            else if (trotoar_left || trotoar_right) begin
                // Trotoar belang hitam-putih.
                if (trotoar_stripe) begin
                    terrain_r = 8'd235; terrain_g = 8'd235; terrain_b = 8'd235;
                end else begin
                    terrain_r = 8'd18; terrain_g = 8'd18; terrain_b = 8'd18;
                end
            end

            else if (tree_canopy_outline) begin
                if (in_snow_zone) begin
                    terrain_r = 8'd235; terrain_g = 8'd242; terrain_b = 8'd248; // rim salju
                end else begin
                    terrain_r = 8'd22; terrain_g = 8'd45; terrain_b = 8'd55;    // outline kanopi
                end
            end

            else if (tree_canopy_lit) begin
                if (in_snow_zone) begin
                    terrain_r = 8'd38; terrain_g = 8'd92; terrain_b = 8'd66;   // cemara terang
                end else begin
                    terrain_r = 8'd62; terrain_g = 8'd118; terrain_b = 8'd130; // kanopi terang
                end
            end

            else if (tree_canopy_shadow) begin
                if (in_snow_zone) begin
                    terrain_r = 8'd24; terrain_g = 8'd62; terrain_b = 8'd46;
                end else begin
                    terrain_r = 8'd40; terrain_g = 8'd82; terrain_b = 8'd96;
                end
            end

            else if (tree_trunk_lit) begin
                terrain_r = 8'd102; terrain_g = 8'd78; terrain_b = 8'd96;   // batang terang
            end

            else if (tree_trunk_shadow) begin
                terrain_r = 8'd72; terrain_g = 8'd54; terrain_b = 8'd68;    // batang bayangan
            end

            else if (light_glow) begin
                terrain_r = 8'd230; terrain_g = 8'd190; terrain_b = 8'd90;  // cahaya lampu jalan
            end

            else if (light_lamp_housing) begin
                terrain_r = 8'd70; terrain_g = 8'd70; terrain_b = 8'd75;    // rumah lampu
            end

            else if (light_arm) begin
                terrain_r = 8'd60; terrain_g = 8'd60; terrain_b = 8'd65;    // lengan tiang
            end

            else if (light_panel) begin
                terrain_r = 8'd30; terrain_g = 8'd40; terrain_b = 8'd75;    // panel surya
            end

            else if (light_pole_lit) begin
                terrain_r = 8'd90; terrain_g = 8'd90; terrain_b = 8'd95;    // tiang terang
            end

            else if (light_pole_shadow) begin
                terrain_r = 8'd55; terrain_g = 8'd55; terrain_b = 8'd60;    // tiang bayangan
            end

            else if (pond_shore) begin
                terrain_r = 8'd120; terrain_g = 8'd96; terrain_b = 8'd64;   // tepi kolam
            end

            else if (pond_water_lit) begin
                if (pond_shimmer) begin
                    terrain_r = 8'd170; terrain_g = 8'd225; terrain_b = 8'd235; // kilau air
                end else if (in_snow_zone) begin
                    terrain_r = 8'd190; terrain_g = 8'd220; terrain_b = 8'd235; // es
                end else begin
                    terrain_r = 8'd70; terrain_g = 8'd150; terrain_b = 8'd180;  // air terang
                end
            end

            else if (pond_water_shadow) begin
                if (in_snow_zone) begin
                    terrain_r = 8'd150; terrain_g = 8'd185; terrain_b = 8'd205;
                end else begin
                    terrain_r = 8'd35; terrain_g = 8'd90; terrain_b = 8'd120;   // air dalam
                end
            end

            else if (person_torso) begin
                terrain_r = 8'd60; terrain_g = 8'd90; terrain_b = 8'd150;   // baju
            end
            else if (person_legs) begin
                terrain_r = 8'd55; terrain_g = 8'd55; terrain_b = 8'd62;    // celana
            end
            else if (person_arms) begin
                terrain_r = 8'd210; terrain_g = 8'd165; terrain_b = 8'd130; // tangan (kulit)
            end
            else if (person_head) begin
                terrain_r = 8'd210; terrain_g = 8'd165; terrain_b = 8'd130; // wajah
            end
            else if (person_hair) begin
                terrain_r = 8'd40; terrain_g = 8'd30; terrain_b = 8'd26;    // rambut
            end

            // ---- landmark menara jam (dicek sebelum gedung biasa) ----
            else if (lm_clock_dot || lm_clock_ring) begin
                terrain_r = 8'd40; terrain_g = 8'd32; terrain_b = 8'd30;    // jarum/cincin jam
            end
            else if (lm_clock_face) begin
                terrain_r = 8'd245; terrain_g = 8'd240; terrain_b = 8'd215; // muka jam krem
            end
            else if (lm_window) begin
                terrain_r = 8'd255; terrain_g = 8'd210; terrain_b = 8'd110; // jendela menara
            end
            else if (lm_roof_px) begin
                terrain_r = 8'd70; terrain_g = 8'd45; terrain_b = 8'd45;    // atap menara
            end
            else if (lm_in_body) begin
                if (lm_is_lit) begin
                    terrain_r = 8'd170; terrain_g = 8'd80; terrain_b = 8'd70;  // bata merah terang
                end else begin
                    terrain_r = 8'd122; terrain_g = 8'd56; terrain_b = 8'd50;  // bata merah bayangan
                end
            end

            else if (market_sign) begin
                terrain_r = 8'd220; terrain_g = 8'd48; terrain_b = 8'd56;   // papan minimarket
            end
            else if (market_door) begin
                terrain_r = 8'd120; terrain_g = 8'd170; terrain_b = 8'd200; // pintu kaca
            end
            else if (market_window) begin
                terrain_r = 8'd200; terrain_g = 8'd230; terrain_b = 8'd245; // etalase
            end
            else if (market_roof) begin
                terrain_r = 8'd150; terrain_g = 8'd140; terrain_b = 8'd130; // atap
            end
            else if (market_wall_lit) begin
                terrain_r = 8'd235; terrain_g = 8'd200; terrain_b = 8'd140; // dinding terang
            end
            else if (market_wall_shadow) begin
                terrain_r = 8'd178; terrain_g = 8'd148; terrain_b = 8'd100; // dinding bayangan
            end

            else if (building_window) begin
                terrain_r = 8'd255; terrain_g = 8'd210; terrain_b = 8'd110; // jendela gedung nyala
            end
            else if (building_roof) begin
                terrain_r = 8'd90; terrain_g = 8'd94; terrain_b = 8'd102;   // parapet atap
            end
            else if (building_wall_lit) begin
                terrain_r = 8'd160; terrain_g = 8'd168; terrain_b = 8'd180; // dinding terang
            end
            else if (building_wall_shadow) begin
                terrain_r = 8'd104; terrain_g = 8'd112; terrain_b = 8'd126; // dinding bayangan
            end

            else if (house_roof) begin
                if (in_snow_zone) begin
                    terrain_r = 8'd232; terrain_g = 8'd238; terrain_b = 8'd246; // atap bersalju
                end else begin
                    terrain_r = 8'd140; terrain_g = 8'd58; terrain_b = 8'd48;   // atap genteng merah
                end
            end
            else if (house_door) begin
                terrain_r = 8'd96; terrain_g = 8'd64; terrain_b = 8'd44;    // pintu kayu
            end
            else if (house_window) begin
                terrain_r = 8'd250; terrain_g = 8'd220; terrain_b = 8'd120; // jendela nyala
            end
            else if (house_wall_lit) begin
                terrain_r = 8'd222; terrain_g = 8'd196; terrain_b = 8'd160; // dinding terang
            end
            else if (house_wall_shadow) begin
                terrain_r = 8'd168; terrain_g = 8'd146; terrain_b = 8'd120; // dinding bayangan
            end

            else if (windmill_blade) begin
                terrain_r = 8'd235; terrain_g = 8'd228; terrain_b = 8'd210; // bilah kincir
            end
            else if (windmill_hub) begin
                terrain_r = 8'd45; terrain_g = 8'd40; terrain_b = 8'd38;    // poros
            end
            else if (windmill_tower_lit) begin
                terrain_r = 8'd188; terrain_g = 8'd176; terrain_b = 8'd162; // menara terang
            end
            else if (windmill_tower_shadow) begin
                terrain_r = 8'd132; terrain_g = 8'd122; terrain_b = 8'd112; // menara bayangan
            end

            else if (billboard_stripe) begin
                terrain_r = 8'd245; terrain_g = 8'd205; terrain_b = 8'd60;  // pita aksen papan
            end
            else if (billboard_face) begin
                terrain_r = 8'd210; terrain_g = 8'd60; terrain_b = 8'd50;   // muka papan iklan
            end
            else if (billboard_frame) begin
                terrain_r = 8'd35; terrain_g = 8'd35; terrain_b = 8'd38;    // bingkai
            end
            else if (billboard_pole_lit) begin
                terrain_r = 8'd150; terrain_g = 8'd150; terrain_b = 8'd155; // tiang terang
            end
            else if (billboard_pole_shadow) begin
                terrain_r = 8'd95; terrain_g = 8'd95; terrain_b = 8'd100;   // tiang bayangan
            end

            else if (in_city_zone) begin
                // Trotoar/aspal kota (4 gradasi abu).
                case ({grass_speck_a, grass_speck_b})
                    2'b00: begin terrain_r = 8'd96;  terrain_g = 8'd96;  terrain_b = 8'd100; end
                    2'b01: begin terrain_r = 8'd104; terrain_g = 8'd104; terrain_b = 8'd108; end
                    2'b10: begin terrain_r = 8'd112; terrain_g = 8'd112; terrain_b = 8'd116; end
                    default: begin terrain_r = 8'd120; terrain_g = 8'd120; terrain_b = 8'd124; end
                endcase
            end

            else if (in_snow_zone) begin
                // Tanah salju (4 gradasi putih kebiruan).
                case ({grass_speck_a, grass_speck_b})
                    2'b00: begin terrain_r = 8'd222; terrain_g = 8'd230; terrain_b = 8'd240; end
                    2'b01: begin terrain_r = 8'd230; terrain_g = 8'd237; terrain_b = 8'd246; end
                    2'b10: begin terrain_r = 8'd238; terrain_g = 8'd244; terrain_b = 8'd250; end
                    default: begin terrain_r = 8'd246; terrain_g = 8'd250; terrain_b = 8'd254; end
                endcase
            end

            else begin
                // RUMPUT default (4 gradasi hijau-teal). Mau ganti warna
                // rumput? Di sinilah 4 baris case ini.
                case ({grass_speck_a, grass_speck_b})
                    2'b00: begin terrain_r = 8'd52; terrain_g = 8'd104; terrain_b = 8'd116; end
                    2'b01: begin terrain_r = 8'd58; terrain_g = 8'd112; terrain_b = 8'd124; end
                    2'b10: begin terrain_r = 8'd64; terrain_g = 8'd120; terrain_b = 8'd132; end
                    default: begin terrain_r = 8'd70; terrain_g = 8'd128; terrain_b = 8'd140; end
                endcase
            end

            // Pantulan lampu di aspal basah (blend di atas terrain).
            if (light_reflection) begin
                terrain_r = blend4(terrain_r, 8'd245, wet_glint ? 4'd8 : 4'd4);
                terrain_g = blend4(terrain_g, 8'd205, wet_glint ? 4'd8 : 4'd4);
                terrain_b = blend4(terrain_b, 8'd120, wet_glint ? 4'd6 : 4'd3);
            end

            // Horizon fade: beberapa baris pertama di bawah gambar latar
            // di-blend dari warna langit ke warna tanah.
            if (in_horizon_blend) begin
                red   = blend4(horizon_r_eff, terrain_r, horizon_blend_w);
                green = blend4(horizon_g_eff, terrain_g, horizon_blend_w);
                blue  = blend4(horizon_b_eff, terrain_b, horizon_blend_w);
            end else begin
                red   = terrain_r;
                green = terrain_g;
                blue  = terrain_b;
            end
        end

        // ==== EFEK GLOBAL (ditumpuk di atas hasil di atas) ====

        // ---- kota malam: seluruh scene diredupkan KECUALI sumber cahaya ----
        if (video_on && in_night_zone && (y >= 10'd120) && !night_keep_bright) begin
            red   = {1'b0, red[7:1]};
            green = {1'b0, green[7:1]};
            blue  = {1'b0, blue[7:1]} + {3'b0, blue[7:3]};
        end

        // ---- hujan: langit mendung + garis diagonal ----
        if (video_on && rain_active) begin
            red   = blend4(red,   8'd95,  4'd3);
            green = blend4(green, 8'd100, 4'd3);
            blue  = blend4(blue,  8'd112, 4'd3);
            if (rain_streak) begin
                red   = blend4(red,   8'd175, 4'd8);
                green = blend4(green, 8'd195, 4'd8);
                blue  = blend4(blue,  8'd225, 4'd8);
            end
        end

        // ---- salju: butiran putih ----
        if (video_on && snow_flake) begin
            red   = blend4(red,   8'd255, 4'd12);
            green = blend4(green, 8'd255, 4'd12);
            blue  = blend4(blue,  8'd255, 4'd12);
        end

        // ---- petir: kilatan putih-kebiruan ----
        if (video_on && lightning_flash != 4'd0) begin
            red   = blend4(red,   8'd235, lightning_flash);
            green = blend4(green, 8'd240, lightning_flash);
            blue  = blend4(blue,  8'd255, lightning_flash);
        end

        // ---- flash merah nabrak ----
        if (video_on && hit_flash != 4'd0) begin
            red   = blend4(red,   8'd255, hit_flash);
            green = blend4(green, 8'd30,  hit_flash);
            blue  = blend4(blue,  8'd30,  hit_flash);
        end

        // ---- kilatan emas near-miss / VIP ----
        if (video_on && nm_flash != 4'd0) begin
            red   = blend4(red,   8'd255, nm_flash);
            green = blend4(green, 8'd215, nm_flash);
            blue  = blend4(blue,  8'd80,  {1'b0, nm_flash[3:1]});
        end

        // ---- confetti milestone ----
        if (video_on && confetti_px) begin
            case ({x[6] ^ shimmer_phase[1], y[6] ^ shimmer_phase[2]})
                2'b00:  begin red = 8'd255; green = 8'd90;  blue = 8'd120; end // pink
                2'b01:  begin red = 8'd255; green = 8'd215; blue = 8'd60;  end // emas
                2'b10:  begin red = 8'd90;  green = 8'd220; blue = 8'd120; end // hijau
                default:begin red = 8'd110; green = 8'd170; blue = 8'd255; end // biru
            endcase
        end

        // ---- fade layar (game over): gelapin scene, TAPI sebelum HUD ----
        red   = blend4(red,   8'd0, fade_level);
        green = blend4(green, 8'd0, fade_level);
        blue  = blend4(blue,  8'd0, fade_level);

        // ==== HUD (digambar paling akhir, selalu di atas segalanya) ====
        if (video_on) begin
            // panel skor (border emas + digit kuning)
            if (in_score_panel) begin
                if (in_score_border) begin
                    red   = 8'd255; green = 8'd200; blue  = 8'd60;
                end else begin
                    red   = 8'd18;  green = 8'd16;  blue  = 8'd30;
                end
            end
            if (score_glyph_bit) begin
                red   = 8'd255; green = 8'd230; blue  = 8'd40;
            end

            // panel high score (border perak + digit biru pucat)
            if (in_hi_panel) begin
                if (in_hi_border) begin
                    red   = 8'd200; green = 8'd200; blue  = 8'd220;
                end else begin
                    red   = 8'd18;  green = 8'd16;  blue  = 8'd30;
                end
            end
            if (hi_glyph_bit) begin
                red   = 8'd200; green = 8'd220; blue  = 8'd255;
            end

            // panel nyawa (border merah + hati)
            if (in_lives_panel) begin
                if (in_lives_border) begin
                    red   = 8'd255; green = 8'd120; blue  = 8'd120;
                end else begin
                    red   = 8'd18;  green = 8'd16;  blue  = 8'd30;
                end
            end
            if (lives_heart_bit) begin
                if (lives_heart_filled) begin
                    red   = 8'd255; green = 8'd70;  blue  = 8'd95;    // hati penuh
                end else begin
                    red   = 8'd72;  green = 8'd38;  blue  = 8'd48;    // slot kosong
                end
            end

            // panel jarak
            if (in_dist_panel) begin
                if (in_dist_border) begin
                    red   = 8'd160; green = 8'd200; blue  = 8'd255;
                end else begin
                    red   = 8'd18;  green = 8'd16;  blue  = 8'd30;
                end
            end
            if (dist_glyph_bit) begin
                red   = 8'd180; green = 8'd215; blue  = 8'd255;
            end

            // panah arah tikungan
            if (in_curve_hud_panel) begin
                if (in_curve_hud_border) begin
                    red   = 8'd255; green = 8'd190; blue  = 8'd40;
                end else begin
                    red   = 8'd18;  green = 8'd16;  blue  = 8'd30;
                end
            end
            if (curve_hud_arrow_pixel) begin
                red   = 8'd255; green = 8'd225; blue  = 8'd60;
            end

            // badge "AREA n"
            if (in_badge_panel) begin
                red   = badge_accent_r; green = badge_accent_g; blue  = badge_accent_b;
            end
            if (badge_glyph_bit) begin
                red   = 8'd255; green = 8'd255; blue  = 8'd240;
            end

            // banner START (teks hijau)
            if (in_st_panel) begin
                red   = 8'd18; green = 8'd16; blue  = 8'd30;
            end
            if (st_glyph_bit) begin
                red   = 8'd120; green = 8'd255; blue  = 8'd140;
            end

            // recap LAST (merah lembut / emas berpendar kalau hampir rekor)
            if (in_recap_last_panel) begin
                red   = 8'd18; green = 8'd16; blue  = 8'd30;
            end
            if (recap_last_glyph_bit) begin
                if (near_beat_highscore) begin
                    red   = 8'd255;
                    green = 8'd210 + {3'b0, shimmer_phase[4:2]};
                    blue  = 8'd60;
                end else begin
                    red   = 8'd255; green = 8'd150; blue  = 8'd150;
                end
            end

            // recap BEST (emas)
            if (in_recap_best_panel) begin
                red   = 8'd18; green = 8'd16; blue  = 8'd30;
            end
            if (recap_best_glyph_bit) begin
                red   = 8'd255; green = 8'd215; blue  = 8'd90;
            end

            // countdown / "GO!" (kuning)
            if (in_cd_panel) begin
                red   = 8'd18; green = 8'd16; blue  = 8'd30;
            end
            if (cd_glyph_bit) begin
                red   = 8'd255; green = 8'd230; blue  = 8'd60;
            end

            // "GAME OVER" (merah)
            if (go_glyph_bit) begin
                red   = 8'd255; green = 8'd40; blue  = 8'd40;
            end
        end
    end

endmodule
