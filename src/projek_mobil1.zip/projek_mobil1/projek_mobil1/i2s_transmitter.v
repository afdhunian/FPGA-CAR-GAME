// i2s_transmitter.v
//
// Generates the I2S clocks (BCLK, LRCLK) and serializes a pair of 16-bit
// signed samples (left, right) out onto DACDAT, in time with those
// clocks, for the WM8731 (configured as an I2S slave -- it just follows
// whatever BCLK/LRCLK we hand it).
//
// Clock plan (approximate, divider-based -- see note in i2c_av_config.v
// about using an ALTPLL instead if you want an exact 48kHz):
//   CLOCK_50 (50MHz) --/16--> AUD_XCK  (~3.125MHz "MCLK" -- see note below)
//   CLOCK_50 (50MHz) --/16--> BCLK     (~3.125MHz)
//   BCLK           --/64--> LRCLK    (~48.8kHz)
//
// NOTE: for a real project you'd normally feed WM8731's AUD_XCK with a
// proper 12.288MHz (256*48kHz) master clock from a PLL, matching the
// R8 Sampling Control setting in i2c_av_config.v. The divider-based
// clock here is a simplification that still produces working audio
// (BCLK/LRCLK ratio of 64:1 is what matters for the codec to correctly
// find bit and frame boundaries in slave mode) but the exact sample
// rate will drift from a "true" 48kHz. Good enough for game sound
// effects; swap in an ALTPLL-generated AUD_XCK later if you want it
// precise.

module i2s_transmitter (
    input  wire        clk,        // 50MHz system clock
    input  wire        reset,
    input  wire signed [15:0] sample_left,
    input  wire signed [15:0] sample_right,
    output wire        aud_bclk,
    output wire        aud_daclrck,
    output wire        aud_dacdat,
    output wire        sample_tick // 1-cycle pulse once per L+R frame -- use this
                                    // to know when it's safe to update
                                    // sample_left/sample_right for the
                                    // next frame without tearing
);

    // ---- BCLK: divide 50MHz down ----
    reg [3:0] bclk_div;
    reg       bclk_reg;
    always @(posedge clk) begin
        if (reset) begin
            bclk_div <= 4'd0;
            bclk_reg <= 1'b0;
        end else if (bclk_div == 4'd7) begin // /16 total (toggle every 8)
            bclk_div <= 4'd0;
            bclk_reg <= ~bclk_reg;
        end else begin
            bclk_div <= bclk_div + 4'd1;
        end
    end
    assign aud_bclk = bclk_reg;

    // ---- Bit counter within the current L or R half-frame ----
    // I2S: LRCLK low = left channel, high = right channel. Data is
    // MSB-first, and shifts out on the BCLK falling edge, one BCLK
    // period AFTER the LRCLK edge (that one-clock delay is the classic
    // "I2S vs left-justified" difference).
    reg [5:0]  bit_pos;     // 0..63 within a full L+R frame (32 bits each side... using 32 BCLKs per channel here for margin)
    reg        lrclk_reg;
    reg [15:0] shift_reg;
    reg        dacdat_reg;
    reg        tick_reg;

    localparam HALF_FRAME = 6'd32; // BCLKs per channel half-frame

    reg bclk_reg_prev;
    always @(posedge clk) bclk_reg_prev <= bclk_reg;
    wire bclk_falling = bclk_reg_prev && !bclk_reg;
    wire bclk_rising  = !bclk_reg_prev && bclk_reg;

    always @(posedge clk) begin
        if (reset) begin
            bit_pos    <= 6'd0;
            lrclk_reg  <= 1'b0;
            shift_reg  <= 16'd0;
            dacdat_reg <= 1'b0;
            tick_reg   <= 1'b0;
        end else begin
            tick_reg <= 1'b0;

            if (bclk_rising) begin
                if (bit_pos == (HALF_FRAME * 2 - 1)) begin
                    bit_pos <= 6'd0;
                end else begin
                    bit_pos <= bit_pos + 6'd1;
                end

                // LRCLK flips at the start of each half-frame
                if (bit_pos == 6'd0) begin
                    lrclk_reg <= 1'b0; // entering left channel
                    shift_reg <= sample_left;
                    tick_reg  <= 1'b1; // new frame starting -- safe point to latch next samples
                end else if (bit_pos == HALF_FRAME) begin
                    lrclk_reg <= 1'b1; // entering right channel
                    shift_reg <= sample_right;
                end
            end

            if (bclk_falling) begin
                // Output the MSB, then shift. The extra 1-BCLK delay
                // relative to the LRCLK edge (checking bit_pos==1/HALF_FRAME+1
                // for the FIRST data bit) is what makes this true I2S
                // rather than left-justified.
                if (bit_pos >= 6'd1 && bit_pos <= 6'd16) begin
                    dacdat_reg <= shift_reg[15];
                    shift_reg  <= {shift_reg[14:0], 1'b0};
                end else if (bit_pos >= (HALF_FRAME + 6'd1) && bit_pos <= (HALF_FRAME + 6'd16)) begin
                    dacdat_reg <= shift_reg[15];
                    shift_reg  <= {shift_reg[14:0], 1'b0};
                end else begin
                    dacdat_reg <= 1'b0;
                end
            end
        end
    end

    assign aud_daclrck = lrclk_reg;
    assign aud_dacdat   = dacdat_reg;
    assign sample_tick  = tick_reg;

endmodule
