// music_rom_player.v
//
// Plays back the 8-bit / 8kHz PCM sample baked into music_rom.hex
// (and equivalently music_rom.mif, for anyone who'd rather bring the
// data in through Quartus's ROM/altsyncram IP instead of $readmemh).
//
// Source clip: preview_8bit_8khz.wav
//   75970 samples, 8-bit unsigned PCM (128 = silence), 8000 Hz mono
//
// Port list matches the music_player slot in audio_top.v:
//
//   music_rom_player u_music (
//       .clk(clk), .reset(reset),
//       .enable(!game_over && config_done),
//       .sample(music_sample)
//   );
//
// i.e. this can be dropped in as a straight replacement for
// music_player -- just rename the instantiation in audio_top.v (or
// rename this module back to music_player, whichever's less hassle).
//
// Loops continuously: when the last sample is reached the address
// counter wraps back to 0, so the clip repeats for as long as
// `enable` is high.

module music_rom_player #(
    parameter NUM_SAMPLES = 75970,          // depth of music_rom.hex/.mif
    parameter ADDR_WIDTH  = 17,             // ceil(log2(75970)) = 17 -> 0..131071 addressable, only 0..75969 used
    parameter CLK_HZ      = 50_000_000,     // board oscillator (matches audio_top.v's clk)
    parameter SAMPLE_HZ   = 8_000           // must match the source wav's sample rate
) (
    input  wire        clk,
    input  wire        reset,
    input  wire        enable,

    output reg  signed [15:0] sample
);

    // ------------------------------------------------------------------
    // ROM: one 8-bit unsigned PCM sample per address, loaded from the
    // ripped-out wav data. Quartus infers this as block RAM from the
    // $readmemh initial block -- keep music_rom.hex next to the .v
    // files (project directory) so the initial block can find it.
    //
    // If you'd rather use the IP Catalog's ROM: 1-PORT / altsyncram
    // megafunction instead (pointing it at music_rom.mif), swap the
    // reg array + $readmemh below for an instantiation of that IP and
    // keep everything downstream (the addr counter, tick divider, and
    // sign conversion) exactly as-is.
    // ------------------------------------------------------------------
    reg [7:0] rom [0:NUM_SAMPLES-1];
    initial begin
        $readmemh("music_rom.hex", rom);
    end

    // ------------------------------------------------------------------
    // Sample-rate tick generator: divide CLK_HZ down to SAMPLE_HZ.
    // 50,000,000 / 8,000 = 6250 clk cycles per audio sample.
    // ------------------------------------------------------------------
    localparam integer DIV_MAX = (CLK_HZ / SAMPLE_HZ) - 1; // 6249
    localparam integer DIV_WIDTH = 13; // enough bits for 6249

    reg [DIV_WIDTH-1:0] div_cnt;
    wire                sample_tick = (div_cnt == DIV_MAX[DIV_WIDTH-1:0]);

    always @(posedge clk) begin
        if (reset)
            div_cnt <= {DIV_WIDTH{1'b0}};
        else if (sample_tick)
            div_cnt <= {DIV_WIDTH{1'b0}};
        else
            div_cnt <= div_cnt + 1'b1;
    end

    // ------------------------------------------------------------------
    // Address counter: walks the ROM once per sample tick, wraps at
    // NUM_SAMPLES so the clip loops instead of reading garbage/zeros
    // past the end.
    // ------------------------------------------------------------------
    reg [ADDR_WIDTH-1:0] addr;
    always @(posedge clk) begin
        if (reset)
            addr <= {ADDR_WIDTH{1'b0}};
        else if (enable && sample_tick) begin
            if (addr == NUM_SAMPLES[ADDR_WIDTH-1:0] - 1'b1)
                addr <= {ADDR_WIDTH{1'b0}};
            else
                addr <= addr + 1'b1;
        end
    end

    // ------------------------------------------------------------------
    // Registered ROM read (one cycle of latency -- fine here since
    // the address only moves once every 6250 clk cycles anyway).
    // ------------------------------------------------------------------
    reg [7:0] rom_data;
    always @(posedge clk) begin
        rom_data <= rom[addr];
    end

    // ------------------------------------------------------------------
    // 8-bit unsigned PCM (0..255, 128 = silence) -> 16-bit signed.
    // Subtract the 128 DC offset, then scale up into the 16-bit range
    // by shifting left 8 (x256), matching the signed 16-bit sample
    // format engine_sound/crash_sfx/the mixer in audio_top.v expect.
    // ------------------------------------------------------------------
    wire signed [8:0]  centered      = $signed({1'b0, rom_data}) - 9'sd128; // -128..127
    wire signed [15:0] sample_scaled = centered * 16'sd128;                 // -16384..16256, well within +-32767

    always @(posedge clk) begin
        if (reset)
            sample <= 16'sd0;
        else if (!enable)
            sample <= 16'sd0;
        else
            sample <= sample_scaled;
    end

endmodule